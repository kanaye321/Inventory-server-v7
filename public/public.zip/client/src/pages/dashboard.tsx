import { useState, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { format } from "date-fns";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer,
  PieChart, Pie, Cell, Tooltip,
} from "recharts";
import {
  Package, Server, Shield, TrendingUp, Laptop, AlertTriangle, CheckCircle,
  Activity, BarChart3, Plus, FileText, Zap, Users, XCircle, ArrowUpRight,
  Gauge, ChevronRight, Database, RotateCcw, MapPin, Target, Wrench,
  Briefcase,
} from "lucide-react";

const PIE_COLORS = ["#10b981", "#3b82f6", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899"];

// ─── StatCard ─────────────────────────────────────────────────────────────────
function StatCard({ label, value, sub, icon: Icon, gradient, href }: {
  label: string; value: string | number; sub?: string;
  icon: any; gradient: [string, string]; href?: string;
}) {
  const inner = (
    <div
      className="relative overflow-hidden rounded-2xl p-5 text-white shadow-lg cursor-pointer group
                 transition-all duration-200 hover:-translate-y-1 hover:shadow-xl"
      style={{ background: `linear-gradient(135deg, ${gradient[0]}, ${gradient[1]})` }}
    >
      <div className="absolute -right-6 -top-6 w-28 h-28 rounded-full opacity-20 bg-white" />
      <div className="absolute -right-2 -bottom-4 w-16 h-16 rounded-full opacity-10 bg-white" />
      <div className="relative flex items-start justify-between">
        <div>
          <p className="text-sm font-medium opacity-85">{label}</p>
          <p className="mt-1 text-3xl font-bold tracking-tight">{value}</p>
          {sub && <p className="mt-1 text-xs opacity-75 flex items-center gap-1"><TrendingUp className="h-3 w-3" />{sub}</p>}
        </div>
        <div className="h-11 w-11 rounded-xl bg-white/20 flex items-center justify-center group-hover:bg-white/30 transition-colors flex-shrink-0">
          <Icon className="h-6 w-6" />
        </div>
      </div>
      {href && (
        <div className="mt-4 flex items-center gap-1 text-xs font-medium opacity-75 group-hover:opacity-100 transition-opacity">
          View details <ArrowUpRight className="h-3 w-3" />
        </div>
      )}
    </div>
  );
  return href ? <Link href={href}>{inner}</Link> : inner;
}

// ─── OperationalCard ──────────────────────────────────────────────────────────
function OperationalCard({ title, desc, value, note, icon: Icon, iconColor, borderColor, href }: {
  title: string; desc: string; value: number; note: string;
  icon: any; iconColor: string; borderColor: string; href: string;
}) {
  return (
    <Link href={href}>
      <div className={`bg-white dark:bg-white/5 border-l-4 ${borderColor} rounded-xl p-5 shadow-sm
                       cursor-pointer hover:shadow-md transition-all duration-200 hover:-translate-y-0.5`}>
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className={`font-semibold text-sm ${iconColor}`}>{title}</h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{desc}</p>
          </div>
          <Icon className={`h-7 w-7 ${iconColor} opacity-70`} />
        </div>
        <div className={`text-2xl font-bold ${iconColor} mb-2`}>{value}</div>
        <div className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400">
          <CheckCircle className="h-3.5 w-3.5" />
          <span>{note}</span>
        </div>
      </div>
    </Link>
  );
}

// ─── QuickAction ─────────────────────────────────────────────────────────────
function QuickAction({ label, icon: Icon, href, colorClass }: {
  label: string; icon: any; href: string; colorClass: string;
}) {
  return (
    <Link href={href}>
      <div className="flex flex-col items-center gap-2 p-3 rounded-xl border border-gray-200 dark:border-white/5
                      bg-white dark:bg-white/5 hover:bg-gray-50 dark:hover:bg-white/10
                      transition-all duration-200 cursor-pointer group hover:-translate-y-0.5 shadow-sm">
        <div className={`h-10 w-10 rounded-xl flex items-center justify-center ${colorClass} transition-transform group-hover:scale-110`}>
          <Icon className="h-5 w-5" />
        </div>
        <span className="text-[11px] font-medium text-gray-600 dark:text-gray-300 text-center leading-tight">{label}</span>
      </div>
    </Link>
  );
}

// ─── Section wrapper ─────────────────────────────────────────────────────────
function Section({ title, subtitle, icon: Icon, iconColor, children, action }: {
  title: string; subtitle?: string; icon?: any; iconColor?: string;
  children: React.ReactNode; action?: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl bg-white dark:bg-white/5 border border-gray-200 dark:border-white/5 shadow-sm">
      <div className="flex items-center justify-between px-5 pt-5 pb-4">
        <div className="flex items-center gap-2">
          {Icon && <Icon className={`h-5 w-5 ${iconColor ?? "text-blue-500"}`} />}
          <div>
            <h2 className="font-semibold text-gray-800 dark:text-gray-100 text-sm">{title}</h2>
            {subtitle && <p className="text-xs text-gray-400 mt-0.5">{subtitle}</p>}
          </div>
        </div>
        {action}
      </div>
      <div className="px-5 pb-5">{children}</div>
    </div>
  );
}

// ─── Dashboard ───────────────────────────────────────────────────────────────
export default function Dashboard() {
  const { user } = useAuth();
  const [now, setNow] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, []);

  // Queries
  const { data: assets = [] }      = useQuery({ queryKey:["assets"],       queryFn:()=>fetch("/api/assets",       {credentials:"include"}).then(r=>r.json()), staleTime:120_000 });
  const { data: activities = [] }  = useQuery({ queryKey:["activities"],   queryFn:()=>fetch("/api/activities",   {credentials:"include"}).then(r=>r.json()), staleTime:2000, refetchInterval:5000 });
  const { data: licenses = [] }    = useQuery({ queryKey:["licenses"],     queryFn:()=>fetch("/api/licenses",     {credentials:"include"}).then(r=>r.json()), staleTime:300_000 });
  const { data: iamAccounts = [] } = useQuery({ queryKey:["iam-accounts"], queryFn:()=>fetch("/api/iam-accounts", {credentials:"include"}).then(r=>r.json()), staleTime:180_000 });
  const { data: vmInventory = [] } = useQuery({ queryKey:["vm-inventory"], queryFn:()=>fetch("/api/vm-inventory", {credentials:"include"}).then(r=>r.json()), staleTime:180_000 });

  // Asset metrics
  const totalAssets     = assets.length;
  const deployedAssets  = assets.filter((a:any) => a.status === "Deployed").length;
  const onHandAssets    = assets.filter((a:any) => a.status === "On-Hand").length;
  const pendingAssets   = assets.filter((a:any) => a.status === "pending" || a.status === "On-Hand").length;
  const badCondition    = assets.filter((a:any) => a.condition === "Bad").length;
  const retiredAssets   = assets.filter((a:any) => a.status === "retired" || a.status === "disposed").length;
  const utilizationRate = totalAssets > 0 ? Math.round((deployedAssets / totalAssets) * 100) : 0;
  const availabilityRate= totalAssets > 0 ? Math.round((onHandAssets   / totalAssets) * 100) : 0;

  const expiringSoon = licenses.filter((l:any) => {
    if (!l.expiryDate) return false;
    const exp = new Date(l.expiryDate), lim = new Date();
    lim.setDate(lim.getDate() + 30); return exp <= lim;
  }).length;

  // VM metrics
  const calcVMStatus = (start:string, end:string, cur:string) => {
    if (cur==="Overdue - Notified" || cur==="Decommissioned") return cur;
    if (!start || !end) return "Active";
    const n=new Date(), s=new Date(start), e=new Date(end);
    return n>=s&&n<=e ? "Active" : n>e ? "Overdue - Not Notified" : "Active";
  };
  const processedVMs = vmInventory.map((v:any) => ({...v, vmStatus:calcVMStatus(v.startDate,v.endDate,v.vmStatus)}));
  const totalVMs = processedVMs.length;

  // IAM metrics
  const today = useMemo(()=>{ const d=new Date(); d.setHours(0,0,0,0); return d; },[]);
  const totalIAM   = iamAccounts.length;
  const activeIAM  = iamAccounts.filter((a:any)=>a.status==="active").length;
  const extendedIAM= iamAccounts.filter((a:any)=>a.status==="extended").length;
  const expNotifiedIAM = iamAccounts.filter((a:any)=>{
    const hasSt=a.status==="expired_notified"||a.status==="expired";
    const isDExp=a.durationEndDate&&new Date(a.durationEndDate)<today;
    return hasSt||(isDExp&&a.status==="expired_notified");
  }).length;
  const expNotNotifiedIAM = iamAccounts.filter((a:any)=>{
    if(!a.durationEndDate) return false;
    const end=new Date(a.durationEndDate); end.setHours(0,0,0,0);
    const notYet=a.status!=="expired_notified"&&a.status!=="access_removed"&&a.status!=="extended"&&a.status!=="active";
    return end<today&&(a.status==="expired_not_notified"||notYet);
  }).length;
  const accessRemovedIAM = iamAccounts.filter((a:any)=>a.status==="access_removed").length;

  // Charts
  const statusPieData = useMemo(()=>{
    const c:Record<string,number>={};
    assets.forEach((a:any)=>{ c[a.status]=(c[a.status]||0)+1; });
    return Object.entries(c).map(([name,value])=>({name,value})).filter(d=>d.value>0);
  },[assets]);

  const categoryBarData = useMemo(()=>{
    const c:Record<string,number>={};
    assets.forEach((a:any)=>{ const cat=a.category||"Other"; c[cat]=(c[cat]||0)+1; });
    return Object.entries(c).map(([name,value])=>({name, value: Number(value)}))
      .sort((a,b)=>b.value-a.value).slice(0,6);
  },[assets]);

  const recentActivities = useMemo(()=>
    [...activities].sort((a:any,b:any)=>new Date(b.timestamp).getTime()-new Date(a.timestamp).getTime()).slice(0,8),
    [activities]);

  const ACTION_DOT:Record<string,string>={create:"bg-emerald-400",update:"bg-blue-400",delete:"bg-red-400",checkout:"bg-violet-400",checkin:"bg-teal-400"};

  const greeting = now.getHours()<12?"Good morning":now.getHours()<17?"Good afternoon":"Good evening";

  return (
    <div className="-m-6 min-h-screen bg-gray-50 dark:bg-gray-950">
      <div className="p-6 space-y-6">

        {/* ── 1. Hero Banner ── */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#0f172a] via-[#1e3a5f] to-[#0f2849] p-6 text-white shadow-xl">
          <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
          <div className="absolute bottom-0 left-1/3 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl translate-y-1/2" />
          <div className="relative flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <p className="text-blue-300 text-xs font-medium mb-1">
                {format(now,"EEEE, MMMM d, yyyy")} · {format(now,"hh:mm:ss a")}
              </p>
              <h1 className="text-2xl sm:text-3xl font-bold !text-white" style={{ color: '#ffffff' }}>{greeting}, {user?.firstName||user?.username||"User"} 👋</h1>
              <p className="mt-1 text-blue-200/70 text-sm">Here's what's happening in your IT infrastructure today.</p>
            </div>
            <div className="flex flex-wrap gap-3">
              {[
                {label:"Total Assets", value:totalAssets,    bg:"bg-white/10 border-white/10",     text:"text-white",        sub:"text-blue-200/70"},
                {label:"Deployed",     value:deployedAssets, bg:"bg-emerald-500/20 border-emerald-400/20", text:"text-emerald-300",  sub:"text-emerald-200/70"},
                {label:"On-Hand",      value:onHandAssets,   bg:"bg-amber-500/20 border-amber-400/20",    text:"text-amber-300",    sub:"text-amber-200/70"},
              ].map(b=>(
                <div key={b.label} className={`rounded-xl ${b.bg} border px-4 py-2 text-center min-w-[80px] backdrop-blur-sm`}>
                  <p className={`text-2xl font-bold ${b.text}`}>{b.value}</p>
                  <p className={`text-xs ${b.sub} mt-0.5`}>{b.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── 2. KPI Cards ── */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <StatCard label="Total IT Assets"   value={totalAssets}        sub={`${deployedAssets} currently deployed`}     icon={Laptop}  gradient={["#3b82f6","#1d4ed8"]} href="/assets" />
          <StatCard label="Asset Utilization" value={`${utilizationRate}%`} sub={`${totalAssets-deployedAssets} available`} icon={Gauge}   gradient={["#10b981","#047857"]} href="/assets" />
          <StatCard label="Licenses Expiring" value={expiringSoon}        sub="Next 30 days"                               icon={Shield}  gradient={["#f59e0b","#b45309"]} href="/licenses" />
          <StatCard label="VM Inventory"      value={totalVMs}            sub={`${processedVMs.filter((v:any)=>v.vmStatus==="Active").length} active`} icon={Server} gradient={["#8b5cf6","#5b21b6"]} href="/vm-inventory" />
        </div>

        {/* ── 3. Operational Status Cards ── */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <OperationalCard
            title="Assets Ready for Deploy" desc="Available assets ready to checkout"
            value={onHandAssets} note="Ready for deployment"
            icon={Package} iconColor="text-blue-600" borderColor="border-l-blue-500"
            href="/assets?statusFilter=On-Hand"
          />
          <OperationalCard
            title="Assets Needing Attention" desc="Assets with bad condition requiring review"
            value={badCondition} note="Bad condition — requires attention"
            icon={Wrench} iconColor="text-yellow-600" borderColor="border-l-yellow-500"
            href="/assets?conditionFilter=Bad"
          />
          <OperationalCard
            title="Active Deployments" desc="Currently deployed across departments"
            value={deployedAssets} note="Deployed across departments"
            icon={Target} iconColor="text-blue-600" borderColor="border-l-blue-500"
            href="/assets?statusFilter=Deployed"
          />
        </div>

        {/* ── 4. IT Management Quick Actions ── */}
        <Section title="IT Management Actions" subtitle="Quick access to common IT operations" icon={Briefcase} iconColor="text-blue-500">
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
            <QuickAction label="Deploy Asset" icon={Plus}        href="/assets?action=deploy"      colorClass="bg-blue-100 dark:bg-blue-900/40 text-blue-600" />
            <QuickAction label="Check In"     icon={CheckCircle} href="/assets?status=deployed"    colorClass="bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600" />
            <QuickAction label="Licenses"     icon={Shield}      href="/licenses"                  colorClass="bg-violet-100 dark:bg-violet-900/40 text-violet-600" />
            <QuickAction label="IT Reports"   icon={BarChart3}   href="/reports"                   colorClass="bg-red-100 dark:bg-red-900/40 text-red-600" />
            <QuickAction label="Users"        icon={Users}       href="/users"                     colorClass="bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600" />
            <QuickAction label="Activities"   icon={Activity}    href="/activities"                colorClass="bg-teal-100 dark:bg-teal-900/40 text-teal-600" />
            <QuickAction label="VM Inventory" icon={Server}      href="/vm-inventory"              colorClass="bg-orange-100 dark:bg-orange-900/40 text-orange-600" />
            <QuickAction label="Trends"       icon={TrendingUp}  href="/monthly-trends-report"     colorClass="bg-pink-100 dark:bg-pink-900/40 text-pink-600" />
          </div>
        </Section>

        {/* ── 5. Asset Distribution Analysis (Redesigned) + Activity ── */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

          {/* Premium Distribution Panel */}
          <div className="lg:col-span-2 self-start rounded-2xl overflow-hidden border border-gray-200 dark:border-white/5 shadow-sm bg-white dark:bg-white/5">
            {/* Gradient Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-5 py-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-bold text-white text-base">Asset Distribution Analysis</h2>
                  <p className="text-blue-100/70 text-xs mt-0.5">Live breakdown across all categories</p>
                </div>
                <Link href="/assets">
                  <button className="text-xs bg-white/15 hover:bg-white/25 text-white px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors font-medium">
                    View All <ChevronRight className="h-3 w-3" />
                  </button>
                </Link>
              </div>
              {/* Summary pills */}
              <div className="flex flex-wrap gap-2 mt-3">
                {[
                  {label:"Total", value:totalAssets,    color:"bg-white/20"},
                  {label:"Deployed", value:deployedAssets, color:"bg-emerald-400/30"},
                  {label:"On-Hand",  value:onHandAssets,   color:"bg-amber-400/30"},
                  {label:"Bad Cond.",value:badCondition,   color:"bg-red-400/30"},
                ].map(p=>(
                  <div key={p.label} className={`${p.color} rounded-lg px-2.5 py-1 flex items-center gap-1.5`}>
                    <span className="text-white/70 text-[10px]">{p.label}</span>
                    <span className="text-white font-bold text-sm">{p.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Chart Body */}
            <div className="p-5">
              {categoryBarData.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                  {/* Horizontal progress bars — left */}
                  <div className="space-y-3">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-3">By Category</p>
                    {categoryBarData.map((d,i)=>{
                      const pct = totalAssets > 0 ? Math.round((d.value/totalAssets)*100) : 0;
                      return (
                        <div key={d.name}>
                          <div className="flex items-center justify-between mb-1.5">
                            <div className="flex items-center gap-2">
                              <div className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                                   style={{backgroundColor:PIE_COLORS[i%PIE_COLORS.length]}} />
                              <span className="text-sm font-semibold text-gray-800 dark:text-gray-200">{d.name}</span>
                            </div>
                            <div className="flex items-center gap-3">
                              <span className="text-sm font-bold text-gray-900 dark:text-gray-100">{d.value}</span>
                              <span className="text-xs text-gray-400 w-9 text-right">{pct}%</span>
                            </div>
                          </div>
                          <div className="h-2.5 bg-gray-100 dark:bg-white/10 rounded-full overflow-hidden">
                            <div className="h-full rounded-full transition-all duration-700"
                                 style={{width:`${pct}%`, backgroundColor:PIE_COLORS[i%PIE_COLORS.length]}} />
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Donut chart + legend — right */}
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-3">By Status</p>
                    {/* Chart at fixed height, pinned to top */}
                    <div style={{height:"140px"}}>
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={statusPieData.length > 0 ? statusPieData : [{name:"No data",value:1}]}
                            cx="50%" cy="50%"
                            innerRadius={38} outerRadius={58}
                            paddingAngle={statusPieData.length > 1 ? 3 : 0}
                            dataKey="value" startAngle={90} endAngle={-270}
                          >
                            {(statusPieData.length > 0 ? statusPieData : [{name:"No data",value:1}]).map((_,i)=>(
                              <Cell key={i}
                                fill={statusPieData.length > 0 ? PIE_COLORS[i%PIE_COLORS.length] : "#e5e7eb"}
                                stroke="none" />
                            ))}
                          </Pie>
                          <Tooltip contentStyle={{borderRadius:"10px",border:"none",boxShadow:"0 4px 24px rgba(0,0,0,0.1)"}} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    {/* Legend directly below — no gap */}
                    <div className="mt-2 space-y-1.5">
                      {statusPieData.map((d,i)=>(
                        <div key={d.name} className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <div className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                                 style={{backgroundColor:PIE_COLORS[i%PIE_COLORS.length]}} />
                            <span className="text-gray-600 dark:text-gray-400">{d.name}</span>
                          </div>
                          <span className="font-bold text-gray-800 dark:text-gray-200">{d.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="h-32 flex items-center justify-center">
                  <div className="text-center">
                    <Package className="h-10 w-10 text-gray-200 mx-auto mb-2" />
                    <p className="text-sm text-gray-400">No assets yet</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Activity Feed */}
          <div className="rounded-2xl bg-white dark:bg-white/5 border border-gray-200 dark:border-white/5 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Activity className="h-4 w-4 text-blue-500" />
                <h2 className="font-semibold text-sm text-gray-800 dark:text-gray-100">Recent IT Operations</h2>
              </div>
              <Link href="/activities"><button className="text-xs text-blue-500 hover:text-blue-600 flex items-center gap-1 font-medium">View all <ChevronRight className="h-3 w-3" /></button></Link>
            </div>
            <div className="space-y-2">
              {recentActivities.length > 0 ? recentActivities.map((act:any,i:number)=>{
                const dot=ACTION_DOT[act.action]??"bg-gray-300";
                const label=(act.action??"").charAt(0).toUpperCase()+(act.action??"").slice(1);
                return (
                  <div key={i} className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-gray-50 dark:hover:bg-white/5 transition-colors">
                    <div className={`mt-1.5 flex-shrink-0 w-2 h-2 rounded-full ${dot}`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-gray-700 dark:text-gray-200 truncate">
                        <span className="font-medium">[{label}]</span>{" "}{act.notes||`${label} on ${act.itemType}`}
                      </p>
                      <p className="text-xs text-gray-400 mt-0.5">{act.itemType} · {format(new Date(act.timestamp),"MMM d, HH:mm")}</p>
                    </div>
                  </div>
                );
              }) : (
                <div className="py-8 text-center">
                  <Activity className="h-8 w-8 text-gray-200 dark:text-gray-700 mx-auto mb-2" />
                  <p className="text-sm text-gray-400">No recent activities</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ── 6. VM Inventory Status Overview ── */}
        <div className="rounded-2xl bg-white dark:bg-white/5 border border-gray-200 dark:border-white/5 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-5">
            <Server className="h-5 w-5 text-blue-600" />
            <div>
              <h2 className="font-semibold text-gray-800 dark:text-gray-100">VM Inventory Status Overview</h2>
              <p className="text-xs text-gray-400 mt-0.5">Virtual machine status breakdown and lifecycle management</p>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {[
              {label:"Total VMs",             value:processedVMs.length,                                                          icon:Server,        bg:"bg-gray-50 hover:bg-gray-100 dark:bg-white/5 dark:hover:bg-white/10",     iconBg:"bg-blue-100 dark:bg-blue-950",   iconColor:"text-blue-600",               href:"/vm-inventory"},
              {label:"Active",                value:processedVMs.filter((v:any)=>v.vmStatus==="Active").length,                   icon:CheckCircle,   bg:"bg-green-50 hover:bg-green-100 dark:bg-green-950 dark:hover:bg-green-900", iconBg:"bg-green-100 dark:bg-green-900", iconColor:"text-green-600",               href:"/vm-inventory?statusFilter=Active"},
              {label:"Overdue - Notified",    value:processedVMs.filter((v:any)=>v.vmStatus==="Overdue - Notified").length,       icon:AlertTriangle, bg:"bg-orange-50 hover:bg-orange-100 dark:bg-orange-950",                    iconBg:"bg-orange-100 dark:bg-orange-900",iconColor:"text-orange-600",             href:"/vm-inventory?statusFilter=Overdue - Notified"},
              {label:"Overdue - Not Notified",value:processedVMs.filter((v:any)=>v.vmStatus==="Overdue - Not Notified").length,   icon:XCircle,       bg:"bg-red-50 hover:bg-red-100 dark:bg-red-950",                             iconBg:"bg-red-100 dark:bg-red-900",     iconColor:"text-red-600",                href:"/vm-inventory?statusFilter=Overdue - Not Notified"},
              {label:"Decommissioned",        value:processedVMs.filter((v:any)=>v.vmStatus==="Decommissioned").length,           icon:Database,      bg:"bg-gray-50 hover:bg-gray-100 dark:bg-gray-800 dark:hover:bg-gray-700",   iconBg:"bg-gray-100 dark:bg-gray-700",   iconColor:"text-gray-600 dark:text-gray-400",href:"/vm-inventory?statusFilter=Decommissioned"},
            ].map(tile=>(
              <div key={tile.label} className={`text-center cursor-pointer transition-transform hover:scale-105 p-4 rounded-xl ${tile.bg}`} onClick={()=>window.location.href=tile.href}>
                <div className={`w-12 h-12 ${tile.iconBg} rounded-full flex items-center justify-center mx-auto mb-3`}>
                  <tile.icon className={`h-6 w-6 ${tile.iconColor}`} />
                </div>
                <div className={`text-2xl font-bold ${tile.iconColor} mb-1`}>{tile.value}</div>
                <p className="text-sm text-gray-600 dark:text-gray-400">{tile.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* ── 7. IAM Accounts Status Overview ── */}
        <div className="rounded-2xl bg-white dark:bg-white/5 border border-gray-200 dark:border-white/5 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-5">
            <Shield className="h-5 w-5 text-blue-600" />
            <div>
              <h2 className="font-semibold text-gray-800 dark:text-gray-100">IAM Accounts Status Overview</h2>
              <p className="text-xs text-gray-400 mt-0.5">Identity and Access Management accounts status breakdown</p>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {[
              {label:"Total Accounts",       value:totalIAM,           icon:Shield,       bg:"bg-gray-50 hover:bg-gray-100 dark:bg-white/5",    iconBg:"bg-blue-100 dark:bg-blue-950",   iconColor:"text-blue-600",    href:"/iam-accounts"},
              {label:"Active",               value:activeIAM,          icon:CheckCircle,  bg:"bg-green-50 hover:bg-green-100 dark:bg-green-950", iconBg:"bg-green-100 dark:bg-green-900", iconColor:"text-green-600",   href:"/iam-accounts?statusFilter=active"},
              {label:"Extended",             value:extendedIAM,        icon:RotateCcw,    bg:"bg-blue-50 hover:bg-blue-100 dark:bg-blue-950",    iconBg:"bg-blue-100 dark:bg-blue-900",   iconColor:"text-blue-600",    href:"/iam-accounts?statusFilter=extended"},
              {label:"Expired - Notified",   value:expNotifiedIAM,     icon:AlertTriangle,bg:"bg-red-50 hover:bg-red-100 dark:bg-red-950",       iconBg:"bg-red-100 dark:bg-red-900",     iconColor:"text-red-600",     href:"/iam-accounts?statusFilter=expired_notified"},
              {label:"Expired - Not Notified",value:expNotNotifiedIAM, icon:AlertTriangle,bg:"bg-yellow-50 hover:bg-yellow-100 dark:bg-yellow-950",iconBg:"bg-yellow-100 dark:bg-yellow-900",iconColor:"text-yellow-600",href:"/iam-accounts?statusFilter=expired_not_notified"},
              {label:"Access Removed",       value:accessRemovedIAM,   icon:XCircle,      bg:"bg-orange-50 hover:bg-orange-100 dark:bg-orange-950",iconBg:"bg-orange-100 dark:bg-orange-900",iconColor:"text-orange-600",href:"/iam-accounts?statusFilter=access_removed"},
            ].map(tile=>(
              <div key={tile.label} className={`text-center cursor-pointer transition-transform hover:scale-105 p-4 rounded-xl ${tile.bg}`} onClick={()=>window.location.href=tile.href}>
                <div className={`w-12 h-12 ${tile.iconBg} rounded-full flex items-center justify-center mx-auto mb-3`}>
                  <tile.icon className={`h-6 w-6 ${tile.iconColor}`} />
                </div>
                <div className={`text-2xl font-bold ${tile.iconColor} mb-1`}>{tile.value}</div>
                <p className="text-sm text-gray-600 dark:text-gray-400">{tile.label}</p>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}