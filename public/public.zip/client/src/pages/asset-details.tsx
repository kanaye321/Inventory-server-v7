import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { QRCodeSVG } from "qrcode.react";
import {
  ArrowLeftIcon,
  BadgeIcon,
  Edit2Icon,
  TrashIcon,
  HistoryIcon,
  BoxIcon,
  CalendarIcon,
  DollarSignIcon,
  KeyIcon,
  MapPinIcon,
  MonitorIcon,
  NetworkIcon,
  HashIcon,
  HardDriveIcon,
  BuildingIcon,
  FileTextIcon,
  UserIcon,
  QrCodeIcon,
  ServerIcon,
  CreditCardIcon,
  PackageOpen,
  Package,
  PencilIcon,
  PlusCircleIcon,
  AlertTriangleIcon,
  CheckCircle2Icon,
  XCircleIcon,
  ClockIcon,
  FilterIcon,
  RefreshCwIcon,
  TrendingUpIcon,
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { formatDate, getStatusColor } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { DeleteConfirmationDialog } from "@/components/ui/delete-confirmation-dialog";
import { Asset, User, AssetStatus } from "@shared/schema";
import AssetForm from "@/components/assets/asset-form";
import CheckoutForm from "@/components/assets/checkout-form";
import CheckinForm from "@/components/assets/checkin-form";

// ─── History action config ──────────────────────────────────────────────────
const ACTION_CONFIG: Record<string, {
  label: string;
  Icon: React.ElementType;
  bgColor: string;
  textColor: string;
  badgeClass: string;
}> = {
  create:   { label: "Created",    Icon: PlusCircleIcon,   bgColor: "bg-purple-100 dark:bg-purple-900/40", textColor: "text-purple-600 dark:text-purple-400", badgeClass: "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300" },
  update:   { label: "Updated",    Icon: PencilIcon,       bgColor: "bg-amber-100 dark:bg-amber-900/40",   textColor: "text-amber-600 dark:text-amber-400",   badgeClass: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300" },
  checkout: { label: "Checked Out",Icon: PackageOpen,      bgColor: "bg-blue-100 dark:bg-blue-900/40",     textColor: "text-blue-600 dark:text-blue-400",     badgeClass: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300" },
  checkin:  { label: "Checked In", Icon: Package,          bgColor: "bg-green-100 dark:bg-green-900/40",   textColor: "text-green-600 dark:text-green-400",   badgeClass: "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300" },
  delete:   { label: "Deleted",    Icon: XCircleIcon,      bgColor: "bg-red-100 dark:bg-red-900/40",       textColor: "text-red-600 dark:text-red-400",       badgeClass: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300" },
  default:  { label: "Action",     Icon: HistoryIcon,      bgColor: "bg-gray-100 dark:bg-gray-800",        textColor: "text-gray-600 dark:text-gray-400",     badgeClass: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300" },
};

function getActionConfig(action: string) {
  return ACTION_CONFIG[action] ?? ACTION_CONFIG.default;
}

function formatTimestamp(raw?: string | null): string {
  if (!raw) return "—";
  try {
    const d = new Date(raw);
    return d.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  } catch {
    return raw;
  }
}

function timeAgo(raw?: string | null): string {
  if (!raw) return "";
  try {
    const diff = Date.now() - new Date(raw).getTime();
    const mins  = Math.floor(diff / 60000);
    const hours = Math.floor(mins / 60);
    const days  = Math.floor(hours / 24);
    if (days > 0)  return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (mins > 0)  return `${mins}m ago`;
    return "Just now";
  } catch {
    return "";
  }
}

// ─── Main component ─────────────────────────────────────────────────────────
export default function AssetDetails() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isCheckoutDialogOpen, setIsCheckoutDialogOpen] = useState(false);
  const [isCheckinDialogOpen, setIsCheckinDialogOpen] = useState(false);
  const [historyFilter, setHistoryFilter] = useState<string>("all");

  // ── Data fetching ───────────────────────────────────────────────────────────
  const { data: asset, isLoading, isError, error } = useQuery<Asset>({
    queryKey: [`/api/assets/${id}`],
    queryFn: async () => {
      const res = await fetch(`/api/assets/${id}`, { credentials: "include" });
      if (!res.ok) {
        if (res.status === 401) throw new Error("Authentication required");
        throw new Error("Failed to fetch asset");
      }
      return res.json();
    },
    retry: (failureCount, error: any) => {
      if (error?.message === "Authentication required") return false;
      return failureCount < 3;
    },
  });

  const { data: activities, isLoading: isActivitiesLoading, refetch: refetchActivities } = useQuery({
    queryKey: [`/api/assets/${id}/activities`],
    queryFn: async () => {
      const res = await fetch(`/api/assets/${id}/activities`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch activities");
      return res.json();
    },
    enabled: !!asset,
  });

  const { data: assignedUser, isLoading: isUserLoading } = useQuery<User>({
    queryKey: [`/api/users/${asset?.assignedTo}`],
    queryFn: async () => {
      const res = await fetch(`/api/users/${asset?.assignedTo}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch user");
      return res.json();
    },
    enabled: !!asset?.assignedTo,
  });

  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const res = await fetch("/api/users", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch users");
      return res.json();
    },
  });

  const getUserName = (userId?: number | null) => {
    if (!userId || !users) return "System";
    const user = users.find((u) => u.id === userId);
    return user ? `${user.firstName} ${user.lastName}` : "Unknown User";
  };

  // ── Mutations ───────────────────────────────────────────────────────────────
  const updateAssetMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("PATCH", `/api/assets/${id}`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/assets/${id}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/assets"] });
      queryClient.invalidateQueries({ queryKey: [`/api/assets/${id}/activities`] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.refetchQueries({ queryKey: [`/api/assets/${id}`] });
      setIsEditDialogOpen(false);
      toast({ title: "Asset updated", description: "The asset has been updated successfully." });
    },
    onError: (error) => toast({ title: "Error", description: error.message || "Failed to update asset", variant: "destructive" }),
  });

  const deleteAssetMutation = useMutation({
    mutationFn: async () => { await apiRequest("DELETE", `/api/assets/${id}`); },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      navigate("/assets");
      toast({ title: "Asset deleted", description: "The asset has been deleted successfully." });
    },
    onError: (error) => toast({ title: "Error", description: error.message || "Failed to delete asset", variant: "destructive" }),
  });

  const checkoutAssetMutation = useMutation({
    mutationFn: async (data: { userId: number; knoxId?: string; firstName?: string; lastName?: string; expectedCheckinDate?: string }) => {
      const response = await apiRequest("POST", `/api/assets/${id}/checkout`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/assets/${id}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/assets"] });
      queryClient.invalidateQueries({ queryKey: [`/api/assets/${id}/activities`] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      setIsCheckoutDialogOpen(false);
      toast({ title: "Asset checked out", description: "The asset has been checked out successfully." });
    },
    onError: (error) => toast({ title: "Error", description: error.message || "Failed to check out asset", variant: "destructive" }),
  });

  const checkinAssetMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/assets/${id}/checkin`);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/assets/${id}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/assets"] });
      queryClient.invalidateQueries({ queryKey: [`/api/assets/${id}/activities`] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      setIsCheckinDialogOpen(false);
      toast({ title: "Asset checked in", description: "The asset has been checked in successfully." });
    },
    onError: (error) => toast({ title: "Error", description: error.message || "Failed to check in asset", variant: "destructive" }),
  });

  const updateFinanceMutation = useMutation({
    mutationFn: async (financeUpdated: boolean) => {
      const response = await apiRequest("POST", `/api/assets/${id}/finance`, { financeUpdated });
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/assets/${id}`] });
      toast({ title: "Finance status updated", description: "The finance status has been updated successfully." });
    },
    onError: (error) => toast({ title: "Error", description: error.message || "Failed to update finance status", variant: "destructive" }),
  });

  // ── Loading / error states ──────────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-gray-500">Loading asset details...</p>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="text-red-500 text-4xl mb-4">⚠️</div>
          <h2 className="text-xl font-semibold mb-2">Error Loading Asset</h2>
          <p className="text-gray-500 mb-4">{error?.message || "Failed to load asset details"}</p>
          <Button onClick={() => navigate("/assets")}>
            <ArrowLeftIcon className="mr-2 h-4 w-4" /> Back to Assets
          </Button>
        </div>
      </div>
    );
  }

  if (!asset) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="text-gray-500 text-4xl mb-4">🔍</div>
          <h2 className="text-xl font-semibold mb-2">Asset Not Found</h2>
          <p className="text-gray-500 mb-4">The asset you're looking for doesn't exist or has been removed.</p>
          <Button onClick={() => navigate("/assets")}>
            <ArrowLeftIcon className="mr-2 h-4 w-4" /> Back to Assets
          </Button>
        </div>
      </div>
    );
  }

  // ── Derived state ───────────────────────────────────────────────────────────
  // Deployed = status is Deployed OR overdue (string literal since OVERDUE is not in the enum)
  const isDeployed = asset.status === AssetStatus.DEPLOYED || asset.status === 'overdue';
  // deployedAt → checkoutDate → updatedAt (last resort for imported/Knox assets with no tracked date)
  const deployedDate = (asset as any).deployedAt
    || asset.checkoutDate
    || (isDeployed ? asset.updatedAt : null);

  // ── History data ─────────────────────────────────────────────────────────
  const allActivities: any[] = Array.isArray(activities) ? activities : [];
  const filteredActivities = historyFilter === "all"
    ? allActivities
    : allActivities.filter((a: any) => a.action === historyFilter);

  const actionCounts = allActivities.reduce((acc: Record<string, number>, a: any) => {
    acc[a.action] = (acc[a.action] || 0) + 1;
    return acc;
  }, {});

  const filterButtons = [
    { key: "all",      label: `All (${allActivities.length})` },
    { key: "create",   label: `Created (${actionCounts.create || 0})` },
    { key: "update",   label: `Updated (${actionCounts.update || 0})` },
    { key: "checkout", label: `Checked Out (${actionCounts.checkout || 0})` },
    { key: "checkin",  label: `Checked In (${actionCounts.checkin || 0})` },
  ].filter((b) => b.key === "all" || (actionCounts[b.key] || 0) > 0);

  const firstActivity = allActivities.length ? allActivities[allActivities.length - 1] : null;
  const lastActivity  = allActivities.length ? allActivities[0] : null;

  // ── Render ───────────────────────────────────────────────────────────────
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3">
          <Button variant="outline" size="icon" onClick={() => navigate("/assets")}>
            <ArrowLeftIcon className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">
              {asset.name}
            </h1>
            <p className="text-sm text-gray-500">Tag: {asset.assetTag}</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {isDeployed ? (
            <Button onClick={() => setIsCheckinDialogOpen(true)}>
              <BoxIcon className="mr-2 h-4 w-4" /> Check In
            </Button>
          ) : (
            <Button onClick={() => setIsCheckoutDialogOpen(true)}>
              <BoxIcon className="mr-2 h-4 w-4" /> Check Out
            </Button>
          )}
          <Button variant="outline" onClick={() => setIsEditDialogOpen(true)}>
            <Edit2Icon className="mr-2 h-4 w-4" /> Edit
          </Button>
          <Button
            variant="outline"
            className="text-red-500 hover:bg-red-50 hover:text-red-600"
            onClick={() => setIsDeleteDialogOpen(true)}
          >
            <TrashIcon className="mr-2 h-4 w-4" /> Delete
          </Button>
        </div>
      </div>

      <Tabs defaultValue="details">
        <TabsList>
          <TabsTrigger value="details">Details</TabsTrigger>
          <TabsTrigger value="history">
            History
            {allActivities.length > 0 && (
              <span className="ml-1.5 inline-flex items-center justify-center rounded-full bg-primary/15 px-1.5 py-0.5 text-[10px] font-semibold text-primary">
                {allActivities.length}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        {/* ── Details Tab ─────────────────────────────────────────────── */}
        <TabsContent value="details" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Main info */}
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="text-lg">Asset Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Status</p>
                    <Badge className={getStatusColor(asset.status)}>
                      {asset.status.charAt(0).toUpperCase() + asset.status.slice(1)}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Condition</p>
                    <Badge className={asset.condition === "Good" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                      {asset.condition}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Category</p>
                    <p>{asset.category}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Asset Tag</p>
                    <div className="flex items-center">
                      <HashIcon className="h-4 w-4 text-gray-400 mr-1" />
                      <p>{asset.assetTag}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Serial Number</p>
                    <p>{asset.serialNumber || "—"}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Model</p>
                    <div className="flex items-center">
                      <HardDriveIcon className="h-4 w-4 text-gray-400 mr-1" />
                      <p>{asset.model || "—"}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Manufacturer</p>
                    <div className="flex items-center">
                      <BuildingIcon className="h-4 w-4 text-gray-400 mr-1" />
                      <p>{asset.manufacturer || "—"}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Purchase Date</p>
                    <div className="flex items-center">
                      <CalendarIcon className="h-4 w-4 text-gray-400 mr-1" />
                      <p>{formatDate(asset.purchaseDate) || "—"}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Purchase Cost</p>
                    <div className="flex items-center">
                      <DollarSignIcon className="h-4 w-4 text-gray-400 mr-1" />
                      <p>{asset.purchaseCost || "—"}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Location</p>
                    <div className="flex items-center">
                      <MapPinIcon className="h-4 w-4 text-gray-400 mr-1" />
                      <p>{asset.location || "—"}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Department</p>
                    <p>{asset.department || "—"}</p>
                  </div>
                </div>

                <Separator />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                  {isDeployed && asset.knoxId && (
                    <div>
                      <p className="text-sm font-medium text-gray-500">Knox ID</p>
                      <div className="flex items-center">
                        <KeyIcon className="h-4 w-4 text-gray-400 mr-1" />
                        <p>{asset.knoxId}</p>
                      </div>
                    </div>
                  )}
                  <div>
                    <p className="text-sm font-medium text-gray-500">IP Address</p>
                    <div className="flex items-center">
                      <NetworkIcon className="h-4 w-4 text-gray-400 mr-1" />
                      <p>{asset.ipAddress || "—"}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">MAC Address</p>
                    <div className="flex items-center">
                      <ServerIcon className="h-4 w-4 text-gray-400 mr-1" />
                      <p>{asset.macAddress || "—"}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">OS Type</p>
                    <div className="flex items-center">
                      <MonitorIcon className="h-4 w-4 text-gray-400 mr-1" />
                      <p>{asset.osType || "—"}</p>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <p className="text-sm font-medium text-gray-500 mb-2">Notes</p>
                  <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-md min-h-[80px]">
                    <p className="text-sm whitespace-pre-wrap">{asset.notes || "No notes available."}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Sidebar */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Assignment & Tools</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* ── Fix: show deployment info whenever isDeployed,
                     regardless of whether assignedTo is set ── */}
                {isDeployed ? (
                  <>
                    {/* Deployed status card */}
                    <div className="rounded-lg border border-blue-200 bg-blue-50 dark:bg-blue-950/30 dark:border-blue-800 p-4 space-y-3">
                      <div className="flex items-center gap-2">
                        <div className="h-7 w-7 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                          <CheckCircle2Icon className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                        </div>
                        <span className="font-semibold text-blue-800 dark:text-blue-300 text-sm">
                          Currently Deployed
                        </span>
                      </div>

                      {/* Knox ID */}
                      {asset.knoxId ? (
                        <div className="flex items-center gap-2">
                          <KeyIcon className="h-3.5 w-3.5 text-blue-500 flex-shrink-0" />
                          <span className="text-xs text-blue-600 dark:text-blue-400 font-medium">Knox ID:</span>
                          <Badge className="bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300 border-0 text-xs">
                            {asset.knoxId}
                          </Badge>
                        </div>
                      ) : (
                        <p className="text-xs text-blue-500 italic">No Knox ID assigned</p>
                      )}

                      {/* Assigned user (if exists) */}
                      {isUserLoading ? (
                        <div className="animate-pulse h-5 bg-blue-100 rounded" />
                      ) : assignedUser ? (
                        <div className="text-xs text-blue-700 dark:text-blue-300 space-y-0.5 border-t border-blue-200 dark:border-blue-700 pt-2">
                          <div className="flex items-center gap-1.5">
                            <UserIcon className="h-3 w-3" />
                            <span className="font-medium">{assignedUser.firstName} {assignedUser.lastName}</span>
                          </div>
                          <p className="text-blue-500 pl-4">{assignedUser.email}</p>
                          {assignedUser.department && (
                            <p className="text-blue-500 pl-4">{assignedUser.department}</p>
                          )}
                        </div>
                      ) : null}
                    </div>

                    {/* Deployed date */}
                    <div>
                      <p className="text-sm font-medium text-gray-500">Deployed Date</p>
                      {deployedDate ? (
                        <p className="text-sm">
                          {formatDate(deployedDate)}
                        </p>
                      ) : (
                        <p className="text-sm text-gray-400">—</p>
                      )}
                    </div>

                    {asset.expectedCheckinDate && (
                      <div>
                        <p className="text-sm font-medium text-gray-500">Expected Return Date</p>
                        <p className="text-sm">{formatDate(asset.expectedCheckinDate)}</p>
                      </div>
                    )}
                  </>
                ) : (
                  /* ── Not deployed ── */
                  <div className="flex flex-col items-center justify-center h-28 text-center rounded-lg border-2 border-dashed border-gray-200 dark:border-gray-700">
                    <BoxIcon className="h-8 w-8 text-gray-300 mb-2" />
                    <p className="text-sm text-gray-500 mb-2">Not currently deployed</p>
                    <Button size="sm" variant="outline" onClick={() => setIsCheckoutDialogOpen(true)}>
                      Check Out
                    </Button>
                  </div>
                )}

                {/* Finance Status */}
                <Separator />
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="finance-updated"
                      checked={asset.financeUpdated || false}
                      onCheckedChange={(checked) => updateFinanceMutation.mutate(!!checked)}
                    />
                    <div className="grid gap-1.5 leading-none">
                      <label
                        htmlFor="finance-updated"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Finance Updated
                      </label>
                      <p className="text-xs text-muted-foreground">
                        Mark when finance department has updated this asset.
                      </p>
                    </div>
                  </div>
                </div>

                {/* QR Code */}
                <Separator />
                <div className="pt-2">
                  <div className="flex items-center mb-2">
                    <QrCodeIcon className="h-4 w-4 text-gray-500 mr-1" />
                    <p className="text-sm font-medium text-gray-500">Asset QR Code</p>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="p-2 bg-white dark:bg-gray-700 rounded border dark:border-gray-600">
                      <QRCodeSVG
                        value={`${window.location.origin}/assets/${id}`}
                        size={120}
                        level="H"
                        includeMargin={true}
                      />
                    </div>
                    <p className="mt-2 text-xs text-gray-500">Scan to view asset details</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ── History Tab ─────────────────────────────────────────────── */}
        <TabsContent value="history" className="space-y-4">
          {/* Stats bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Card className="p-4">
              <p className="text-xs text-muted-foreground">Total Events</p>
              <p className="text-2xl font-bold">{allActivities.length}</p>
            </Card>
            <Card className="p-4">
              <p className="text-xs text-muted-foreground">Checkouts</p>
              <p className="text-2xl font-bold text-blue-600">{actionCounts.checkout || 0}</p>
            </Card>
            <Card className="p-4">
              <p className="text-xs text-muted-foreground">Updates</p>
              <p className="text-2xl font-bold text-amber-600">{actionCounts.update || 0}</p>
            </Card>
            <Card className="p-4">
              <p className="text-xs text-muted-foreground">Last Activity</p>
              <p className="text-sm font-semibold truncate">{lastActivity ? timeAgo(lastActivity.timestamp) : "—"}</p>
            </Card>
          </div>

          {/* Timeline card */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <div className="flex items-center gap-2">
                <HistoryIcon className="h-5 w-5 text-muted-foreground" />
                <CardTitle className="text-lg">Activity Timeline</CardTitle>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => refetchActivities()}
                className="h-8 w-8 p-0"
                title="Refresh"
              >
                <RefreshCwIcon className="h-4 w-4" />
              </Button>
            </CardHeader>

            {/* Filter tabs */}
            <div className="px-6 pb-3 flex flex-wrap gap-1.5 border-b">
              {filterButtons.map((btn) => (
                <button
                  key={btn.key}
                  onClick={() => setHistoryFilter(btn.key)}
                  className={`
                    px-3 py-1 rounded-full text-xs font-medium transition-colors
                    ${historyFilter === btn.key
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"}
                  `}
                >
                  {btn.label}
                </button>
              ))}
            </div>

            <CardContent className="pt-4">
              {isActivitiesLoading ? (
                <div className="space-y-6">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="flex gap-4 animate-pulse">
                      <div className="h-9 w-9 rounded-full bg-muted flex-shrink-0" />
                      <div className="flex-1 space-y-2 pt-1">
                        <div className="h-3 bg-muted rounded w-1/3" />
                        <div className="h-3 bg-muted rounded w-2/3" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : filteredActivities.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-center">
                  <div className="h-14 w-14 rounded-full bg-muted flex items-center justify-center mb-3">
                    <HistoryIcon className="h-7 w-7 text-muted-foreground" />
                  </div>
                  <p className="font-medium text-muted-foreground">No events found</p>
                  <p className="text-sm text-muted-foreground/70 mt-1">
                    {historyFilter === "all"
                      ? "No activity history for this asset yet."
                      : `No "${historyFilter}" events recorded.`}
                  </p>
                </div>
              ) : (
                <ol className="relative border-l-2 border-muted ml-4 space-y-0">
                  {filteredActivities.map((activity: any, idx: number) => {
                    const cfg = getActionConfig(activity.action);
                    const Icon = cfg.Icon;
                    const isLast = idx === filteredActivities.length - 1;

                    return (
                      <li key={activity.id ?? idx} className={`ml-6 ${isLast ? "pb-0" : "pb-7"}`}>
                        {/* Timeline dot */}
                        <span
                          className={`
                            absolute -left-[18px] flex h-9 w-9 items-center justify-center
                            rounded-full ring-4 ring-background ${cfg.bgColor}
                          `}
                        >
                          <Icon className={`h-4 w-4 ${cfg.textColor}`} />
                        </span>

                        {/* Event card */}
                        <div className="rounded-lg border bg-card p-3 shadow-sm">
                          <div className="flex items-start justify-between gap-2 flex-wrap">
                            <div className="flex items-center gap-2">
                              <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold ${cfg.badgeClass}`}>
                                {cfg.label}
                              </span>
                              <span className="text-xs text-muted-foreground">
                                by <span className="font-medium text-foreground">{getUserName(activity.userId)}</span>
                              </span>
                            </div>
                            <div className="flex items-center gap-1 text-xs text-muted-foreground flex-shrink-0">
                              <ClockIcon className="h-3 w-3" />
                              <time title={formatTimestamp(activity.timestamp)}>
                                {timeAgo(activity.timestamp)}
                              </time>
                              <span className="hidden sm:inline">· {formatTimestamp(activity.timestamp)}</span>
                            </div>
                          </div>

                          {activity.notes && (
                            <p className="mt-1.5 text-sm text-muted-foreground leading-snug line-clamp-2">
                              {activity.notes}
                            </p>
                          )}
                        </div>
                      </li>
                    );
                  })}
                </ol>
              )}

              {/* Footer: first activity */}
              {firstActivity && filteredActivities.length > 0 && (
                <div className="mt-6 pt-4 border-t flex items-center gap-2 text-xs text-muted-foreground">
                  <TrendingUpIcon className="h-3.5 w-3.5" />
                  <span>
                    First recorded: <span className="font-medium">{formatTimestamp(firstActivity.timestamp)}</span>
                  </span>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* ── Dialogs ────────────────────────────────────────────────────── */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="w-[95vw] max-w-[95vw] sm:max-w-[620px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Asset</DialogTitle>
          </DialogHeader>
          <AssetForm
            onSubmit={async (data) => {
              const payload = { ...data };
              const knoxIsEmpty  = !payload.knoxId || payload.knoxId.trim() === '';
              const knoxIsFilled = !knoxIsEmpty;
              const wasDeployed  = asset.status === 'Deployed';

              if (wasDeployed && knoxIsEmpty) {
                // ── Knox removed from Deployed → return to On-Hand ──────────
                try { await apiRequest('POST', `/api/assets/${id}/checkin`); } catch (_) {}
                payload.status = 'On-Hand';

              } else if (knoxIsFilled && !wasDeployed) {
                // ── Knox added to non-Deployed asset → promote to Deployed ──
                // Call checkout to stamp checkoutDate = today (real date, not updatedAt guess)
                try {
                  const userRes = await apiRequest('GET', '/api/user');
                  const currentUser = await userRes.json();
                  if (currentUser?.id) {
                    await apiRequest('POST', `/api/assets/${id}/checkout`, {
                      userId: currentUser.id,
                      knoxId: payload.knoxId,
                    });
                  }
                } catch (_) { /* non-fatal */ }
                payload.status = 'Deployed';
              }

              updateAssetMutation.mutate(payload);
            }}
            isLoading={updateAssetMutation.isPending}
            defaultValues={asset}
          />
        </DialogContent>
      </Dialog>

      <DeleteConfirmationDialog
        open={isDeleteDialogOpen}
        onClose={() => setIsDeleteDialogOpen(false)}
        onConfirm={() => deleteAssetMutation.mutate()}
        isLoading={deleteAssetMutation.isPending}
        itemType="asset"
        itemName={asset ? `${asset.name} (${asset.assetTag})` : ""}
      />

      <Dialog open={isCheckoutDialogOpen} onOpenChange={setIsCheckoutDialogOpen}>
        <DialogContent className="w-[95vw] max-w-[95vw] sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Check Out Asset</DialogTitle>
            <DialogDescription>Assign this asset to a user.</DialogDescription>
          </DialogHeader>
          <CheckoutForm
            onSubmit={(data) => checkoutAssetMutation.mutate(data)}
            isLoading={checkoutAssetMutation.isPending}
            assetName={asset.name}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={isCheckinDialogOpen} onOpenChange={setIsCheckinDialogOpen}>
        <DialogContent className="w-[95vw] max-w-[95vw] sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Check In Asset</DialogTitle>
            <DialogDescription>Return this asset to inventory.</DialogDescription>
          </DialogHeader>
          <CheckinForm
            onSubmit={() => checkinAssetMutation.mutate()}
            isLoading={checkinAssetMutation.isPending}
            assetName={asset.name}
            userName={
              assignedUser
                ? `${assignedUser.firstName} ${assignedUser.lastName}`
                : asset.knoxId
                ? `Knox ID: ${asset.knoxId}`
                : "Unknown"
            }
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}