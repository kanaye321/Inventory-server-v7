import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { User, Mail, Phone, MapPin, Calendar, Shield, AlertTriangle, Link as LinkIcon, Camera, Edit3, Key, Check } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useLocation } from "wouter";

export default function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [locationRoute] = useLocation();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [forcePasswordChange, setForcePasswordChange] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const requiresChange = params.get('changePassword') === 'true' || user?.forcePasswordChange === true;
    setForcePasswordChange(requiresChange);
  }, [user, locationRoute]);

  const { data: userData, isLoading } = useQuery({
    queryKey: ['/api/me'],
    queryFn: async () => {
      const response = await fetch('/api/me');
      if (!response.ok) throw new Error('Not authenticated');
      return response.json();
    }
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch('/api/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to update profile');
      }
      return response.json();
    },
    onSuccess: (updatedUser) => {
      setIsEditing(false);
      queryClient.invalidateQueries({ queryKey: ['/api/me'] });
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      queryClient.setQueryData(['/api/me'], { ...userData, user: updatedUser });
      toast({
        title: "Profile Updated",
        description: "Your modern profile has been saved successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    }
  });

  const changePasswordMutation = useMutation({
    mutationFn: async (data: { currentPassword: string; newPassword: string }) => {
      const response = await fetch("/api/user/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ ...data, forceChange: forcePasswordChange })
      });
      if (!response.ok) throw new Error((await response.json()).message || "Failed to change password");
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Secure Data Saved", description: "Your password has been updated securely." });
      setCurrentPassword(""); setNewPassword(""); setConfirmPassword("");
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      queryClient.invalidateQueries({ queryKey: ['/api/me'] });

      if (forcePasswordChange) {
        setForcePasswordChange(false);
        setTimeout(() => window.location.href = '/', 1500);
      }
    },
    onError: (error: Error) => toast({ title: "Update Failed", description: error.message, variant: "destructive" }),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    updateProfileMutation.mutate(Object.fromEntries(formData));
  };

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      return toast({
        title: "Mismatch Detected",
        description: "Please ensure both password fields match perfectly.",
        variant: "destructive",
      });
    }
    changePasswordMutation.mutate({ currentPassword, newPassword });
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-[80vh]">
        <div className="h-12 w-12 border-4 border-t-primary border-r-transparent border-b-primary border-l-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  const userProfile = userData?.user || user;

  return (
    <div className="container mx-auto p-4 sm:p-8 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {forcePasswordChange && (
        <Alert variant="destructive" className="border-2 shadow-lg rounded-2xl mx-auto max-w-4xl bg-red-500/10 backdrop-blur-md mb-8">
          <AlertTriangle className="h-5 w-5" />
          <AlertDescription className="ml-2 font-medium">
            <strong>Security Enforced:</strong> Administrator policies require you to change your password before continuing.
          </AlertDescription>
        </Alert>
      )}

      <div className="mx-auto max-w-6xl grid grid-cols-1 lg:grid-cols-12 gap-8 relative z-10 px-2 sm:px-6 pt-4">
        
        {/* Left Column: Avatar & Identity Card */}
        <div className="lg:col-span-4 space-y-6">
          <Card className="rounded-[2rem] border-white/20 dark:border-white/10 bg-white/60 dark:bg-slate-900/60 backdrop-blur-3xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] border">
            <CardContent className="p-8 flex flex-col items-center">
              
              {/* Floating Avatar */}
              <div className="relative group cursor-pointer mb-6 transform hover:scale-105 transition-all duration-300">
                <div className="absolute -inset-1 bg-gradient-to-r from-pink-500 to-indigo-500 rounded-full blur opacity-70 group-hover:opacity-100 transition duration-500"></div>
                <Avatar className="h-32 w-32 border-4 border-white dark:border-slate-800 shadow-xl relative z-10">
                  <AvatarImage src={userProfile?.avatar || "https://github.com/shadcn.png"} alt={userProfile?.username} className="object-cover" />
                  <AvatarFallback className="text-3xl bg-indigo-100 text-indigo-700">
                    {userProfile?.username ? userProfile.username.charAt(0).toUpperCase() : "U"}
                  </AvatarFallback>
                </Avatar>
                {isEditing && (
                  <div className="absolute bottom-0 right-0 bg-primary h-10 w-10 rounded-full flex items-center justify-center text-white shadow-lg z-20 border-2 border-white dark:border-slate-800">
                    <Camera className="h-4 w-4" />
                  </div>
                )}
              </div>

              <h2 className="text-2xl font-black text-slate-800 dark:text-white tracking-tight text-center">
                {userProfile?.firstName && userProfile?.lastName 
                  ? `${userProfile.firstName} ${userProfile.lastName}`
                  : userProfile?.username}
              </h2>
              <div className="flex items-center space-x-2 mt-2">
                <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 px-3 py-1 text-xs font-bold uppercase tracking-widest rounded-full">
                  {userProfile?.role || "Staff"}
                </Badge>
                {userProfile?.department && (
                  <Badge variant="secondary" className="px-3 py-1 text-xs font-bold uppercase tracking-widest rounded-full">
                    {userProfile.department}
                  </Badge>
                )}
              </div>

              {userProfile?.bio && !isEditing && (
                <div className="mt-6 text-center text-sm text-slate-600 dark:text-slate-400 italic px-4 bg-black/5 dark:bg-white/5 py-3 rounded-2xl">
                  “{userProfile.bio}”
                </div>
              )}

              <Separator className="my-6 bg-slate-200 dark:bg-slate-800 w-full" />

              <div className="w-full space-y-4">
                <div className="flex items-center space-x-4 p-3 rounded-2xl hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                  <div className="h-10 w-10 rounded-xl bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
                    <Mail className="h-5 w-5" />
                  </div>
                  <div className="overflow-hidden">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Email</p>
                    <p className="text-sm font-medium text-slate-700 dark:text-slate-200 truncate">{userProfile?.email || "Not Provided"}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4 p-3 rounded-2xl hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                  <div className="h-10 w-10 rounded-xl bg-green-100 dark:bg-green-900/30 flex items-center justify-center text-green-600 dark:text-green-400 shrink-0">
                    <Phone className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Phone</p>
                    <p className="text-sm font-medium text-slate-700 dark:text-slate-200">{userProfile?.phone || "Not provided"}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4 p-3 rounded-2xl hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                  <div className="h-10 w-10 rounded-xl bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center text-orange-600 dark:text-orange-400 shrink-0">
                    <MapPin className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Location</p>
                    <p className="text-sm font-medium text-slate-700 dark:text-slate-200">{userProfile?.location || "Not provided"}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Editing and Security Forms */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Main Edit Profile Card */}
          <Card className="rounded-[2rem] border-white/20 dark:border-white/10 bg-white/60 dark:bg-slate-900/60 backdrop-blur-3xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] border overflow-hidden">
            <CardHeader className="bg-slate-50/50 dark:bg-slate-800/30 border-b border-black/5 dark:border-white/5 px-8 py-6 flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <User className="text-primary hidden sm:block" /> 
                  {isEditing ? "Customize Profile" : "Personal Information"}
                </CardTitle>
                <CardDescription className="text-sm mt-1">Manage your public presence and contact data</CardDescription>
              </div>
              {!isEditing && (
                <Button onClick={() => setIsEditing(true)} className="rounded-full shadow-lg shadow-primary/20 hover:scale-105 transition-transform" size="sm">
                  <Edit3 className="mr-2 h-4 w-4" /> Edit Details
                </Button>
              )}
            </CardHeader>

            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="firstName" className="text-xs font-bold uppercase tracking-wider text-slate-500">First Name</Label>
                    <Input id="firstName" name="firstName" defaultValue={userProfile?.firstName} disabled={!isEditing} 
                      className="bg-white/50 dark:bg-black/20 border-slate-200 cursor-text dark:border-slate-800 focus-visible:ring-primary rounded-xl h-11" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName" className="text-xs font-bold uppercase tracking-wider text-slate-500">Last Name</Label>
                    <Input id="lastName" name="lastName" defaultValue={userProfile?.lastName} disabled={!isEditing} 
                      className="bg-white/50 dark:bg-black/20 border-slate-200 dark:border-slate-800 focus-visible:ring-primary rounded-xl h-11" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-xs font-bold uppercase tracking-wider text-slate-500">Email Address</Label>
                    <Input id="email" name="email" type="email" defaultValue={userProfile?.email} disabled={!isEditing} 
                       className="bg-white/50 dark:bg-black/20 border-slate-200 dark:border-slate-800 focus-visible:ring-primary rounded-xl h-11" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-xs font-bold uppercase tracking-wider text-slate-500">Phone Code</Label>
                    <Input id="phone" name="phone" type="tel" defaultValue={userProfile?.phone} disabled={!isEditing} placeholder="+1 (555) 000-0000"
                       className="bg-white/50 dark:bg-black/20 border-slate-200 dark:border-slate-800 focus-visible:ring-primary rounded-xl h-11" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location" className="text-xs font-bold uppercase tracking-wider text-slate-500">Base Location</Label>
                  <Input id="location" name="location" defaultValue={userProfile?.location} disabled={!isEditing} placeholder="e.g. San Roque Operations Hub"
                     className="bg-white/50 dark:bg-black/20 border-slate-200 dark:border-slate-800 focus-visible:ring-primary rounded-xl h-11" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio" className="text-xs font-bold uppercase tracking-wider text-slate-500">Biography / Title</Label>
                  <Input id="bio" name="bio" defaultValue={userProfile?.bio} disabled={!isEditing} placeholder="Tell your team about your role..."
                     className="bg-white/50 dark:bg-black/20 border-slate-200 dark:border-slate-800 focus-visible:ring-primary rounded-xl h-11" />
                </div>

                {isEditing && (
                  <div className="space-y-2 border border-blue-500/30 bg-blue-500/5 p-4 rounded-2xl relative overflow-hidden">
                     <div className="absolute top-0 right-0 p-4 opacity-10"><LinkIcon className="h-10 w-10"/></div>
                    <Label htmlFor="avatar" className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">Avatar Image URL</Label>
                    <Input id="avatar" name="avatar" defaultValue={userProfile?.avatar} placeholder="https://example.com/my-photo.jpg"
                       className="bg-white dark:bg-black/50 border-blue-200 dark:border-blue-900 focus-visible:ring-blue-500 rounded-xl h-11" />
                       <p className="text-[10px] text-muted-foreground mt-1">Paste a direct link to an image to update your profile photo.</p>
                  </div>
                )}

                {isEditing && (
                  <div className="flex space-x-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                    <Button type="submit" disabled={updateProfileMutation.isPending} className="rounded-xl px-8 h-11 bg-primary shadow-lg shadow-primary/20 hover:scale-[1.02] transition-transform">
                      {updateProfileMutation.isPending ? <div className="h-4 w-4 border-2 border-white rounded-full border-t-transparent animate-spin mr-2"/> : <Check className="h-4 w-4 mr-2" />}
                      Save Profile Updates
                    </Button>
                    <Button type="button" variant="outline" onClick={() => setIsEditing(false)} className="rounded-xl h-11 hover:bg-slate-100">
                      Cancel
                    </Button>
                  </div>
                )}
              </form>
            </CardContent>
          </Card>

          {/* Advanced Security Card */}
          <Card className="rounded-[2rem] border-white/20 dark:border-white/10 bg-white/60 dark:bg-slate-900/60 backdrop-blur-3xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] border overflow-hidden">
             <CardHeader className="bg-red-50/50 dark:bg-red-900/10 border-b border-black/5 dark:border-white/5 px-8 py-6">
               <CardTitle className="text-xl flex items-center text-red-600 dark:text-red-400 gap-2">
                 <Shield className="h-5 w-5" /> Cryptographic Security
               </CardTitle>
               <CardDescription>
                 {forcePasswordChange ? "ADMIN REQUIRED: Reset your password immediately." : "Update your system cryptographic password."}
               </CardDescription>
             </CardHeader>
             <CardContent className="p-8">
               <form onSubmit={handlePasswordChange} className="space-y-5">
                 <div className="space-y-2">
                   <Label htmlFor="currentPassword" className="text-xs font-bold uppercase tracking-wider text-slate-500">
                     Current Key {forcePasswordChange && <span className="text-red-400">(Bypassed)</span>}
                   </Label>
                   <Input id="currentPassword" type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)}
                     required={!forcePasswordChange} disabled={forcePasswordChange} placeholder={forcePasswordChange ? "Bypassed by admin forced reset" : "Enter old password..."}
                     className="bg-white/50 dark:bg-black/20 border-slate-200 dark:border-slate-800 rounded-xl h-11" />
                 </div>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   <div className="space-y-2">
                     <Label htmlFor="newPassword" className="text-xs font-bold uppercase tracking-wider text-slate-500">New Payload Key</Label>
                     <Input id="newPassword" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required
                        className="bg-white/50 dark:bg-black/20 border-slate-200 dark:border-slate-800 rounded-xl h-11" placeholder="••••••••" />
                   </div>
                   <div className="space-y-2">
                     <Label htmlFor="confirmPassword" className="text-xs font-bold uppercase tracking-wider text-slate-500">Verify Key</Label>
                     <Input id="confirmPassword" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required
                        className="bg-white/50 dark:bg-black/20 border-slate-200 dark:border-slate-800 rounded-xl h-11" placeholder="••••••••" />
                   </div>
                 </div>
                 <div className="pt-2">
                   <Button type="submit" disabled={changePasswordMutation.isPending} variant="destructive" className="rounded-xl shadow-lg shadow-red-500/20 hover:scale-[1.02] transition-transform">
                     {changePasswordMutation.isPending ? "Encrypting Data..." : ( <><Key className="mr-2 h-4 w-4"/> Commute New Password</> )}
                   </Button>
                 </div>
               </form>
             </CardContent>
          </Card>

        </div>
      </div>
    </div>
  );
}