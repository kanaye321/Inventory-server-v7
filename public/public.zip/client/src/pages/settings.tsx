import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Palette, Settings as SettingsIcon, Monitor, Bell, Shield, 
  Save, Loader2, Link as LinkIcon, Building2, UserCog, CheckCircle, Smartphone
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useTheme } from "@/components/theme-provider";
import { PageHeader } from "@/components/page-header";

const colorThemes = [
  { name: "Default", value: "default", primary: "230 60% 55%", primaryHex: "#3b82f6", secondary: "210 40% 98%" },
  { name: "Blue", value: "blue", primary: "221 83% 53%", primaryHex: "#2563eb", secondary: "210 40% 98%" },
  { name: "Green", value: "green", primary: "142 71% 45%", primaryHex: "#059669", secondary: "138 76% 97%" },
  { name: "Purple", value: "purple", primary: "262 83% 58%", primaryHex: "#7c3aed", secondary: "270 20% 98%" },
  { name: "Red", value: "red", primary: "0 84% 60%", primaryHex: "#dc2626", secondary: "355 100% 97%" },
  { name: "Orange", value: "orange", primary: "24 95% 53%", primaryHex: "#ea580c", secondary: "33 100% 97%" },
  { name: "Yellow", value: "yellow", primary: "43 96% 56%", primaryHex: "#ca8a04", secondary: "48 100% 97%" },
  { name: "Pink", value: "pink", primary: "322 81% 64%", primaryHex: "#db2777", secondary: "322 100% 97%" },
  { name: "Teal", value: "teal", primary: "173 58% 39%", primaryHex: "#0d9488", secondary: "180 100% 97%" },
  { name: "Indigo", value: "indigo", primary: "239 84% 67%", primaryHex: "#4f46e5", secondary: "239 100% 97%" },
  { name: "Cyan", value: "cyan", primary: "189 94% 43%", primaryHex: "#0891b2", secondary: "189 100% 97%" },
  { name: "Amber", value: "amber", primary: "43 96% 56%", primaryHex: "#d97706", secondary: "43 100% 97%" },
];

export default function Settings() {
  const { theme, setTheme, colorTheme, setColorTheme } = useTheme();
  const { toast } = useToast();

  const [localState, setLocalState] = useState<Record<string, any>>({});

  const { data: settings, isLoading } = useQuery({
    queryKey: ['/api/settings'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/settings');
      return await response.json();
    }
  });

  // Sync server data to local component state when it loads
  useEffect(() => {
    if (settings) {
      setLocalState({ ...settings });
    }
  }, [settings]);

  const updateSettingsMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/settings', data);
      if (!response.ok) {
        throw new Error("Failed to update settings");
      }
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
      toast({
        title: "Settings Saved",
        description: "Your system configuration has been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error Saving",
        description: error.message || "Failed to save settings.",
        variant: "destructive",
      });
    }
  });

  const applyColorTheme = (themeName: string) => {
    setColorTheme(themeName);
    const selectedTheme = colorThemes.find(t => t.value === themeName);
    toast({
      title: "Theme Applied",
      description: `${selectedTheme?.name} palette is now active.`,
    });
  };

  const handleSave = (tabGroup: string[]) => {
    // Only extract the fields relevant to the current save action
    const subset: Record<string, any> = {};
    tabGroup.forEach(key => {
      if (localState[key] !== undefined) {
        subset[key] = localState[key];
      }
    });

    console.log("Saving settings subset:", subset);
    updateSettingsMutation.mutate(subset);
  };

  const updateField = (field: string, value: any) => {
    setLocalState(prev => ({ ...prev, [field]: value }));
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <PageHeader title="System Settings" description="Loading configuration..." />
        <Skeleton className="w-full h-[400px] rounded-xl" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-10">
      <div className="flex items-start sm:items-center justify-between flex-col sm:flex-row gap-4 mb-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
          <p className="text-muted-foreground mt-1">Manage your application configuration and preferences.</p>
        </div>
        <Badge variant="outline" className="px-3 py-1 text-sm bg-primary/5 text-primary border-primary/20">
          <SettingsIcon className="h-3.5 w-3.5 mr-1.5" /> Core Configuration
        </Badge>
      </div>

      <Tabs defaultValue="appearance" className="w-full">
        <TabsList className="grid grid-cols-2 md:grid-cols-4 w-full h-auto gap-2 bg-transparent p-0 mb-6">
          <TabsTrigger value="appearance" className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-none border border-transparent data-[state=active]:border-primary/20 py-2.5 rounded-lg">
            <Palette className="h-4 w-4 mr-2" /> Appearance
          </TabsTrigger>
          <TabsTrigger value="system" className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-none border border-transparent data-[state=active]:border-primary/20 py-2.5 rounded-lg">
            <Monitor className="h-4 w-4 mr-2" /> General System
          </TabsTrigger>
          <TabsTrigger value="security" className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-none border border-transparent data-[state=active]:border-primary/20 py-2.5 rounded-lg">
            <Shield className="h-4 w-4 mr-2" /> Security Policies
          </TabsTrigger>
          <TabsTrigger value="notifications" className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-none border border-transparent data-[state=active]:border-primary/20 py-2.5 rounded-lg">
            <Bell className="h-4 w-4 mr-2" /> Event Alerts
          </TabsTrigger>
        </TabsList>

        {/* ================= APPEARANCE TAB ================= */}
        <TabsContent value="appearance" className="space-y-6 animate-in fade-in-50 slide-in-from-bottom-2 duration-300">
          <Card className="border-border/60 shadow-sm overflow-hidden">
            <div className="h-1 bg-gradient-to-r from-pink-500 to-purple-500" />
            <CardHeader className="bg-muted/10 pb-4 border-b border-border/40">
              <CardTitle className="text-lg">Dashboard Theme Options</CardTitle>
              <CardDescription>Personalize the look and feel of the inventory system</CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-8">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 p-4 rounded-xl border bg-card hover:border-primary/30 transition-colors">
                <div className="space-y-1">
                  <Label className="text-base font-semibold flex items-center gap-2">
                    Visual Mode
                    {theme === "dark" ? <Badge className="bg-indigo-500">Dark</Badge> : <Badge className="bg-amber-500 text-amber-950">Light</Badge>}
                  </Label>
                  <p className="text-sm text-muted-foreground mr-10">
                    Switch between the light mode for daytime visibility or dark mode to reduce eye strain.
                  </p>
                </div>
                <div className="flex items-center gap-2 bg-muted p-1 rounded-full shrink-0">
                  <Button 
                    variant={theme === "light" ? "secondary" : "ghost"} 
                    className={`rounded-full h-8 px-4 ${theme === "light" ? "shadow-sm bg-background" : ""}`}
                    onClick={() => setTheme("light")}
                  > Light
                  </Button>
                  <Button 
                    variant={theme === "dark" ? "secondary" : "ghost"} 
                    className={`rounded-full h-8 px-4 ${theme === "dark" ? "shadow-sm bg-background" : ""}`}
                    onClick={() => setTheme("dark")}
                  > Dark
                  </Button>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <Label className="text-base font-semibold">Primary Color Palette</Label>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    Select an accent color to be used across all components, buttons, and graphics.
                  </p>
                </div>
                
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3 pt-2">
                  {colorThemes.map((themeOption) => {
                    const isActive = colorTheme === themeOption.value;
                    return (
                      <Button
                        key={themeOption.value}
                        variant="outline"
                        className={`h-24 flex flex-col items-center justify-center gap-3 transition-all ${
                          isActive ? "border-2 border-primary bg-primary/5 shadow-sm" : "hover:border-primary/40 hover:bg-muted/50"
                        }`}
                        onClick={() => applyColorTheme(themeOption.value)}
                      >
                        <div
                          className={`w-8 h-8 rounded-full shadow-sm ${isActive ? 'ring-4 ring-primary/20' : ''}`}
                          style={{ backgroundColor: themeOption.primaryHex }}
                        />
                        <span className={`text-xs font-medium ${isActive ? 'text-primary' : 'text-muted-foreground'}`}>
                          {themeOption.name}
                        </span>
                      </Button>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ================= SYSTEM TAB ================= */}
        <TabsContent value="system" className="space-y-6 animate-in fade-in-50 slide-in-from-bottom-2 duration-300">
          <Card className="border-border/60 shadow-sm overflow-hidden">
            <div className="h-1 bg-blue-500" />
            <CardHeader className="bg-muted/10 pb-4 border-b border-border/40">
              <CardTitle className="text-lg flex items-center gap-2">
                <Building2 className="h-5 w-5 text-blue-500" /> Organization Identity
              </CardTitle>
              <CardDescription>Basic information about your deployment</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="companyName">Organization Name</Label>
                  <Input 
                    id="companyName" 
                    value={localState.companyName || ""} 
                    onChange={(e) => updateField("companyName", e.target.value)} 
                    placeholder="e.g. Acme Corp"
                    className="focus-visible:ring-blue-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="siteName">Dashboard Title</Label>
                  <Input 
                    id="siteName" 
                    value={localState.siteName || ""} 
                    onChange={(e) => updateField("siteName", e.target.value)} 
                    placeholder="e.g. IT Inventory Portal"
                    className="focus-visible:ring-blue-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="companyEmail">Primary Support Email</Label>
                  <Input 
                    id="companyEmail" 
                    type="email" 
                    value={localState.companyEmail || ""} 
                    onChange={(e) => updateField("companyEmail", e.target.value)} 
                    placeholder="admin@example.com"
                    className="focus-visible:ring-blue-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="siteUrl">Internal Portal URL</Label>
                  <div className="relative">
                    <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input 
                      id="siteUrl" 
                      value={localState.siteUrl || ""} 
                      onChange={(e) => updateField("siteUrl", e.target.value)} 
                      placeholder="https://inventory.local"
                      className="pl-9 focus-visible:ring-blue-500"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-muted/10 border-t border-border/40 flex justify-end py-4">
              <Button 
                onClick={() => handleSave(["siteName", "siteUrl", "companyName", "companyEmail"])} 
                disabled={updateSettingsMutation.isPending}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {updateSettingsMutation.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                Save Identity Settings
              </Button>
            </CardFooter>
          </Card>

          <Card className="border-border/60 shadow-sm overflow-hidden">
            <CardHeader className="bg-muted/10 pb-4 border-b border-border/40">
              <CardTitle className="text-lg">Regional Settings</CardTitle>
            </CardHeader>
            <CardContent className="pt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Default Language</Label>
                <Select value={localState.defaultLanguage || "english"} onValueChange={(v) => updateField("defaultLanguage", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="english">English</SelectItem>
                    <SelectItem value="spanish">Spanish</SelectItem>
                    <SelectItem value="french">French</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>System Timezone</Label>
                <Select value={localState.defaultTimezone || "UTC"} onValueChange={(v) => updateField("defaultTimezone", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="UTC">UTC / GMT</SelectItem>
                    <SelectItem value="America/New_York">Eastern Time (US)</SelectItem>
                    <SelectItem value="America/Los_Angeles">Pacific Time (US)</SelectItem>
                    <SelectItem value="Asia/Manila">Philippine Time</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
            <CardFooter className="bg-muted/10 border-t border-border/40 flex justify-end py-4">
              <Button 
                variant="outline"
                onClick={() => handleSave(["defaultLanguage", "defaultTimezone"])} 
                disabled={updateSettingsMutation.isPending}
              >
                Save Regional Settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* ================= SECURITY TAB ================= */}
        <TabsContent value="security" className="space-y-6 animate-in fade-in-50 slide-in-from-bottom-2 duration-300">
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <Card className="border-border/60 shadow-sm h-full">
                <div className="h-1 bg-red-500" />
                <CardHeader className="bg-muted/10 pb-4 border-b border-border/40">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <UserCog className="h-5 w-5 text-red-500" /> Access & Authentication
                  </CardTitle>
                  <CardDescription>Global variables affecting how users authenticate.</CardDescription>
                </CardHeader>
                <CardContent className="pt-6 space-y-6">
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                    <div className="space-y-2">
                      <Label>Session Idle Timeout</Label>
                      <Select 
                        value={String(localState.sessionTimeout || "30")} 
                        onValueChange={(v) => updateField("sessionTimeout", parseInt(v))}
                      >
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="15">15 minutes</SelectItem>
                          <SelectItem value="30">30 minutes</SelectItem>
                          <SelectItem value="60">1 hour</SelectItem>
                          <SelectItem value="180">3 hours</SelectItem>
                          <SelectItem value="1440">24 hours</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground mt-1">Users are logged out after inactivity</p>
                    </div>

                    <div className="space-y-2">
                      <Label className="flex items-center gap-1.5">
                        Minimum Password Length
                      </Label>
                      <Input
                        type="number"
                        min="6"
                        max="24"
                        value={localState.passwordMinLength || ""}
                        onChange={(e) => updateField("passwordMinLength", parseInt(e.target.value) || 8)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Max Invalid Login Attempts</Label>
                      <Select 
                        value={String(localState.maxLoginAttempts || "5")} 
                        onValueChange={(v) => updateField("maxLoginAttempts", parseInt(v))}
                      >
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="3">3 attempts (Strict)</SelectItem>
                          <SelectItem value="5">5 attempts (Standard)</SelectItem>
                          <SelectItem value="10">10 attempts (Lenient)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <Label className="text-base">Password Complexity Requirements</Label>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="flex items-center space-x-3 bg-muted/30 p-3 rounded-lg border">
                        <Switch 
                          id="reqUpperCase"
                          checked={localState.requireUppercase ?? true}
                          onCheckedChange={(c) => updateField("requireUppercase", c)}
                        />
                        <Label htmlFor="reqUpperCase" className="font-medium cursor-pointer">Uppercase letters (A-Z)</Label>
                      </div>
                      
                      <div className="flex items-center space-x-3 bg-muted/30 p-3 rounded-lg border">
                        <Switch 
                          id="reqNumber"
                          checked={localState.requireNumber ?? true}
                          onCheckedChange={(c) => updateField("requireNumber", c)}
                        />
                        <Label htmlFor="reqNumber" className="font-medium cursor-pointer">Numeric character (0-9)</Label>
                      </div>

                      <div className="flex items-center space-x-3 bg-muted/30 p-3 rounded-lg border">
                        <Switch 
                          id="reqSpecial"
                          checked={localState.requireSpecialChar ?? true}
                          onCheckedChange={(c) => updateField("requireSpecialChar", c)}
                        />
                        <Label htmlFor="reqSpecial" className="font-medium cursor-pointer">Special character (!@#)</Label>
                      </div>
                    </div>
                  </div>

                </CardContent>
                <CardFooter className="bg-muted/10 border-t border-border/40 flex justify-end py-4">
                  <Button 
                    onClick={() => handleSave([
                      "sessionTimeout", "passwordMinLength", "maxLoginAttempts", 
                      "requireUppercase", "requireNumber", "requireSpecialChar"
                    ])} 
                    disabled={updateSettingsMutation.isPending}
                    variant="destructive"
                    className="bg-red-600 hover:bg-red-700"
                  >
                    {updateSettingsMutation.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Shield className="h-4 w-4 mr-2" />}
                    Enforce Security Policies
                  </Button>
                </CardFooter>
              </Card>
            </div>

            <div className="space-y-6">
              <Card className="border-border/60 bg-primary/5 border-primary/20">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Smartphone className="h-5 w-5 text-primary" /> Two-Factor Auth
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 text-sm text-muted-foreground pb-6">
                  <p>MFA applies per-user. As an administrator, you can configure your own MFA device here to protect your account.</p>
                  <div className="bg-background border rounded-lg p-3 flex gap-3 items-start">
                    <Shield className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                    <p className="text-xs">We support Samsung SingleID, Google Authenticator, and Authy.</p>
                  </div>
                  <Button 
                    className="w-full mt-2" 
                    onClick={() => window.location.href = '/admin/mfa-management'}
                  >
                    Open MFA Management
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* ================= NOTIFICATIONS TAB ================= */}
        <TabsContent value="notifications" className="space-y-6 animate-in fade-in-50 slide-in-from-bottom-2 duration-300">
          <Card className="border-border/60 shadow-sm overflow-hidden">
            <div className="h-1 bg-amber-400" />
            <CardHeader className="bg-muted/10 pb-4 border-b border-border/40">
              <CardTitle className="text-lg flex items-center gap-2">
                <Bell className="h-5 w-5 text-amber-500" /> Global Event Triggers
              </CardTitle>
              <CardDescription>
                Configure which actions trigger administrative alerts. Note: You can customize the actual email templates in the <a href="/email-notifications" className="text-primary hover:underline font-medium">Email Notifications</a> page.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-lg border bg-card">
                  <div className="space-y-1">
                    <Label className="text-base font-semibold">Enable Global Email Notifications</Label>
                    <p className="text-sm text-muted-foreground">Master switch for all out-bound administrative emails.</p>
                  </div>
                  <Switch 
                    checked={localState.enableAdminNotifications ?? true}
                    onCheckedChange={(c) => updateField("enableAdminNotifications", c)}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    { key: "notifyOnCheckout", label: "Asset Checkouts", desc: "Alert when a user is assigned an asset." },
                    { key: "notifyOnCheckin", label: "Asset Check-ins", desc: "Alert when an asset is returned." },
                    { key: "notifyOnOverdue", label: "Overdue Returns", desc: "Daily digest for past-due assets." },
                    { key: "notifyOnIamExpiration", label: "IAM Expiration", desc: "Warnings for resolving IAM expirations." },
                  ].map(setting => (
                    <div key={setting.key} className={`flex items-start space-x-3 p-4 rounded-lg border transition-colors ${localState.enableAdminNotifications === false ? 'opacity-50 pointer-events-none bg-muted/50' : 'bg-card'}`}>
                      <Switch 
                        id={setting.key}
                        checked={localState[setting.key] ?? true}
                        onCheckedChange={(c) => updateField(setting.key, c)}
                        className="mt-0.5"
                      />
                      <div className="space-y-1">
                        <Label htmlFor={setting.key} className="text-sm font-semibold cursor-pointer">{setting.label}</Label>
                        <p className="text-xs text-muted-foreground leading-relaxed">{setting.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </CardContent>
            <CardFooter className="bg-muted/10 border-t border-border/40 flex justify-end py-4">
              <Button 
                onClick={() => handleSave([
                  "enableAdminNotifications", "notifyOnCheckout", "notifyOnCheckin", 
                  "notifyOnOverdue", "notifyOnIamExpiration"
                ])} 
                disabled={updateSettingsMutation.isPending}
                className="bg-amber-600 hover:bg-amber-700 text-white"
              >
                {updateSettingsMutation.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                Save Notification Prefs
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

      </Tabs>
    </div>
  );
}