import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Settings, MailCheck, Globe, ShieldAlert, Bell, Database,
  Save, RefreshCw, Loader2, Building2, Clock, Lock,
  CheckCircle, AlertCircle, Download, Server, ChevronRight
} from "lucide-react";

/* ── Types ── */
interface SystemSettings {
  siteName?: string;
  siteUrl?: string;
  defaultLanguage?: string;
  defaultTimezone?: string;
  companyName?: string;
  companyAddress?: string;
  companyEmail?: string;
  companyPhone?: string;
  mailFromAddress?: string;
  mailFromName?: string;
  mailHost?: string;
  mailPort?: string;
  mailUsername?: string;
  mailPassword?: string;
  sessionTimeout?: number;
  maxLoginAttempts?: number;
  enableLoginAttempts?: boolean;
  enableAdminNotifications?: boolean;
  enableUserNotifications?: boolean;
  notifyOnCheckin?: boolean;
  notifyOnCheckout?: boolean;
  notifyOnOverdue?: boolean;
  notifyOnIamExpiration?: boolean;
  notifyOnVmExpiration?: boolean;
  [key: string]: any;
}

/* ── Constants ── */
const TIMEZONES = ["UTC", "Asia/Manila", "Asia/Singapore", "Asia/Tokyo", "Asia/Seoul",
  "America/New_York", "America/Chicago", "America/Los_Angeles",
  "Europe/London", "Europe/Paris", "Europe/Berlin", "Australia/Sydney"];

const LANGUAGES = [
  { code: "en", name: "English" }, { code: "es", name: "Spanish" },
  { code: "fr", name: "French" }, { code: "de", name: "German" },
  { code: "ja", name: "Japanese" }, { code: "zh", name: "Chinese" },
];

const NAV_SECTIONS = [
  { id: "general",       label: "General",       icon: Globe,       desc: "Site name, URL & locale" },
  { id: "company",       label: "Company",        icon: Building2,   desc: "Organization details" },
  { id: "email",         label: "Email / SMTP",   icon: MailCheck,   desc: "Mail server configuration" },
  { id: "security",      label: "Security",       icon: ShieldAlert, desc: "Session & login policies" },
  { id: "notifications", label: "Notifications",  icon: Bell,        desc: "Alert preferences" },
  { id: "maintenance",   label: "Maintenance",    icon: Database,    desc: "Database & backups" },
];

/* ── Helper: toggle row ── */
function ToggleRow({ label, description, checked, onCheckedChange }: {
  label: string; description: string; checked: boolean; onCheckedChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between p-4 rounded-xl border border-border bg-card hover:bg-accent/30 transition-colors">
      <div className="space-y-0.5 pr-4">
        <p className="text-sm font-medium">{label}</p>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  );
}

/* ── Helper: save button ── */
function SaveBtn({ onClick, pending }: { onClick: () => void; pending: boolean }) {
  return (
    <div className="pt-4 border-t border-border mt-6">
      <Button onClick={onClick} disabled={pending} className="bg-primary hover:bg-primary/90 gap-2">
        {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
        {pending ? "Saving…" : "Save Changes"}
      </Button>
    </div>
  );
}

/* ── Helper: field row ── */
function FieldRow({ label, desc, children }: { label: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
      <div className="md:pt-2">
        <Label className="text-sm font-medium">{label}</Label>
        {desc && <p className="text-xs text-muted-foreground mt-0.5">{desc}</p>}
      </div>
      <div className="md:col-span-2">{children}</div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   Main Page
═══════════════════════════════════════════════ */
export default function SystemSetupPage() {
  const [activeSection, setActiveSection] = useState("general");
  const [saved, setSaved] = useState<string | null>(null);
  const { toast } = useToast();

  /* ── Fetch settings ── */
  const { data: settings, isLoading } = useQuery<SystemSettings>({
    queryKey: ["/api/settings"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/settings");
      return res.json();
    },
  });

  /* ── Local draft state (per section) ── */
  const [general, setGeneral] = useState({ siteName: "", siteUrl: "", defaultLanguage: "en", defaultTimezone: "UTC" });
  const [company, setCompany] = useState({ companyName: "", companyAddress: "", companyEmail: "", companyPhone: "" });
  const [email, setEmail] = useState({ mailFromAddress: "", mailFromName: "", mailHost: "", mailPort: "587", mailUsername: "", mailPassword: "" });
  const [security, setSecurity] = useState({ sessionTimeout: 120, maxLoginAttempts: 5, enableLoginAttempts: true });
  const [notifs, setNotifs] = useState({
    enableAdminNotifications: true,
    enableUserNotifications: true,
    notifyOnCheckin: true,
    notifyOnCheckout: true,
    notifyOnOverdue: true,
    notifyOnIamExpiration: true,
    notifyOnVmExpiration: true,
  });

  /* ── Sync from server ── */
  useEffect(() => {
    if (!settings) return;
    setGeneral({
      siteName: settings.siteName || "SRPH-MIS",
      siteUrl: settings.siteUrl || "",
      defaultLanguage: settings.defaultLanguage || "en",
      defaultTimezone: settings.defaultTimezone || "UTC",
    });
    setCompany({
      companyName: settings.companyName || "",
      companyAddress: settings.companyAddress || "",
      companyEmail: settings.companyEmail || "",
      companyPhone: settings.companyPhone || "",
    });
    setEmail({
      mailFromAddress: settings.mailFromAddress || "",
      mailFromName: settings.mailFromName || "",
      mailHost: settings.mailHost || "",
      mailPort: settings.mailPort || "587",
      mailUsername: settings.mailUsername || "",
      mailPassword: "",
    });
    setSecurity({
      sessionTimeout: settings.sessionTimeout || 120,
      maxLoginAttempts: settings.maxLoginAttempts || 5,
      enableLoginAttempts: settings.enableLoginAttempts !== false,
    });
    setNotifs({
      enableAdminNotifications: settings.enableAdminNotifications !== false,
      enableUserNotifications: settings.enableUserNotifications !== false,
      notifyOnCheckin: settings.notifyOnCheckin !== false,
      notifyOnCheckout: settings.notifyOnCheckout !== false,
      notifyOnOverdue: settings.notifyOnOverdue !== false,
      notifyOnIamExpiration: settings.notifyOnIamExpiration !== false,
      notifyOnVmExpiration: settings.notifyOnVmExpiration !== false,
    });
  }, [settings]);

  /* ── Save mutation ── */
  const saveMutation = useMutation({
    mutationFn: async (data: Record<string, any>) => {
      const res = await apiRequest("POST", "/api/settings", data);
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      setSaved(activeSection);
      setTimeout(() => setSaved(null), 3000);
      toast({ title: "Settings saved", description: "Changes have been saved successfully." });
    },
    onError: () => {
      toast({ title: "Save failed", description: "Could not save settings. Please try again.", variant: "destructive" });
    },
  });

  /* ── Test email mutation ── */
  const testEmailMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/test-email");
      return res.json();
    },
    onSuccess: () => toast({ title: "Test email sent", description: "Check your inbox." }),
    onError: () => toast({ title: "Email test failed", description: "Check your SMTP configuration.", variant: "destructive" }),
  });

  /* ── Database backup mutation ── */
  const backupMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/database/backup");
      return res.json();
    },
    onSuccess: () => toast({ title: "Backup created", description: "Database backup completed successfully." }),
    onError: () => toast({ title: "Backup failed", description: "Could not create database backup.", variant: "destructive" }),
  });

  const isSaving = saveMutation.isPending;

  /* ── Section savers ── */
  const saveGeneral = () => saveMutation.mutate(general);
  const saveCompany = () => saveMutation.mutate(company);
  const saveEmail = () => saveMutation.mutate({ ...email, mailFromName: email.mailFromName || company.companyName });
  const saveSecurity = () => saveMutation.mutate({ ...security, sessionTimeout: Number(security.sessionTimeout), maxLoginAttempts: Number(security.maxLoginAttempts) });
  const saveNotifs = () => saveMutation.mutate(notifs);

  /* ── Render ── */
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const currentNav = NAV_SECTIONS.find(n => n.id === activeSection)!;

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Settings className="h-6 w-6 text-primary" />
            System Setup
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Configure global system preferences, email, security, and maintenance
          </p>
        </div>
        {saved && (
          <Badge className="bg-emerald-500/15 text-emerald-600 border border-emerald-500/30 gap-1.5 px-3 py-1.5">
            <CheckCircle className="h-3.5 w-3.5" /> Saved successfully
          </Badge>
        )}
      </div>

      <div className="flex gap-6">
        {/* ── Sidebar nav ── */}
        <div className="w-56 shrink-0">
          <Card className="p-2 space-y-0.5">
            {NAV_SECTIONS.map((section) => {
              const Icon = section.icon;
              const active = activeSection === section.id;
              return (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-center gap-3 text-left px-3 py-2.5 rounded-lg text-sm transition-colors ${
                    active
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-accent text-foreground"
                  }`}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{section.label}</p>
                    <p className={`text-[10px] truncate ${active ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                      {section.desc}
                    </p>
                  </div>
                  {active && <ChevronRight className="h-3 w-3 shrink-0 opacity-60" />}
                </button>
              );
            })}
          </Card>
        </div>

        {/* ── Main content ── */}
        <div className="flex-1 min-w-0">
          <Card>
            <CardHeader className="pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-primary/10">
                  <currentNav.icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-base">{currentNav.label}</CardTitle>
                  <CardDescription className="text-xs mt-0.5">{currentNav.desc}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>

              {/* ─── GENERAL ─── */}
              {activeSection === "general" && (
                <div className="space-y-5">
                  <FieldRow label="Site Name" desc="Displayed throughout the application">
                    <Input value={general.siteName} onChange={e => setGeneral({ ...general, siteName: e.target.value })} placeholder="SRPH-MIS" />
                  </FieldRow>
                  <FieldRow label="Site URL" desc="Full URL where the system is hosted">
                    <Input value={general.siteUrl} onChange={e => setGeneral({ ...general, siteUrl: e.target.value })} placeholder="https://mis.srph.org" />
                  </FieldRow>
                  <FieldRow label="Language">
                    <Select value={general.defaultLanguage} onValueChange={v => setGeneral({ ...general, defaultLanguage: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{LANGUAGES.map(l => <SelectItem key={l.code} value={l.code}>{l.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </FieldRow>
                  <FieldRow label="Timezone">
                    <Select value={general.defaultTimezone} onValueChange={v => setGeneral({ ...general, defaultTimezone: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{TIMEZONES.map(tz => <SelectItem key={tz} value={tz}>{tz}</SelectItem>)}</SelectContent>
                    </Select>
                  </FieldRow>
                  <SaveBtn onClick={saveGeneral} pending={isSaving} />
                </div>
              )}

              {/* ─── COMPANY ─── */}
              {activeSection === "company" && (
                <div className="space-y-5">
                  <FieldRow label="Company Name" desc="Your organization's name">
                    <Input value={company.companyName} onChange={e => setCompany({ ...company, companyName: e.target.value })} placeholder="SRPH" />
                  </FieldRow>
                  <FieldRow label="Email Address" desc="Primary contact email">
                    <Input type="email" value={company.companyEmail} onChange={e => setCompany({ ...company, companyEmail: e.target.value })} placeholder="admin@srph.org" />
                  </FieldRow>
                  <FieldRow label="Phone Number">
                    <Input value={company.companyPhone} onChange={e => setCompany({ ...company, companyPhone: e.target.value })} placeholder="+63 2 1234 5678" />
                  </FieldRow>
                  <FieldRow label="Address">
                    <Textarea value={company.companyAddress} onChange={e => setCompany({ ...company, companyAddress: e.target.value })} rows={3} placeholder="Building, Street, City, Country" />
                  </FieldRow>
                  <SaveBtn onClick={saveCompany} pending={isSaving} />
                </div>
              )}

              {/* ─── EMAIL ─── */}
              {activeSection === "email" && (
                <div className="space-y-5">
                  <div className="flex gap-2 p-3 rounded-xl bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/40 text-amber-800 dark:text-amber-300 text-xs">
                    <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                    <span>SMTP credentials are stored in the database. Use "Test Email" to verify configuration before saving.</span>
                  </div>

                  <FieldRow label="Sender Email" desc="From address for all system emails">
                    <Input type="email" value={email.mailFromAddress} onChange={e => setEmail({ ...email, mailFromAddress: e.target.value })} placeholder="noreply@srph.org" />
                  </FieldRow>
                  <FieldRow label="Sender Name">
                    <Input value={email.mailFromName} onChange={e => setEmail({ ...email, mailFromName: e.target.value })} placeholder="SRPH-MIS" />
                  </FieldRow>

                  <div className="h-px bg-border" />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label className="text-sm font-medium">SMTP Server</Label>
                      <Input value={email.mailHost} onChange={e => setEmail({ ...email, mailHost: e.target.value })} placeholder="smtp.gmail.com" />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-sm font-medium">SMTP Port</Label>
                      <Input value={email.mailPort} onChange={e => setEmail({ ...email, mailPort: e.target.value })} placeholder="587" />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-sm font-medium">Username</Label>
                      <Input value={email.mailUsername} onChange={e => setEmail({ ...email, mailUsername: e.target.value })} />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-sm font-medium">Password</Label>
                      <Input type="password" value={email.mailPassword} onChange={e => setEmail({ ...email, mailPassword: e.target.value })} placeholder="Leave blank to keep current" />
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4 border-t border-border mt-6">
                    <Button onClick={saveEmail} disabled={isSaving} className="gap-2">
                      {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                      {isSaving ? "Saving…" : "Save Email Settings"}
                    </Button>
                    <Button variant="outline" onClick={() => testEmailMutation.mutate()} disabled={testEmailMutation.isPending} className="gap-2">
                      {testEmailMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <MailCheck className="h-4 w-4" />}
                      Send Test Email
                    </Button>
                  </div>
                </div>
              )}

              {/* ─── SECURITY ─── */}
              {activeSection === "security" && (
                <div className="space-y-5">
                  <FieldRow label="Session Timeout" desc="Minutes of inactivity before auto-logout">
                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <Input
                          type="number" min="1" max="1440"
                          value={security.sessionTimeout}
                          onChange={e => setSecurity({ ...security, sessionTimeout: Number(e.target.value) })}
                          className="w-32"
                        />
                        <span className="text-sm text-muted-foreground">minutes</span>
                      </div>
                      {security.sessionTimeout > 0 && (
                        <p className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                          <CheckCircle className="h-3 w-3" />
                          Users will be warned 60 seconds before logout after{" "}
                          <strong>
                            {security.sessionTimeout >= 60
                              ? `${Math.floor(security.sessionTimeout / 60)}h ${security.sessionTimeout % 60 > 0 ? `${security.sessionTimeout % 60}m` : ""}`.trim()
                              : `${security.sessionTimeout}m`}
                          </strong>{" "}
                          of inactivity
                        </p>
                      )}
                    </div>
                  </FieldRow>

                  <FieldRow label="Max Login Attempts" desc="Failed attempts before account lockout">
                    <div className="flex items-center gap-3">
                      <Input
                        type="number" min="1" max="20"
                        value={security.maxLoginAttempts}
                        onChange={e => setSecurity({ ...security, maxLoginAttempts: Number(e.target.value) })}
                        className="w-32"
                      />
                      <span className="text-sm text-muted-foreground">attempts</span>
                    </div>
                  </FieldRow>

                  <ToggleRow
                    label="Enable Login Attempt Limiting"
                    description="Lock accounts after exceeding max failed login attempts"
                    checked={security.enableLoginAttempts}
                    onCheckedChange={v => setSecurity({ ...security, enableLoginAttempts: v })}
                  />

                  <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-900/15 border border-blue-200 dark:border-blue-700/40 text-xs text-blue-700 dark:text-blue-300 flex gap-2">
                    <Lock className="h-4 w-4 shrink-0 mt-0.5" />
                    <span>MFA (Two-Factor Authentication) settings are managed under <strong>Admin → MFA Management</strong>.</span>
                  </div>

                  <SaveBtn onClick={saveSecurity} pending={isSaving} />
                </div>
              )}

              {/* ─── NOTIFICATIONS ─── */}
              {activeSection === "notifications" && (
                <div className="space-y-4">
                  <ToggleRow
                    label="Admin Email Notifications"
                    description="Send email alerts to administrators for important events"
                    checked={notifs.enableAdminNotifications}
                    onCheckedChange={v => setNotifs({ ...notifs, enableAdminNotifications: v })}
                  />
                  <ToggleRow
                    label="User Email Notifications"
                    description="Send email updates to end users"
                    checked={notifs.enableUserNotifications}
                    onCheckedChange={v => setNotifs({ ...notifs, enableUserNotifications: v })}
                  />

                  <div className="h-px bg-border my-2" />
                  <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground px-1">Event Triggers</p>

                  <ToggleRow
                    label="Asset Check-In"
                    description="Notify when an asset is checked back in"
                    checked={notifs.notifyOnCheckin}
                    onCheckedChange={v => setNotifs({ ...notifs, notifyOnCheckin: v })}
                  />
                  <ToggleRow
                    label="Asset Check-Out"
                    description="Notify when an asset is issued to a user"
                    checked={notifs.notifyOnCheckout}
                    onCheckedChange={v => setNotifs({ ...notifs, notifyOnCheckout: v })}
                  />
                  <ToggleRow
                    label="Overdue Alerts"
                    description="Notify when an asset or approval is past due"
                    checked={notifs.notifyOnOverdue}
                    onCheckedChange={v => setNotifs({ ...notifs, notifyOnOverdue: v })}
                  />
                  <ToggleRow
                    label="IAM Account Expiration"
                    description="Notify before IAM accounts expire"
                    checked={notifs.notifyOnIamExpiration}
                    onCheckedChange={v => setNotifs({ ...notifs, notifyOnIamExpiration: v })}
                  />
                  <ToggleRow
                    label="VM Approval Expiration"
                    description="Notify before VM approval periods expire"
                    checked={notifs.notifyOnVmExpiration}
                    onCheckedChange={v => setNotifs({ ...notifs, notifyOnVmExpiration: v })}
                  />

                  <SaveBtn onClick={saveNotifs} pending={isSaving} />
                </div>
              )}

              {/* ─── MAINTENANCE ─── */}
              {activeSection === "maintenance" && (
                <div className="space-y-6">
                  {/* System status */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="p-4 rounded-xl border border-border bg-card space-y-2">
                      <div className="flex items-center gap-2">
                        <Server className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">Server Status</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse" />
                        <span className="text-sm text-emerald-600 dark:text-emerald-400 font-medium">Running normally</span>
                      </div>
                    </div>
                    <div className="p-4 rounded-xl border border-border bg-card space-y-2">
                      <div className="flex items-center gap-2">
                        <Database className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">Database Status</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse" />
                        <span className="text-sm text-emerald-600 dark:text-emerald-400 font-medium">Connected</span>
                      </div>
                    </div>
                  </div>

                  {/* Database backup */}
                  <div className="space-y-3">
                    <div>
                      <h3 className="text-sm font-semibold">Database Backup</h3>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Create a manual backup of all database records. The backup file will be saved to the <code className="text-xs bg-muted px-1 py-0.5 rounded">backups/</code> directory on the server.
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => backupMutation.mutate()}
                      disabled={backupMutation.isPending}
                      className="gap-2"
                    >
                      {backupMutation.isPending
                        ? <><Loader2 className="h-4 w-4 animate-spin" /> Creating backup…</>
                        : <><Download className="h-4 w-4" /> Create Database Backup</>
                      }
                    </Button>
                  </div>

                  {/* Cache / refresh */}
                  <div className="space-y-3">
                    <div>
                      <h3 className="text-sm font-semibold">Refresh Settings Cache</h3>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Force-reload all system settings from the database to clear any cached values in the current session.
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/settings"] })}
                      className="gap-2"
                    >
                      <RefreshCw className="h-4 w-4" /> Refresh Cache
                    </Button>
                  </div>

                  <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-900/15 border border-amber-200 dark:border-amber-700/40 text-xs text-amber-700 dark:text-amber-300 flex gap-2">
                    <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                    <div>
                      <strong>Automatic backups</strong> and <strong>scheduled maintenance</strong> are configured under{" "}
                      <strong>Admin → Database</strong> in the sidebar.
                    </div>
                  </div>
                </div>
              )}

            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}