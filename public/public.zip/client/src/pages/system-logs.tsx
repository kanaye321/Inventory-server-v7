
import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import {
  FileText, Download, RefreshCw,
  UserCheck, Search, Shield, Activity, Clock, Users, XCircle,
  CheckCircle, Monitor, ChevronRight, Eye, AlertTriangle,
  Ban, Unlock, Plus, Zap, TrendingUp, Globe, ShieldAlert,
  ChevronLeft, ChevronRight as ChevronRightIcon,
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend, Cell,
} from "recharts";

/* ──────────────────────────────────────────────
   Auth Helpers
────────────────────────────────────────────── */
function parseAuthLog(content: string) {
  return content
    .trim()
    .split("\n")
    .map((line) => {
      try {
        const match = line.match(/\[(.*?)\] \[AUTH\] (.*)/);
        if (match) return { timestamp: match[1], ...JSON.parse(match[2]) };
        return JSON.parse(line);
      } catch {
        return null;
      }
    })
    .filter(Boolean);
}

function buildHourlyChart(entries: any[]) {
  const map: Record<string, { hour: string; login: number; logout: number; failed: number }> = {};
  entries.forEach((e) => {
    try {
      const d = new Date(e.timestamp);
      const hour = `${d.getHours().toString().padStart(2, "0")}:00`;
      if (!map[hour]) map[hour] = { hour, login: 0, logout: 0, failed: 0 };
      if (e.action === "login") map[hour].login++;
      else if (e.action === "logout") map[hour].logout++;
      else if (e.action === "failed_login") map[hour].failed++;
    } catch {}
  });
  return Object.values(map).sort((a, b) => a.hour.localeCompare(b.hour));
}

/* ──────────────────────────────────────────────
   Security Helpers
────────────────────────────────────────────── */
const THREAT_LABELS: Record<string, string> = {
  sql_injection:     "SQL Injection",
  xss:               "XSS",
  rate_limit:        "Rate Limit",
  blocked_ip:        "Blocked IP",
  oversized_request: "Oversized Req",
  suspicious_agent:  "Suspicious Agent",
};

const SEVERITY_COLORS: Record<string, string> = {
  low:      "bg-blue-500/15 text-blue-600 border-blue-500/30",
  medium:   "bg-yellow-500/15 text-yellow-600 border-yellow-500/30",
  high:     "bg-orange-500/15 text-orange-600 border-orange-500/30",
  critical: "bg-red-500/15 text-red-600 border-red-500/30",
};

const TYPE_COLORS: Record<string, string> = {
  sql_injection:     "#ef4444",
  xss:               "#f97316",
  rate_limit:        "#eab308",
  blocked_ip:        "#8b5cf6",
  oversized_request: "#06b6d4",
  suspicious_agent:  "#64748b",
};

function SeverityBadge({ severity }: { severity: string }) {
  return (
    <Badge className={`text-[10px] font-semibold px-1.5 border ${SEVERITY_COLORS[severity] ?? "bg-gray-100 text-gray-600"}`}>
      {severity.toUpperCase()}
    </Badge>
  );
}

function ThreatBadge({ type }: { type: string }) {
  return (
    <Badge variant="outline" className="text-[10px] font-mono px-1.5">
      {THREAT_LABELS[type] ?? type}
    </Badge>
  );
}

/* ──────────────────────────────────────────────
   Shared Sub-components
────────────────────────────────────────────── */
function ActionBadge({ action }: { action: string }) {
  if (action === "login")
    return <Badge className="bg-emerald-500/15 text-emerald-600 border border-emerald-500/30 text-[10px] font-semibold px-2">LOGIN</Badge>;
  if (action === "logout")
    return <Badge className="bg-sky-500/15 text-sky-600 border border-sky-500/30 text-[10px] font-semibold px-2">LOGOUT</Badge>;
  if (action === "failed_login")
    return <Badge className="bg-red-500/15 text-red-600 border border-red-500/30 text-[10px] font-semibold px-2">FAILED</Badge>;
  return <Badge variant="outline" className="text-[10px] px-2">{action}</Badge>;
}

function ActionIcon({ action }: { action: string }) {
  if (action === "login") return <div className="p-1.5 rounded-full bg-emerald-500/10"><CheckCircle className="h-3.5 w-3.5 text-emerald-500" /></div>;
  if (action === "logout") return <div className="p-1.5 rounded-full bg-sky-500/10"><XCircle className="h-3.5 w-3.5 text-sky-500" /></div>;
  if (action === "failed_login") return <div className="p-1.5 rounded-full bg-red-500/10"><XCircle className="h-3.5 w-3.5 text-red-500" /></div>;
  return <div className="p-1.5 rounded-full bg-gray-500/10"><UserCheck className="h-3.5 w-3.5 text-gray-500" /></div>;
}

function StatCard({ icon, label, value, sub, color }: {
  icon: React.ReactNode; label: string; value: string | number; sub?: string; color: string;
}) {
  return (
    <Card className={`border-l-4 ${color} bg-card`}>
      <CardContent className="pt-5 pb-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{label}</p>
            <p className="text-3xl font-bold mt-1">{value}</p>
            {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
          </div>
          <div className="opacity-70 mt-1">{icon}</div>
        </div>
      </CardContent>
    </Card>
  );
}

/* ──────────────────────────────────────────────
   Main Page
────────────────────────────────────────────── */
export default function SystemLogsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // ── Auth log state ──
  const [selectedLog, setSelectedLog] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [filterAction, setFilterAction] = useState("all");
  const [activeTab, setActiveTab] = useState("auth");

  // ── Security dashboard state ──
  const [secPage, setSecPage]           = useState(1);
  const [secPageSize]                   = useState(25);
  const [severityFilter, setSeverity]   = useState("all");
  const [typeFilter, setTypeFilter]     = useState("all");
  const [ipFilter, setIpFilter]         = useState("");
  const [newBlockIp, setNewBlockIp]     = useState("");
  const [newBlockReason, setNewBlockReason] = useState("");
  const [showAddBlock, setShowAddBlock] = useState(false);

  /* ── Data fetching — auth ── */
  const { data: logFiles = [], refetch: refetchLogs, isFetching } = useQuery({
    queryKey: ["/api/logs"],
    queryFn: async () => {
      const res = await fetch("/api/logs", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch logs");
      return res.json() as Promise<string[]>;
    },
    refetchInterval: 60_000,
  });

  const { data: logContent } = useQuery({
    queryKey: ["/api/logs", selectedLog],
    queryFn: async () => {
      const res = await fetch(`/api/logs/${selectedLog}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch log content");
      return res.json() as Promise<{ filename: string; content: string }>;
    },
    enabled: !!selectedLog,
  });

  const authLogs  = logFiles.filter((f) => f.startsWith("auth_"));
  const otherLogs = logFiles.filter((f) => !f.startsWith("auth_"));

  const authEntries: any[] = useMemo(() => {
    if (!logContent || !selectedLog?.startsWith("auth_")) return [];
    return parseAuthLog(logContent.content);
  }, [logContent, selectedLog]);

  const { data: latestAuthContent } = useQuery({
    queryKey: ["/api/logs/latest-auth", authLogs[authLogs.length - 1]],
    queryFn: async () => {
      const file = authLogs[authLogs.length - 1];
      if (!file) return null;
      const res = await fetch(`/api/logs/${file}`, { credentials: "include" });
      if (!res.ok) return null;
      return res.json() as Promise<{ filename: string; content: string }>;
    },
    enabled: authLogs.length > 0,
  });

  const latestEntries: any[] = useMemo(() => {
    if (!latestAuthContent) return [];
    return parseAuthLog(latestAuthContent.content);
  }, [latestAuthContent]);

  const stats = useMemo(() => {
    const logins  = latestEntries.filter((e) => e.action === "login").length;
    const logouts = latestEntries.filter((e) => e.action === "logout").length;
    const failed  = latestEntries.filter((e) => e.action === "failed_login").length;
    const unique  = new Set(latestEntries.map((e) => e.username).filter(Boolean)).size;
    return { logins, logouts, failed, unique };
  }, [latestEntries]);

  const hourlyChart = useMemo(() => buildHourlyChart(authEntries.length ? authEntries : latestEntries), [authEntries, latestEntries]);

  const filteredEntries = useMemo(() => {
    return authEntries.filter((e) => {
      const matchSearch =
        !search ||
        (e.username || "").toLowerCase().includes(search.toLowerCase()) ||
        (e.ipAddress || "").includes(search);
      const matchAction = filterAction === "all" || e.action === filterAction;
      return matchSearch && matchAction;
    });
  }, [authEntries, search, filterAction]);

  /* ── Data fetching — security ── */
  const { data: secStats, refetch: refetchSecStats } = useQuery({
    queryKey: ["/api/security/stats"],
    queryFn: async () => {
      const res = await fetch("/api/security/stats", { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    refetchInterval: 30_000,
  });

  const { data: secEventsData, refetch: refetchSecEvents } = useQuery({
    queryKey: ["/api/security/events", secPage, secPageSize, severityFilter, typeFilter, ipFilter],
    queryFn: async () => {
      const params = new URLSearchParams({
        page: String(secPage),
        pageSize: String(secPageSize),
        severityFilter,
        typeFilter,
        ipFilter,
      });
      const res = await fetch(`/api/security/events?${params}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    refetchInterval: 30_000,
  });

  const { data: blockedIpsList = [], refetch: refetchBlocked } = useQuery({
    queryKey: ["/api/security/blocked-ips"],
    queryFn: async () => {
      const res = await fetch("/api/security/blocked-ips", { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  const blockIpMutation = useMutation({
    mutationFn: async ({ ip, reason }: { ip: string; reason: string }) => {
      const res = await fetch("/api/security/blocked-ips", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ ip, reason }),
      });
      if (!res.ok) throw new Error((await res.json()).error ?? "Failed");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "IP blocked", description: `${newBlockIp} has been added to the blocklist.` });
      setNewBlockIp(""); setNewBlockReason(""); setShowAddBlock(false);
      refetchBlocked(); refetchSecStats();
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const unblockIpMutation = useMutation({
    mutationFn: async (ip: string) => {
      const res = await fetch(`/api/security/blocked-ips/${encodeURIComponent(ip)}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    onSuccess: (_, ip) => {
      toast({ title: "IP unblocked", description: `${ip} has been removed from the blocklist.` });
      refetchBlocked(); refetchSecStats();
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  /* ── Actions ── */
  const downloadLog = () => {
    if (!logContent) return;
    const blob = new Blob([logContent.content], { type: "text/plain" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url; a.download = logContent.filename; a.click();
    URL.revokeObjectURL(url);
  };

  const formatFileLabel = (f: string) =>
    f.replace("auth_", "").replace(".log", "").replace(/_/g, " ");

  const secEvents     = secEventsData?.data ?? [];
  const secTotal      = secEventsData?.total ?? 0;
  const secTotalPages = secEventsData?.totalPages ?? 1;

  const activeBlocked = (blockedIpsList as any[]).filter((b) => !b.unblocked);
  const topType       = secStats?.byType
    ? Object.entries(secStats.byType as Record<string, number>)
        .sort((a, b) => b[1] - a[1])[0]
    : null;

  /* ── Render ── */
  return (
    <div className="space-y-6 p-6">
      {/* ── Header ── */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            Security & Audit Dashboard
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Monitor authentication events, system logs, and real-time threat intelligence
          </p>
        </div>
        <Button onClick={() => { refetchLogs(); refetchSecStats(); refetchSecEvents(); refetchBlocked(); }}
          variant="outline" disabled={isFetching} className="flex items-center gap-2">
          <RefreshCw className={`h-4 w-4 ${isFetching ? "animate-spin" : ""}`} />
          {isFetching ? "Refreshing..." : "Refresh"}
        </Button>
      </div>

      {/* ── Auth Stats Cards ── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={<CheckCircle className="h-8 w-8 text-emerald-500" />} label="Successful Logins"  value={stats.logins}  sub="Latest log file"    color="border-l-emerald-500" />
        <StatCard icon={<XCircle     className="h-8 w-8 text-red-500"     />} label="Failed Attempts"   value={stats.failed}  sub="Potential threats"  color="border-l-red-500" />
        <StatCard icon={<Users       className="h-8 w-8 text-violet-500"  />} label="Unique Users"      value={stats.unique}  sub="Distinct accounts"  color="border-l-violet-500" />
        <StatCard icon={<FileText    className="h-8 w-8 text-sky-500"     />} label="Log Files"         value={logFiles.length} sub={`${authLogs.length} auth · ${otherLogs.length} system`} color="border-l-sky-500" />
      </div>

      {/* ── Activity Chart ── */}
      {hourlyChart.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4 text-primary" />
              <CardTitle className="text-base">Authentication Activity — Hourly Breakdown</CardTitle>
            </div>
            <CardDescription>
              {selectedLog ? formatFileLabel(selectedLog) : "Latest log file"} · login / logout / failed events per hour
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={hourlyChart} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="gLogin" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#10b981" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gFailed" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#ef4444" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="hour" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }}
                  formatter={(v: number, name: string) => [v, name.charAt(0).toUpperCase() + name.slice(1)]} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                <Area type="monotone" dataKey="login"  stroke="#10b981" fill="url(#gLogin)"  strokeWidth={2} />
                <Area type="monotone" dataKey="failed" stroke="#ef4444" fill="url(#gFailed)" strokeWidth={2} />
                <Area type="monotone" dataKey="logout" stroke="#38bdf8" fill="none"          strokeWidth={1.5} strokeDasharray="4 2" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* ── Tabs ── */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid grid-cols-3 w-full sm:w-auto sm:inline-flex">
          <TabsTrigger value="auth" className="flex items-center gap-1.5">
            <Shield className="h-4 w-4" /> Auth Logs
          </TabsTrigger>
          <TabsTrigger value="all" className="flex items-center gap-1.5">
            <Monitor className="h-4 w-4" /> System Logs
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-1.5">
            <ShieldAlert className="h-4 w-4" /> Security
            {secStats?.last24h > 0 && (
              <span className="ml-1 bg-red-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full leading-none">
                {secStats.last24h}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        {/* ────────── Authentication Logs Tab ────────── */}
        <TabsContent value="auth" className="space-y-0">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
            <Card className="lg:col-span-1">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" /> Auth Log Files
                </CardTitle>
                <CardDescription className="text-xs">{authLogs.length} file{authLogs.length !== 1 ? "s" : ""} available</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[520px]">
                  <div className="px-3 pb-3 space-y-1">
                    {authLogs.length === 0 ? (
                      <p className="text-xs text-muted-foreground text-center py-8">No auth log files found</p>
                    ) : (
                      [...authLogs].reverse().map((file) => (
                        <button key={file} onClick={() => setSelectedLog(file)}
                          className={`w-full flex items-center gap-2 text-left rounded-lg px-3 py-2.5 text-sm transition-colors ${
                            selectedLog === file ? "bg-primary text-primary-foreground" : "hover:bg-accent text-foreground"
                          }`}>
                          <Shield className="h-3.5 w-3.5 shrink-0 opacity-60" />
                          <span className="flex-1 truncate font-medium">{formatFileLabel(file)}</span>
                          <ChevronRight className="h-3 w-3 opacity-40 shrink-0" />
                        </button>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            <Card className="lg:col-span-3">
              <CardHeader className="pb-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Eye className="h-4 w-4 text-muted-foreground" />
                      {selectedLog ? `Events — ${formatFileLabel(selectedLog)}` : "Authentication Events"}
                    </CardTitle>
                    <CardDescription className="text-xs mt-0.5">
                      {selectedLog
                        ? `${filteredEntries.length} event${filteredEntries.length !== 1 ? "s" : ""} shown`
                        : "Select a log file from the left to view events"}
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {selectedLog && (
                      <Button size="sm" variant="outline" onClick={downloadLog} className="h-8 text-xs">
                        <Download className="h-3.5 w-3.5 mr-1" /> Download
                      </Button>
                    )}
                  </div>
                </div>
                {selectedLog && (
                  <div className="flex flex-col sm:flex-row gap-2 mt-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                      <Input placeholder="Search username or IP..." value={search}
                        onChange={(e) => setSearch(e.target.value)} className="pl-8 h-8 text-xs" />
                    </div>
                    <Select value={filterAction} onValueChange={setFilterAction}>
                      <SelectTrigger className="w-36 h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Events</SelectItem>
                        <SelectItem value="login">Login Only</SelectItem>
                        <SelectItem value="logout">Logout Only</SelectItem>
                        <SelectItem value="failed_login">Failed Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[460px]">
                  {!selectedLog ? (
                    <div className="flex flex-col items-center justify-center h-40 text-center text-muted-foreground gap-2">
                      <Shield className="h-10 w-10 opacity-20" />
                      <p className="text-sm">Select a log file to view authentication events</p>
                    </div>
                  ) : filteredEntries.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-40 text-center text-muted-foreground gap-2">
                      <Search className="h-8 w-8 opacity-20" />
                      <p className="text-sm">No events match current filters</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-border">
                      {filteredEntries.map((entry: any, idx: number) => (
                        <div key={idx}
                          className={`flex items-start gap-3 px-4 py-3 hover:bg-accent/50 transition-colors ${
                            entry.action === "failed_login" ? "bg-red-500/5" : ""
                          }`}>
                          <ActionIcon action={entry.action} />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <ActionBadge action={entry.action} />
                              <span className="font-semibold text-sm">{entry.username || "Unknown"}</span>
                              {entry.ipAddress && (
                                <span className="text-xs text-muted-foreground font-mono bg-muted px-1.5 py-0.5 rounded">
                                  {entry.ipAddress}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {entry.timestamp ? new Date(entry.timestamp).toLocaleString() : "—"}
                              </span>
                              {entry.userAgent && (
                                <span className="truncate max-w-xs hidden sm:block opacity-70">
                                  {entry.userAgent}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ────────── System Logs Tab ────────── */}
        <TabsContent value="all" className="space-y-0">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
            <Card className="lg:col-span-1">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <FileText className="h-4 w-4 text-muted-foreground" /> All Log Files
                </CardTitle>
                <CardDescription className="text-xs">{logFiles.length} file{logFiles.length !== 1 ? "s" : ""} total</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[520px]">
                  <div className="px-3 pb-3 space-y-1">
                    {authLogs.length > 0 && (
                      <>
                        <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground px-2 pt-2 pb-1">Auth Logs</p>
                        {[...authLogs].reverse().map((file) => (
                          <button key={file} onClick={() => setSelectedLog(file)}
                            className={`w-full flex items-center gap-2 text-left rounded-lg px-3 py-2.5 text-sm transition-colors ${
                              selectedLog === file ? "bg-primary text-primary-foreground" : "hover:bg-accent"
                            }`}>
                            <Shield className="h-3.5 w-3.5 shrink-0 opacity-60" />
                            <span className="flex-1 truncate">{formatFileLabel(file)}</span>
                          </button>
                        ))}
                      </>
                    )}
                    {otherLogs.length > 0 && (
                      <>
                        <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground px-2 pt-3 pb-1">System Logs</p>
                        {otherLogs.map((file) => (
                          <button key={file} onClick={() => setSelectedLog(file)}
                            className={`w-full flex items-center gap-2 text-left rounded-lg px-3 py-2.5 text-sm transition-colors ${
                              selectedLog === file ? "bg-primary text-primary-foreground" : "hover:bg-accent"
                            }`}>
                            <FileText className="h-3.5 w-3.5 shrink-0 opacity-60" />
                            <span className="flex-1 truncate">{file}</span>
                          </button>
                        ))}
                      </>
                    )}
                    {logFiles.length === 0 && (
                      <p className="text-xs text-muted-foreground text-center py-8">No log files found</p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            <Card className="lg:col-span-3">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Monitor className="h-4 w-4 text-muted-foreground" />
                      {selectedLog ? selectedLog : "Log Viewer"}
                    </CardTitle>
                    <CardDescription className="text-xs mt-0.5">
                      {logContent
                        ? `${logContent.content.split("\n").length.toLocaleString()} lines`
                        : "Select a file to view its contents"}
                    </CardDescription>
                  </div>
                  {selectedLog && logContent && (
                    <Button size="sm" variant="outline" onClick={downloadLog} className="h-8 text-xs">
                      <Download className="h-3.5 w-3.5 mr-1" /> Download
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="p-0 px-4 pb-4">
                {logContent ? (
                  <ScrollArea className="h-[490px] rounded-lg border border-border overflow-hidden">
                    <pre className="text-[11px] leading-relaxed font-mono bg-slate-950 text-green-400 p-4 min-h-full whitespace-pre-wrap break-all">
                      {logContent.content}
                    </pre>
                  </ScrollArea>
                ) : (
                  <div className="h-[490px] rounded-lg border border-dashed border-border flex flex-col items-center justify-center text-muted-foreground gap-3">
                    <Monitor className="h-12 w-12 opacity-15" />
                    <p className="text-sm">Select a log file to view raw content</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ════════════ Security Dashboard Tab ════════════ */}
        <TabsContent value="security" className="space-y-6">

          {/* ── Security Stat Cards ── */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              icon={<AlertTriangle className="h-8 w-8 text-red-500" />}
              label="Threats (24 h)"
              value={secStats?.last24h ?? 0}
              sub="Blocked requests"
              color="border-l-red-500"
            />
            <StatCard
              icon={<Zap className="h-8 w-8 text-orange-500" />}
              label="All-time Threats"
              value={secStats?.total ?? 0}
              sub="Since monitoring start"
              color="border-l-orange-500"
            />
            <StatCard
              icon={<Ban className="h-8 w-8 text-violet-500" />}
              label="Blocked IPs"
              value={secStats?.blockedIpsCount ?? 0}
              sub="Currently active bans"
              color="border-l-violet-500"
            />
            <StatCard
              icon={<TrendingUp className="h-8 w-8 text-amber-500" />}
              label="Top Threat"
              value={topType ? THREAT_LABELS[topType[0]] ?? topType[0] : "—"}
              sub={topType ? `${topType[1]} occurrences` : "No data yet"}
              color="border-l-amber-500"
            />
          </div>

          {/* ── Charts row ── */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Daily threats chart */}
            <Card className="lg:col-span-2">
              <CardHeader className="pb-2">
                <div className="flex items-center gap-2">
                  <Activity className="h-4 w-4 text-primary" />
                  <CardTitle className="text-base">Blocked Requests — Last 7 Days</CardTitle>
                </div>
                <CardDescription>Daily count of requests blocked by all security layers</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={secStats?.dailyChart ?? []} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }}
                      tickFormatter={(v) => new Date(v).toLocaleDateString(undefined, { month: "short", day: "numeric" })} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                    <Tooltip
                      contentStyle={{ fontSize: 12, borderRadius: 8 }}
                      labelFormatter={(v) => new Date(v).toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })}
                    />
                    <Bar dataKey="count" fill="#ef4444" radius={[3, 3, 0, 0]} name="Blocked" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Threat type breakdown */}
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-primary" />
                  <CardTitle className="text-base">By Threat Type</CardTitle>
                </div>
                <CardDescription>All-time distribution</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 pt-1">
                {secStats?.byType && Object.keys(secStats.byType).length > 0 ? (
                  Object.entries(secStats.byType as Record<string, number>)
                    .sort((a, b) => b[1] - a[1])
                    .map(([type, count]) => {
                      const total = secStats.total || 1;
                      const pct   = Math.round((count / total) * 100);
                      return (
                        <div key={type}>
                          <div className="flex items-center justify-between text-xs mb-0.5">
                            <span className="font-medium">{THREAT_LABELS[type] ?? type}</span>
                            <span className="text-muted-foreground">{count} ({pct}%)</span>
                          </div>
                          <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                            <div className="h-full rounded-full transition-all"
                              style={{ width: `${pct}%`, backgroundColor: TYPE_COLORS[type] ?? "#94a3b8" }} />
                          </div>
                        </div>
                      );
                    })
                ) : (
                  <p className="text-xs text-muted-foreground text-center py-6">No threats recorded yet</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* ── Top Attacker IPs + Event Feed ── */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
            {/* Top IPs sidebar */}
            <Card className="lg:col-span-1">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Globe className="h-4 w-4 text-muted-foreground" /> Top Attackers
                </CardTitle>
                <CardDescription className="text-xs">IPs with most blocked requests</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[420px]">
                  <div className="px-3 pb-3 space-y-1.5 pt-1">
                    {secStats?.topIps?.length > 0 ? (
                      (secStats.topIps as { ip: string; count: number }[]).map(({ ip, count }, i) => (
                        <div key={ip} className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-accent/50 transition-colors">
                          <span className="text-[10px] text-muted-foreground w-4 text-center font-bold">{i + 1}</span>
                          <span className="font-mono text-xs flex-1 truncate">{ip}</span>
                          <Badge variant="outline" className="text-[10px] shrink-0">{count}</Badge>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-muted-foreground text-center py-8">No data</p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Event feed */}
            <Card className="lg:col-span-3">
              <CardHeader className="pb-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Eye className="h-4 w-4 text-muted-foreground" /> Live Threat Feed
                    </CardTitle>
                    <CardDescription className="text-xs mt-0.5">
                      {secTotal.toLocaleString()} event{secTotal !== 1 ? "s" : ""} total · page {secPage} of {secTotalPages}
                    </CardDescription>
                  </div>
                </div>
                {/* Filters */}
                <div className="flex flex-col sm:flex-row gap-2 mt-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                    <Input placeholder="Filter by IP…" value={ipFilter}
                      onChange={(e) => { setIpFilter(e.target.value); setSecPage(1); }}
                      className="pl-8 h-8 text-xs" />
                  </div>
                  <Select value={typeFilter} onValueChange={(v) => { setTypeFilter(v); setSecPage(1); }}>
                    <SelectTrigger className="w-40 h-8 text-xs"><SelectValue placeholder="Threat type" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      {Object.entries(THREAT_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <Select value={severityFilter} onValueChange={(v) => { setSeverity(v); setSecPage(1); }}>
                    <SelectTrigger className="w-32 h-8 text-xs"><SelectValue placeholder="Severity" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Severity</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[330px]">
                  {secEvents.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-2 py-12">
                      <ShieldAlert className="h-10 w-10 opacity-20" />
                      <p className="text-sm">No threat events recorded yet</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-border">
                      {secEvents.map((ev: any) => (
                        <div key={ev.id} className={`flex items-start gap-3 px-4 py-2.5 hover:bg-accent/50 transition-colors ${
                          ev.severity === "critical" ? "bg-red-500/5" : ev.severity === "high" ? "bg-orange-500/5" : ""
                        }`}>
                          <div className={`mt-0.5 p-1.5 rounded-full ${
                            ev.severity === "critical" ? "bg-red-500/15" :
                            ev.severity === "high"     ? "bg-orange-500/15" :
                            ev.severity === "medium"   ? "bg-yellow-500/15" : "bg-blue-500/15"
                          }`}>
                            <AlertTriangle className={`h-3 w-3 ${
                              ev.severity === "critical" ? "text-red-500" :
                              ev.severity === "high"     ? "text-orange-500" :
                              ev.severity === "medium"   ? "text-yellow-500" : "text-blue-500"
                            }`} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <SeverityBadge severity={ev.severity} />
                              <ThreatBadge type={ev.threatType} />
                              <code className="text-xs font-mono bg-muted px-1 rounded">{ev.ip}</code>
                              <span className="text-xs text-muted-foreground font-mono truncate max-w-[180px]">{ev.path}</span>
                            </div>
                            <div className="flex items-center gap-3 mt-0.5 text-[11px] text-muted-foreground">
                              <span>{new Date(ev.createdAt).toLocaleString()}</span>
                              {ev.details && <span className="truncate max-w-[240px] opacity-70">{ev.details}</span>}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
                {/* Pagination */}
                <div className="flex items-center justify-between px-4 py-2 border-t border-border">
                  <span className="text-xs text-muted-foreground">
                    {secTotal === 0 ? "0 results" : `${(secPage - 1) * secPageSize + 1}–${Math.min(secPage * secPageSize, secTotal)} of ${secTotal}`}
                  </span>
                  <div className="flex items-center gap-1">
                    <Button size="sm" variant="outline" className="h-7 w-7 p-0"
                      disabled={secPage <= 1} onClick={() => setSecPage((p) => p - 1)}>
                      <ChevronLeft className="h-3.5 w-3.5" />
                    </Button>
                    <span className="text-xs px-2">{secPage} / {secTotalPages}</span>
                    <Button size="sm" variant="outline" className="h-7 w-7 p-0"
                      disabled={secPage >= secTotalPages} onClick={() => setSecPage((p) => p + 1)}>
                      <ChevronRightIcon className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* ── Blocked IPs Management ── */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Ban className="h-4 w-4 text-violet-500" /> Blocked IP Addresses
                  </CardTitle>
                  <CardDescription className="text-xs mt-0.5">
                    {activeBlocked.length} active ban{activeBlocked.length !== 1 ? "s" : ""} · auto-bans trigger after 10 threats in 10 minutes
                  </CardDescription>
                </div>
                <Button size="sm" variant="outline" onClick={() => setShowAddBlock((v) => !v)} className="h-8 text-xs gap-1.5 shrink-0">
                  <Plus className="h-3.5 w-3.5" /> Block IP
                </Button>
              </div>

              {/* Add block form */}
              {showAddBlock && (
                <div className="flex flex-col sm:flex-row gap-2 mt-3 pt-3 border-t border-border">
                  <Input placeholder="IP address (e.g. 192.168.1.100)" value={newBlockIp}
                    onChange={(e) => setNewBlockIp(e.target.value)} className="h-8 text-xs flex-1" />
                  <Input placeholder="Reason (optional)" value={newBlockReason}
                    onChange={(e) => setNewBlockReason(e.target.value)} className="h-8 text-xs flex-1" />
                  <Button size="sm" className="h-8 text-xs gap-1.5 shrink-0"
                    disabled={!newBlockIp || blockIpMutation.isPending}
                    onClick={() => blockIpMutation.mutate({ ip: newBlockIp, reason: newBlockReason || "Manually blocked by admin" })}>
                    <Ban className="h-3.5 w-3.5" />
                    {blockIpMutation.isPending ? "Blocking…" : "Block"}
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[280px]">
                {blockedIpsList.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-2 py-10">
                    <Shield className="h-10 w-10 opacity-15" />
                    <p className="text-sm">No blocked IPs</p>
                  </div>
                ) : (
                  <div className="divide-y divide-border">
                    {(blockedIpsList as any[]).map((b) => (
                      <div key={b.id} className={`flex items-center gap-3 px-4 py-3 hover:bg-accent/40 transition-colors ${b.unblocked ? "opacity-50" : ""}`}>
                        <div className={`p-1.5 rounded-full ${b.unblocked ? "bg-gray-500/10" : "bg-violet-500/15"}`}>
                          {b.unblocked
                            ? <Unlock className="h-3.5 w-3.5 text-gray-500" />
                            : <Ban    className="h-3.5 w-3.5 text-violet-500" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <code className="text-sm font-mono font-semibold">{b.ip}</code>
                            <Badge variant="outline" className={`text-[10px] ${b.blockedBy === "auto" ? "border-orange-500/40 text-orange-600" : "border-violet-500/40 text-violet-600"}`}>
                              {b.blockedBy === "auto" ? "Auto-banned" : "Manual"}
                            </Badge>
                            {b.unblocked && <Badge variant="outline" className="text-[10px] text-muted-foreground">Unblocked</Badge>}
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5 truncate">{b.reason}</p>
                          <p className="text-[10px] text-muted-foreground opacity-70">{new Date(b.createdAt).toLocaleString()}</p>
                        </div>
                        {!b.unblocked && (
                          <Button size="sm" variant="outline" className="h-7 text-xs gap-1 shrink-0"
                            disabled={unblockIpMutation.isPending}
                            onClick={() => unblockIpMutation.mutate(b.ip)}>
                            <Unlock className="h-3 w-3" /> Unblock
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

        </TabsContent>
        {/* ─────────────────────────────────────────────── */}
      </Tabs>
    </div>
  );
}
