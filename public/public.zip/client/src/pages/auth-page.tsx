import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useQueryClient } from "@tanstack/react-query";
import {
  EyeIcon, EyeOffIcon, LockIcon, ShieldCheckIcon, UsersIcon,
  BarChart3Icon, ServerIcon, MonitorIcon, Shield, UserIcon,
  KeyRound, Fingerprint, ChevronRight
} from "lucide-react";

export default function AuthPage() {
  const [, setLocation] = useLocation();
  const { user, login } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Login form state
  const [loginData, setLoginData] = useState({ username: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // MFA state
  const [mfaRequired, setMfaRequired] = useState(false);
  const [mfaUserId, setMfaUserId] = useState<number | null>(null);
  const [mfaCode, setMfaCode] = useState("");

  /* ── Handlers ── */
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    try {
      const response = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(loginData),
      });
      const data = await response.json();

      if (response.ok) {
        if (data.requiresPasswordChange) {
          toast({ title: "Password Change Required", description: data.message });
          setTimeout(() => setLocation("/profile?changePassword=true"), 100);
        } else if (data.requiresMfa) {
          setMfaRequired(true);
          setMfaUserId(data.userId);
          toast({ title: "MFA Required", description: data.message });
        } else if (data.requiresMfaSetup) {
          login(data);
          toast({ title: "MFA Setup Required", description: "Set up Two-Factor Authentication to continue." });
          queryClient.invalidateQueries({ queryKey: ["/api/user"] });
          setTimeout(() => setLocation("/mfa-setup"), 100);
        } else {
          queryClient.invalidateQueries({ queryKey: ["/api/user"] });
          toast({ title: "Login successful", description: `Welcome back, ${data.firstName || data.username}!` });
          setLocation("/");
        }
      } else {
        toast({ title: "Login failed", description: data.message || "Invalid credentials", variant: "destructive" });
      }
    } catch {
      toast({ title: "Login failed", description: "Network error. Please try again.", variant: "destructive" });
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleMfaVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (mfaCode.length !== 6) {
      toast({ title: "Invalid Code", description: "Enter a 6-digit code from your authenticator app.", variant: "destructive" });
      return;
    }
    setIsLoggingIn(true);
    try {
      const response = await fetch("/api/mfa/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ userId: mfaUserId, token: mfaCode }),
      });
      if (response.ok) {
        const userData = await response.json();
        if (!userData.user?.username || !userData.user?.id) throw new Error("Invalid user data");
        queryClient.clear();
        login(userData.user);
        toast({ title: "Login successful", description: `Welcome back, ${userData.user.firstName || userData.user.username}!` });
        setTimeout(async () => {
          try {
            const verify = await fetch("/api/user", { credentials: "include", headers: { "Cache-Control": "no-cache" } });
            if (verify.ok) window.location.href = "/";
            else throw new Error("Session check failed");
          } catch {
            toast({ title: "Session Error", description: "Please log in again.", variant: "destructive" });
            setTimeout(() => (window.location.href = "/auth"), 2000);
          }
        }, 800);
      } else {
        const err = await response.json();
        setMfaCode("");
        toast({ title: "Verification failed", description: err.message || "Invalid code", variant: "destructive" });
      }
    } catch {
      setMfaCode("");
      toast({ title: "Verification failed", description: "Network error.", variant: "destructive" });
    } finally {
      setIsLoggingIn(false);
    }
  };

  if (user) return null;

  /* ── Feature cards data ── */
  const features = [
    { icon: ServerIcon, title: "Hardware Management", desc: "Track computers, servers, network equipment and IT accessories with detailed specs", color: "from-emerald-500 to-teal-600" },
    { icon: MonitorIcon, title: "Virtual Machine Monitoring", desc: "Monitor VM performance, resource usage and automated health checks", color: "from-blue-500 to-indigo-600" },
    { icon: UsersIcon, title: "Asset Checkout System", desc: "Streamlined asset assignment, checkout/checkin workflows and user management", color: "from-amber-500 to-orange-600" },
    { icon: BarChart3Icon, title: "Comprehensive Reports", desc: "Asset lifecycle tracking, BitLocker key management and detailed audit trails", color: "from-violet-500 to-purple-600" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 relative overflow-hidden">
      {/* Background blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-200/40 rounded-full blur-3xl animate-pulse" style={{ animationDuration: "4s" }} />
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-indigo-200/40 rounded-full blur-3xl animate-pulse" style={{ animationDuration: "6s", animationDelay: "1s" }} />
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-cyan-200/30 rounded-full blur-3xl animate-pulse" style={{ animationDuration: "5s", animationDelay: "2s" }} />
      </div>

      {/* Dot grid */}
      <div className="absolute inset-0 opacity-50"
        style={{ backgroundImage: "radial-gradient(circle, #6366f1 1px, transparent 1px)", backgroundSize: "40px 40px" }} />

      <div className="relative z-10 flex min-h-screen">
        {/* ── Left branding panel ── */}
        <div className="hidden lg:flex flex-1 flex-col justify-center px-12 xl:px-20 py-12">
          {/* Logo row */}
          <div className="flex items-center gap-3 mb-14">
            <div className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse" />
            <ServerIcon className="w-5 h-5 text-emerald-600" />
            <span className="text-emerald-600 text-sm font-semibold tracking-widest uppercase">IT Asset Portal</span>
          </div>

          {/* Hero text */}
          <div className="space-y-5 mb-14">
            <h1 className="text-6xl xl:text-7xl font-bold bg-gradient-to-r from-slate-800 via-emerald-700 to-teal-800 bg-clip-text text-transparent leading-none">
              SRPH-MIS
            </h1>
            <h2 className="text-3xl font-light text-slate-600 dark:text-slate-300">Asset Management System</h2>
            <div className="w-28 h-1 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full" />
            <p className="text-slate-500 dark:text-slate-400 text-lg max-w-xl leading-relaxed">
              Comprehensive IT asset tracking and inventory management. Manage hardware, software licenses, virtual machines, and network resources.
            </p>
          </div>

          {/* Feature grid */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-5 max-w-2xl">
            {features.map((f, i) => (
              <div
                key={i}
                className="group flex items-start gap-4 p-5 rounded-2xl bg-white/70 dark:bg-gray-800/60 backdrop-blur-sm border border-white/60 dark:border-gray-700/40 hover:bg-white/90 dark:hover:bg-gray-800/90 hover:scale-[1.02] hover:shadow-xl transition-all duration-300 shadow-md"
              >
                <div className={`w-12 h-12 shrink-0 rounded-xl bg-gradient-to-br ${f.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                  <f.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-slate-800 dark:text-slate-200 font-semibold text-sm mb-1">{f.title}</h3>
                  <p className="text-slate-500 dark:text-slate-400 text-xs leading-relaxed">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Bottom trust bar */}
          <div className="mt-12 flex items-center gap-8 text-xs text-slate-500 dark:text-slate-500">
            {[
              { icon: ServerIcon, label: "Network Discovery" },
              { icon: MonitorIcon, label: "VM Monitoring" },
              { icon: ShieldCheckIcon, label: "BitLocker Keys" },
            ].map(({ icon: Icon, label }) => (
              <div key={label} className="flex items-center gap-1.5">
                <Icon className="w-4 h-4" />
                <span>{label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ── Right: Login card ── */}
        <div className="w-full lg:w-[520px] xl:w-[560px] flex items-center justify-center px-6 py-12">
          <div className="w-full max-w-md">

            {/* Card */}
            <div className="relative bg-white/95 dark:bg-gray-800/95 backdrop-blur-2xl rounded-3xl shadow-2xl shadow-slate-300/40 dark:shadow-black/40 border border-white/80 dark:border-gray-700/50 overflow-hidden">

              {/* Top color bar */}
              <div className="h-1.5 w-full bg-gradient-to-r from-emerald-400 via-teal-500 to-cyan-500" />

              {/* Header */}
              <div className="px-10 pt-10 pb-8 text-center">
                {/* Icon */}
                <div className="relative mx-auto w-20 h-20 mb-6">
                  <div className="absolute inset-0 bg-gradient-to-br from-emerald-400 to-teal-600 rounded-2xl rotate-6 opacity-20 blur-sm" />
                  <div className="relative w-20 h-20 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center shadow-xl shadow-emerald-500/30">
                    <LockIcon className="w-9 h-9 text-white" />
                  </div>
                </div>

                <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-1">
                  Welcome Back
                </h2>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  Sign in to SRPH-MIS Asset Management
                </p>

                {/* Security badge */}
                <div className="inline-flex items-center gap-1.5 mt-4 px-3 py-1.5 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-700/40 text-emerald-700 dark:text-emerald-400 rounded-full text-xs font-medium">
                  <ShieldCheckIcon className="w-3.5 h-3.5" />
                  Secured with 256-bit SSL encryption
                </div>
              </div>

              {/* Divider */}
              <div className="mx-10 h-px bg-gradient-to-r from-transparent via-slate-200 dark:via-gray-700 to-transparent" />

              {/* Form */}
              <div className="px-10 py-8">
                {!mfaRequired ? (
                  <form onSubmit={handleLogin} className="space-y-5">
                    {/* Username */}
                    <div className="space-y-2">
                      <Label htmlFor="username" className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                        Username
                      </Label>
                      <div className="relative">
                        <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
                          <UserIcon className="w-4 h-4" />
                        </div>
                        <Input
                          id="username"
                          type="text"
                          placeholder="Enter your username"
                          className="pl-10 h-12 rounded-xl bg-slate-50 dark:bg-gray-700 border-slate-200 dark:border-gray-600 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 text-slate-800 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-400 transition-all duration-200"
                          value={loginData.username}
                          onChange={(e) => setLoginData({ ...loginData, username: e.target.value })}
                          required
                        />
                      </div>
                    </div>

                    {/* Password */}
                    <div className="space-y-2">
                      <Label htmlFor="password" className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                        Password
                      </Label>
                      <div className="relative">
                        <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
                          <KeyRound className="w-4 h-4" />
                        </div>
                        <Input
                          id="password"
                          type={showPassword ? "text" : "password"}
                          placeholder="Enter your password"
                          className="pl-10 pr-12 h-12 rounded-xl bg-slate-50 dark:bg-gray-700 border-slate-200 dark:border-gray-600 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 text-slate-800 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-400 transition-all duration-200"
                          value={loginData.password}
                          onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors p-1"
                        >
                          {showPassword ? <EyeOffIcon className="w-4 h-4" /> : <EyeIcon className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Submit */}
                    <Button
                      type="submit"
                      disabled={isLoggingIn}
                      className="w-full h-12 mt-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-semibold shadow-lg shadow-emerald-500/25 hover:shadow-emerald-500/40 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 text-sm"
                    >
                      {isLoggingIn ? (
                        <span className="flex items-center gap-2">
                          <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                          Authenticating...
                        </span>
                      ) : (
                        <span className="flex items-center gap-2">
                          <LockIcon className="w-4 h-4" />
                          Access System
                          <ChevronRight className="w-4 h-4" />
                        </span>
                      )}
                    </Button>
                  </form>
                ) : (
                  /* ── MFA form ── */
                  <form onSubmit={handleMfaVerify} className="space-y-6">
                    <div className="text-center space-y-3">
                      <div className="w-16 h-16 mx-auto bg-blue-50 dark:bg-blue-900/20 rounded-2xl flex items-center justify-center">
                        <Fingerprint className="w-8 h-8 text-blue-600" />
                      </div>
                      <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Two-Factor Verification</h3>
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        Enter the 6-digit code from your authenticator app
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="mfaCode" className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                        Verification Code
                      </Label>
                      <Input
                        id="mfaCode"
                        type="text"
                        inputMode="numeric"
                        maxLength={6}
                        placeholder="000000"
                        className="h-14 rounded-xl text-center text-3xl tracking-[0.5em] font-mono bg-slate-50 dark:bg-gray-700 border-slate-200 dark:border-gray-600 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 text-slate-800 dark:text-slate-100"
                        value={mfaCode}
                        onChange={(e) => setMfaCode(e.target.value.replace(/\D/g, ""))}
                        required
                      />
                    </div>

                    <Button
                      type="submit"
                      disabled={isLoggingIn || mfaCode.length !== 6}
                      className="w-full h-12 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white font-semibold shadow-lg"
                    >
                      {isLoggingIn ? (
                        <span className="flex items-center gap-2">
                          <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                          Verifying...
                        </span>
                      ) : (
                        <span className="flex items-center gap-2">
                          <Shield className="w-4 h-4" />
                          Verify & Sign In
                        </span>
                      )}
                    </Button>

                    <button
                      type="button"
                      onClick={() => { setMfaRequired(false); setMfaCode(""); setMfaUserId(null); }}
                      className="w-full text-sm text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 transition-colors py-1"
                    >
                      ← Back to login
                    </button>
                  </form>
                )}
              </div>

              {/* Footer */}
              <div className="px-10 pb-8">
                <div className="pt-5 border-t border-slate-100 dark:border-gray-800">
                  <div className="flex items-center justify-center gap-6 text-[11px] text-slate-400 dark:text-slate-600">
                    <div className="flex items-center gap-1"><ShieldCheckIcon className="w-3 h-3 text-emerald-500" /> SSL Secured</div>
                    <div className="flex items-center gap-1"><LockIcon className="w-3 h-3 text-blue-500" /> Encrypted</div>
                    <div className="flex items-center gap-1"><Shield className="w-3 h-3 text-violet-500" /> MFA Ready</div>
                  </div>
                  <p className="text-center text-[11px] text-slate-400 dark:text-slate-600 mt-3">
                    © {new Date().getFullYear()} SRPH-MIS · All rights reserved
                  </p>
                </div>
              </div>

            </div>
            {/* End card */}

          </div>
        </div>
      </div>
    </div>
  );
}