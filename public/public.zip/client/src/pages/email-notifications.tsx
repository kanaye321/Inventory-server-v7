
import { useState, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Mail, Send, Settings, CheckCircle, AlertCircle, Loader2,
  RefreshCw, Clock, XCircle, Search, Filter, TrendingUp,
  Inbox, AlertTriangle, BarChart2, CalendarDays, AtSign,
  FileText, Zap, Globe,
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell,
} from "recharts";

/* ──────────────────────────────────────────────────────
   Helpers
────────────────────────────────────────────────────── */
function buildDailyCounts(logs: any[]) {
  const map: Record<string, { date: string; sent: number; failed: number }> = {};
  for (let d = 6; d >= 0; d--) {
    const day = new Date(Date.now() - d * 86_400_000);
    const key = day.toISOString().slice(0, 10);
    map[key] = { date: key, sent: 0, failed: 0 };
  }
  for (const log of logs) {
    const key = new Date(log.timestamp).toISOString().slice(0, 10);
    if (key in map) {
      if (log.status === "success") map[key].sent++;
      else map[key].failed++;
    }
  }
  return Object.values(map).map((d) => ({
    ...d,
    label: new Date(d.date).toLocaleDateString(undefined, { month: "short", day: "numeric" }),
  }));
}

function StatPill({ value, label, color }: { value: number; label: string; color: string }) {
  return (
    <div className={`flex flex-col items-center justify-center rounded-xl px-6 py-4 border-l-4 ${color} bg-card`}>
      <span className="text-3xl font-bold">{value}</span>
      <span className="text-xs text-muted-foreground mt-1 text-center">{label}</span>
    </div>
  );
}

/* ──────────────────────────────────────────────────────
   Main Component
────────────────────────────────────────────────────── */
export default function EmailNotificationsPage() {
  const { toast } = useToast();
  const [isTesting, setIsTesting] = useState(false);

  // ── Log filters ──
  const [search, setSearch]               = useState("");
  const [statusFilter, setStatusFilter]   = useState("all");
  const [typeFilter, setTypeFilter]       = useState("all");

  /* ── Queries ── */
  const { data: settings, isLoading } = useQuery({
    queryKey: ["/api/settings"],
    queryFn: async () => {
      const r = await apiRequest("GET", "/api/settings");
      return r.json();
    },
  });

  const { data: emailLogs = [], refetch: refetchLogs, isLoading: isLoadingLogs } = useQuery({
    queryKey: ["/api/email-logs"],
    queryFn: async () => {
      const r = await apiRequest("GET", "/api/email-logs");
      if (!r.ok) return [];
      const d = await r.json();
      return Array.isArray(d) ? d : [];
    },
    refetchInterval: 30_000,
  });

  /* ── Mutations ── */
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: any) => {
      const r = await apiRequest("POST", "/api/settings", data);
      return r.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Settings saved", description: "Email settings updated successfully." });
    },
    onError: () => toast({ title: "Error", description: "Failed to save settings.", variant: "destructive" }),
  });

  const testEmailMutation = useMutation({
    mutationFn: async () => (await apiRequest("POST", "/api/test-email")).json(),
    onSuccess: (d) => { toast({ title: "Test email sent", description: d.message || "Check your inbox." }); setIsTesting(false); },
    onError: (e: any) => { toast({ title: "Failed", description: e.message, variant: "destructive" }); setIsTesting(false); },
  });

  /* ── Settings handler ── */
  const handleSaveSettings = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const get = (k: string, def = "") => fd.get(k)?.toString() ?? settings?.[k] ?? def;
    updateSettingsMutation.mutate({
      mailHost: get("mailHost"), mailPort: get("mailPort", "587"),
      mailUsername: get("mailUsername"), mailPassword: get("mailPassword"),
      mailFromAddress: get("mailFromAddress"), mailFromName: get("mailFromName"),
      companyEmail: get("companyEmail"),
      iamExpirationEmailSubject: get("iamExpirationEmailSubject"),
      iamExpirationEmailBody: get("iamExpirationEmailBody"),
    });
  };

  /* ── Derived stats & filters ── */
  const totalSent   = (emailLogs as any[]).filter((l) => l.status === "success").length;
  const totalFailed = (emailLogs as any[]).filter((l) => l.status !== "success").length;
  const last24h     = (emailLogs as any[]).filter((l) => Date.now() - new Date(l.timestamp).getTime() < 86_400_000).length;
  const successRate = emailLogs.length ? Math.round((totalSent / emailLogs.length) * 100) : 0;

  const dailyChart = useMemo(() => buildDailyCounts(emailLogs as any[]), [emailLogs]);

  const uniqueTypes = useMemo(() =>
    [...new Set((emailLogs as any[]).map((l) => l.type ?? l.subject?.split(" ")[0] ?? "General").filter(Boolean))],
    [emailLogs]);

  const filteredLogs = useMemo(() => {
    return (emailLogs as any[]).filter((l) => {
      const matchSearch  = !search || (l.to ?? "").toLowerCase().includes(search.toLowerCase()) || (l.subject ?? "").toLowerCase().includes(search.toLowerCase());
      const matchStatus  = statusFilter === "all" || (statusFilter === "success" ? l.status === "success" : l.status !== "success");
      const matchType    = typeFilter === "all" || (l.type ?? l.subject)?.includes(typeFilter);
      return matchSearch && matchStatus && matchType;
    });
  }, [emailLogs, search, statusFilter, typeFilter]);

  const pieData = [
    { name: "Sent",   value: totalSent,   color: "#10b981" },
    { name: "Failed", value: totalFailed, color: "#ef4444" },
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="flex flex-col items-center gap-3 text-muted-foreground">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="text-sm">Loading email configuration…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* ── Header ── */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Mail className="h-6 w-6 text-primary" />
            Email Notifications
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            SMTP configuration, notification templates, and delivery logs
          </p>
        </div>
        <Button
          onClick={() => { setIsTesting(true); testEmailMutation.mutate(); }}
          disabled={isTesting}
          className="flex items-center gap-2"
        >
          {isTesting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          Send Test Email
        </Button>
      </div>

      <form onSubmit={handleSaveSettings} className="space-y-6">
        <Tabs defaultValue="smtp" className="space-y-4">
          <TabsList className="grid grid-cols-4 w-full sm:w-auto sm:inline-flex">
            <TabsTrigger value="smtp"        className="flex items-center gap-1.5"><Settings   className="h-4 w-4" />SMTP</TabsTrigger>
            <TabsTrigger value="preferences" className="flex items-center gap-1.5"><Zap        className="h-4 w-4" />Preferences</TabsTrigger>
            <TabsTrigger value="templates"   className="flex items-center gap-1.5"><FileText   className="h-4 w-4" />Templates</TabsTrigger>
            <TabsTrigger value="logs"        className="flex items-center gap-1.5">
              <Inbox className="h-4 w-4" />Logs
              {totalFailed > 0 && (
                <span className="ml-1 bg-red-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full leading-none">
                  {totalFailed}
                </span>
              )}
            </TabsTrigger>
          </TabsList>

          {/* ════════ SMTP Tab ════════ */}
          <TabsContent value="smtp" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Globe className="h-4 w-4 text-primary" /> SMTP Server Configuration
                </CardTitle>
                <CardDescription>Connect your mail server to enable outbound notifications</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="mailHost">SMTP Server</Label>
                    <Input id="mailHost" name="mailHost" placeholder="smtp.gmail.com" defaultValue={settings?.mailHost || ""} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mailPort">Port</Label>
                    <Input id="mailPort" name="mailPort" type="number" placeholder="587" defaultValue={settings?.mailPort || "587"} />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="mailUsername">Username</Label>
                    <Input id="mailUsername" name="mailUsername" placeholder="your-email@example.com" defaultValue={settings?.mailUsername || ""} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mailPassword">Password</Label>
                    <Input id="mailPassword" name="mailPassword" type="password" placeholder="••••••••" defaultValue={settings?.mailPassword || ""} />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="mailFromAddress">From Address</Label>
                    <Input id="mailFromAddress" name="mailFromAddress" type="email" placeholder="noreply@example.com" defaultValue={settings?.mailFromAddress || ""} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mailFromName">From Name</Label>
                    <Input id="mailFromName" name="mailFromName" placeholder="SRPH-MIS" defaultValue={settings?.mailFromName || "SRPH-MIS"} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="companyEmail">Admin Email (receives all system notifications)</Label>
                  <Input id="companyEmail" name="companyEmail" type="email" placeholder="admin@example.com" defaultValue={settings?.companyEmail || ""} />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ════════ Preferences Tab ════════ */}
          <TabsContent value="preferences" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-emerald-500/15 flex items-center justify-center">
                    <CheckCircle className="h-5 w-5 text-emerald-500" />
                  </div>
                  <div>
                    <CardTitle className="text-base">All Notifications Active</CardTitle>
                    <CardDescription>Email alerts fire automatically for all system events below</CardDescription>
                  </div>
                  <Badge className="ml-auto bg-emerald-500 text-white">ENABLED</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {[
                    { label: "Asset Check-out / Check-in",    icon: <CheckCircle className="h-4 w-4 text-emerald-500" />,  sub: "Always enabled" },
                    { label: "IAM Account Expiration",        icon: <AlertCircle className="h-4 w-4 text-amber-500" />,    sub: "Daily check" },
                    { label: "VM Expiration",                 icon: <AlertCircle className="h-4 w-4 text-amber-500" />,    sub: "Daily check" },
                    { label: "IT Equipment Changes",          icon: <CheckCircle className="h-4 w-4 text-emerald-500" />,  sub: "On every change" },
                    { label: "User Account Modifications",    icon: <CheckCircle className="h-4 w-4 text-emerald-500" />,  sub: "On every change" },
                    { label: "VM Inventory Changes",          icon: <CheckCircle className="h-4 w-4 text-emerald-500" />,  sub: "On every change" },
                    { label: "IAM Account Changes",           icon: <CheckCircle className="h-4 w-4 text-emerald-500" />,  sub: "On every change" },
                    { label: "GCP Resource Changes",          icon: <CheckCircle className="h-4 w-4 text-emerald-500" />,  sub: "On import" },
                    { label: "Azure Resource Changes",        icon: <CheckCircle className="h-4 w-4 text-emerald-500" />,  sub: "On import" },
                    { label: "Approval Expiration (1 week)", icon: <AlertTriangle className="h-4 w-4 text-orange-500" />, sub: "7-day warning" },
                    { label: "Asset / License Creation",      icon: <CheckCircle className="h-4 w-4 text-emerald-500" />,  sub: "On every change" },
                    { label: "System Alerts",                 icon: <AlertTriangle className="h-4 w-4 text-orange-500" />, sub: "Immediate" },
                  ].map(({ label, icon, sub }) => (
                    <div key={label} className="flex items-start gap-3 p-3 rounded-xl border bg-card hover:bg-accent/40 transition-colors">
                      <div className="mt-0.5">{icon}</div>
                      <div>
                        <p className="text-sm font-medium">{label}</p>
                        <p className="text-xs text-muted-foreground">{sub}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ════════ Templates Tab ════════ */}
          <TabsContent value="templates" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <FileText className="h-4 w-4 text-primary" /> IAM Expiration Email Template
                </CardTitle>
                <CardDescription>Sent to IAM account owners and the admin when access is about to expire</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="iamExpirationEmailSubject">Email Subject</Label>
                  <Input
                    id="iamExpirationEmailSubject"
                    name="iamExpirationEmailSubject"
                    placeholder="IAM Account Access Expiration Notice"
                    defaultValue={settings?.iamExpirationEmailSubject || "IAM Account Access Expiration Notice"}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="iamExpirationEmailBody">Email Body</Label>
                  <textarea
                    id="iamExpirationEmailBody"
                    name="iamExpirationEmailBody"
                    className="w-full min-h-[240px] p-3 rounded-lg border bg-background font-mono text-sm resize-y focus:outline-none focus:ring-2 focus:ring-primary/50"
                    defaultValue={settings?.iamExpirationEmailBody || `Hi,\n\nPlease be advised that your requested access is now expired and will be removed on {removalDate}.\n\nKindly let us know if you still require access or if we can now proceed with the removal.\n\nAccount Details:\n- Requestor: {requestor}\n- Knox ID: {knoxId}\n- Permission/IAM/SCOP: {permission}\n- Cloud Platform: {cloudPlatform}\n- Expiration Date: {endDate}\n- Approval ID: {approvalId}\n\nIf you need to extend your access, please submit a new request through the proper channels.`}
                  />
                </div>
                <div className="rounded-xl bg-muted/60 border p-4">
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Available Placeholders</p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {[
                      ["{removalDate}", "Removal date (+7 days)"],
                      ["{requestor}",   "Requestor name"],
                      ["{knoxId}",      "Knox ID"],
                      ["{permission}",  "Permission / IAM / SCOP"],
                      ["{cloudPlatform}", "Cloud platform"],
                      ["{endDate}",     "Expiration date"],
                      ["{approvalId}",  "Approval ID"],
                    ].map(([ph, desc]) => (
                      <div key={ph} className="flex items-start gap-1.5">
                        <code className="text-[11px] bg-background border px-1.5 py-0.5 rounded font-mono text-primary shrink-0">{ph}</code>
                        <span className="text-[11px] text-muted-foreground">{desc}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ════════ Logs Tab ════════ */}
          <TabsContent value="logs" className="space-y-4">

            {/* ── Stats row ── */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <StatPill value={emailLogs.length} label="Total Emails"   color="border-l-sky-500" />
              <StatPill value={totalSent}         label="Delivered"      color="border-l-emerald-500" />
              <StatPill value={totalFailed}       label="Failed"         color="border-l-red-500" />
              <StatPill value={last24h}           label="Last 24 hours"  color="border-l-violet-500" />
            </div>

            {/* ── Charts row ── */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Area chart */}
              <Card className="lg:col-span-2">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <BarChart2 className="h-4 w-4 text-primary" /> Delivery Volume — Last 7 Days
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={160}>
                    <AreaChart data={dailyChart} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                      <defs>
                        <linearGradient id="gSent"   x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%"  stopColor="#10b981" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="gFailed" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%"  stopColor="#ef4444" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                      <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                      <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                      <Area type="monotone" dataKey="sent"   stroke="#10b981" fill="url(#gSent)"   strokeWidth={2} name="Sent" />
                      <Area type="monotone" dataKey="failed" stroke="#ef4444" fill="url(#gFailed)" strokeWidth={2} name="Failed" />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Pie chart */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-primary" /> Success Rate
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col items-center">
                  {emailLogs.length === 0 ? (
                    <div className="h-[160px] flex items-center justify-center text-muted-foreground text-sm">No data yet</div>
                  ) : (
                    <>
                      <ResponsiveContainer width="100%" height={130}>
                        <PieChart>
                          <Pie data={pieData} cx="50%" cy="50%" innerRadius={40} outerRadius={60} dataKey="value" paddingAngle={3}>
                            {pieData.map((e, i) => <Cell key={i} fill={e.color} />)}
                          </Pie>
                          <Tooltip formatter={(v: number, n: string) => [v, n]} contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                        </PieChart>
                      </ResponsiveContainer>
                      <p className="text-3xl font-bold mt-1">{successRate}%</p>
                      <p className="text-xs text-muted-foreground">delivery success rate</p>
                      <div className="flex items-center gap-4 mt-3 text-xs">
                        <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-emerald-500 inline-block" /> Sent</span>
                        <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-red-500 inline-block" /> Failed</span>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* ── Log Feed ── */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Inbox className="h-4 w-4 text-primary" /> Email Delivery Log
                    </CardTitle>
                    <CardDescription className="text-xs mt-0.5">
                      {filteredLogs.length} of {emailLogs.length} email{emailLogs.length !== 1 ? "s" : ""} shown
                    </CardDescription>
                  </div>
                  <Button onClick={() => refetchLogs()} variant="outline" size="sm" className="h-8 text-xs gap-1.5 shrink-0">
                    <RefreshCw className="h-3.5 w-3.5" /> Refresh
                  </Button>
                </div>

                {/* Filters */}
                <div className="flex flex-col sm:flex-row gap-2 mt-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                    <Input
                      placeholder="Search recipient or subject…"
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      className="pl-8 h-8 text-xs"
                    />
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-36 h-8 text-xs"><SelectValue placeholder="Status" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="success">Delivered</SelectItem>
                      <SelectItem value="failed">Failed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="p-0">
                <ScrollArea className="h-[480px]">
                  {isLoadingLogs ? (
                    <div className="flex flex-col items-center justify-center h-40 gap-3 text-muted-foreground">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      <p className="text-sm">Loading email logs…</p>
                    </div>
                  ) : filteredLogs.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-40 gap-3 text-muted-foreground">
                      <Inbox className="h-12 w-12 opacity-15" />
                      <p className="text-sm font-medium">No emails match</p>
                      <p className="text-xs">Email notifications will appear here once sent</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-border">
                      {filteredLogs.map((log: any, idx: number) => {
                        const ok = log.status === "success";
                        return (
                          <div
                            key={idx}
                            className={`flex items-start gap-3 px-4 py-3.5 hover:bg-accent/40 transition-colors ${!ok ? "bg-red-500/5" : ""}`}
                          >
                            {/* Icon */}
                            <div className={`mt-0.5 p-2 rounded-full shrink-0 ${ok ? "bg-emerald-500/10" : "bg-red-500/10"}`}>
                              {ok
                                ? <CheckCircle className="h-4 w-4 text-emerald-500" />
                                : <XCircle    className="h-4 w-4 text-red-500" />
                              }
                            </div>

                            {/* Content */}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <Badge
                                  className={`text-[10px] font-semibold px-2 border ${
                                    ok
                                      ? "bg-emerald-500/10 text-emerald-700 border-emerald-500/30"
                                      : "bg-red-500/10 text-red-700 border-red-500/30"
                                  }`}
                                >
                                  {ok ? "DELIVERED" : "FAILED"}
                                </Badge>
                                <span className="text-sm font-medium truncate">{log.subject}</span>
                              </div>

                              <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground flex-wrap">
                                <span className="flex items-center gap-1">
                                  <AtSign className="h-3 w-3" />
                                  {log.to}
                                </span>
                                <span className="flex items-center gap-1">
                                  <CalendarDays className="h-3 w-3" />
                                  {new Date(log.timestamp).toLocaleString()}
                                </span>
                                {log.messageId && (
                                  <span className="font-mono opacity-60 text-[10px] hidden sm:block truncate max-w-[200px]">
                                    {log.messageId}
                                  </span>
                                )}
                              </div>

                              {log.error && (
                                <div className="mt-1.5 flex items-start gap-1.5">
                                  <AlertTriangle className="h-3 w-3 text-red-500 mt-0.5 shrink-0" />
                                  <p className="text-xs text-red-600 leading-snug">{log.error}</p>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* ── Save button ── */}
        <div className="flex justify-end">
          <Button type="submit" disabled={updateSettingsMutation.isPending} className="gap-2">
            {updateSettingsMutation.isPending
              ? <Loader2 className="h-4 w-4 animate-spin" />
              : <CheckCircle className="h-4 w-4" />
            }
            Save Settings
          </Button>
        </div>
      </form>
    </div>
  );
}
