import { useState } from "react";
import { useLocation, Link } from "wouter";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import {
  LayoutDashboard, Package, Users, Settings, FileText, Activity, Key,
  ChevronLeft, ChevronRight, MonitorSpeaker, Cpu, Wrench, BookOpen,
  ChevronDown, Database, UserCog, Shield, BarChart, Network, Zap,
  HelpCircle, Mail, Globe, Server, Cloud, ShoppingCart, Monitor,
  ExternalLink, Lock, TrendingUp, Kanban, User, BarChart3,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const NAV_GROUPS = [
  {
    label: "Overview",
    items: [
      { title: "Dashboard", icon: LayoutDashboard, href: "/" },
    ],
  },
  {
    label: "Asset Management",
    items: [
      { title: "Assets",            icon: Package,       href: "/assets" },
      { title: "Components",        icon: Cpu,           href: "/components" },
      { title: "Accessories",       icon: Wrench,        href: "/accessories" },
      { title: "Consumables",       icon: ShoppingCart,  href: "/it-equipment" },
      { title: "Monitor Inventory", icon: Monitor,       href: "/monitor-inventory" },
    ],
  },
  {
    label: "People & Licenses",
    items: [
      { title: "Users",    icon: Users,    href: "/users" },
      { title: "Licenses", icon: FileText, href: "/licenses" },
    ],
  },
  {
    label: "Cloud & Virtual",
    items: [
      { title: "Azure Inventory",    icon: Cloud,          href: "/azure-inventory" },
      { title: "GCP Inventory",      icon: Globe,          href: "/gcp-inventory" },
      { title: "AWS Inventory",      icon: Cloud,          href: "/aws-inventory" },
      { title: "VM Inventory",       icon: Server,         href: "/vm-inventory" },
      { title: "Servers Monitoring", icon: MonitorSpeaker, href: "/servers-monitoring" },
    ],
  },
  {
    label: "Security",
    items: [
      { title: "BitLocker Keys", icon: Key,    href: "/bitlocker-keys" },
      { title: "IAM Accounts",   icon: Shield, href: "/iam-accounts" },
    ],
  },
  {
    label: "Reports & Analytics",
    items: [
      { title: "Activity Log",     icon: Activity,     href: "/activities" },
      { title: "Reports",          icon: BarChart,     href: "/reports" },
      { title: "Monthly Trends",   icon: TrendingUp,   href: "/monthly-trends-report" },
      { title: "Advanced Reports", icon: FileText,     href: "/reports-secondary" },
      { title: "JIRA Dashboard",   icon: ExternalLink, href: "/jira-dashboard" },
      { title: "Jira Kanban",      icon: Kanban,       href: "/jira-kanban" },
    ],
  },
  {
    label: "Tools",
    items: [
      { title: "Approval Monitoring", icon: FileText, href: "/approval-monitoring" },
      { title: "Email Bulk Sender",   icon: Mail,     href: "/email-bulk-sender" },
    ],
  },
];

const ADMIN_ITEMS = [
  { title: "Account Management",  icon: UserCog,  href: "/admin/account-management" },
  { title: "User Management",     icon: Shield,   href: "/user-management" },
  { title: "Database",            icon: Database, href: "/admin/database" },
  { title: "System Setup",        icon: Settings, href: "/admin/system-setup" },
  { title: "JIRA Settings",       icon: Zap,      href: "/admin/jira-settings" },
  { title: "System Logs",         icon: FileText, href: "/admin/system-logs" },
  { title: "Email Notifications", icon: Mail,     href: "/admin/email-notifications" },
  { title: "Page Builder",        icon: FileText, href: "/admin/page-builder", badge: "New" },
  { title: "Data Encryption",     icon: Lock,     href: "/admin/data-encryption" },
];

const HELP_ITEMS = [
  { title: "User Manual",     icon: BookOpen,   href: "/user-manual" },
  { title: "Report an Issue", icon: HelpCircle, href: "/report-issue" },
  { title: "Settings",        icon: Settings,   href: "/settings" },
];

function NavItem({ item, isActive, collapsed }: {
  item: { title: string; icon: any; href: string; badge?: string | null };
  isActive: boolean;
  collapsed: boolean;
}) {
  const Icon = item.icon;
  return (
    <Link href={item.href} className="block">
      <div className={cn(
        "group relative flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all duration-150 cursor-pointer",
        collapsed && "justify-center px-2",
        isActive
          ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300"
          : "text-black hover:bg-gray-100 hover:text-black dark:text-slate-300 dark:hover:bg-white/8 dark:hover:text-white"
      )}>
        {isActive && (
          <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 rounded-r-full bg-emerald-500" />
        )}
        <Icon className={cn(
          "h-4 w-4 flex-shrink-0 transition-colors",
          isActive
            ? "text-emerald-700 dark:text-emerald-400"
            : "text-gray-700 group-hover:text-black dark:text-slate-400 dark:group-hover:text-slate-200"
        )} />
        {!collapsed && (
          <>
            <span className="flex-1 truncate">{item.title}</span>
            {item.badge && (
              <Badge className="ml-auto bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300 border-0 text-[10px] px-1.5 py-0 h-4">
                {item.badge}
              </Badge>
            )}
          </>
        )}
      </div>
    </Link>
  );
}

function NavGroup({ group, location, collapsed, defaultOpen = false }: {
  group: typeof NAV_GROUPS[0];
  location: string;
  collapsed: boolean;
  defaultOpen?: boolean;
}) {
  const isActive = group.items.some(i => location === i.href || location.startsWith(i.href + "/"));
  const [open, setOpen] = useState(defaultOpen || isActive);

  if (collapsed) {
    return (
      <div className="space-y-0.5">
        {group.items.map(item => (
          <NavItem key={item.href} item={item} isActive={location === item.href} collapsed />
        ))}
      </div>
    );
  }

  return (
    <div>
      <button
        onClick={() => setOpen(p => !p)}
        className="flex w-full items-center justify-between px-3 py-1 mb-0.5
                   text-[10px] font-bold uppercase tracking-[0.1em]
                   text-black hover:text-black
                   dark:text-slate-500 dark:hover:text-slate-300
                   transition-colors"
      >
        <span>{group.label}</span>
        <ChevronDown className={cn("h-3 w-3 transition-transform", open ? "" : "-rotate-90")} />
      </button>
      {open && (
        <div className="space-y-0.5 mb-1">
          {group.items.map(item => (
            <NavItem key={item.href} item={item} isActive={location === item.href} collapsed={false} />
          ))}
        </div>
      )}
    </div>
  );
}

interface SidebarProps {
  isCollapsed?: boolean;
  onToggle?: () => void;
  className?: string;
  customPages?: any[];
  customPagesLoading?: boolean;
  customPagesError?: any;
}

function Sidebar({ isCollapsed = false, onToggle, className = "" }: SidebarProps) {
  const [location] = useLocation();
  const [adminOpen,  setAdminOpen]  = useState(false);
  const [helpOpen,   setHelpOpen]   = useState(false);
  const [customOpen, setCustomOpen] = useState(false);

  const { data: user } = useQuery({
    queryKey: ["/api/me"],
    queryFn: async () => {
      const res = await fetch("/api/me", { credentials: "include" });
      if (!res.ok) return null;
      const r = await res.json();
      return r.user || r;
    },
    retry: false, staleTime: 300_000,
  });

  const { data: customPages } = useQuery({
    queryKey: ["/api/page-builder/pages"],
    queryFn: async () => (await apiRequest("GET", "/api/page-builder/pages")).json(),
    retry: false, staleTime: 60_000,
  });

  const isAdmin = user?.isAdmin === true;

  return (
    <div className={cn(
      "flex flex-col h-full overflow-hidden transition-all duration-300",
      /* Light: plain white with border. Dark: deep navy. */
      "bg-white border-r border-gray-200",
      "dark:bg-[#0f1623] dark:border-white/5",
      isCollapsed ? "w-16" : "w-64",
      className
    )}>

      {/* Logo */}
      <div className={cn(
        "flex items-center h-16 flex-shrink-0 px-3 border-b border-gray-200 dark:border-white/5",
        isCollapsed ? "justify-center" : "justify-between gap-2"
      )}>
        {!isCollapsed && (
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="relative flex-shrink-0">
              <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-pulse" />
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center shadow-md">
                <Database className="h-5 w-5 text-white" />
              </div>
            </div>
            <div className="min-w-0">
              <p className="text-sm font-bold text-gray-900 dark:text-white leading-none tracking-tight">SRPH-MIS</p>
              <p className="text-[10px] text-gray-400 dark:text-slate-500 mt-0.5">Asset Management</p>
            </div>
          </div>
        )}
        {isCollapsed && (
          <div className="relative">
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center">
              <Database className="h-5 w-5 text-white" />
            </div>
          </div>
        )}
        <button
          onClick={onToggle}
          className={cn(
            "flex-shrink-0 h-6 w-6 rounded-md flex items-center justify-center transition-colors",
            "text-gray-400 hover:bg-gray-100 hover:text-gray-600",
            "dark:text-slate-500 dark:hover:bg-white/10 dark:hover:text-slate-300"
          )}
        >
          {isCollapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <ChevronLeft className="h-3.5 w-3.5" />}
        </button>
      </div>

      {/* Nav */}
      <div className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
        {NAV_GROUPS.map((g, i) => (
          <NavGroup key={g.label} group={g} location={location} collapsed={isCollapsed} defaultOpen={i === 0} />
        ))}

        {/* Custom pages */}
        {customPages && customPages.length > 0 && !isCollapsed && (
          <div>
            <button
              onClick={() => setCustomOpen(p => !p)}
              className="flex w-full items-center justify-between px-3 py-1 mb-0.5
                         text-[10px] font-bold uppercase tracking-[0.1em]
                         text-black hover:text-black dark:text-slate-500 dark:hover:text-slate-300 transition-colors"
            >
              <span>Custom Pages</span>
              <ChevronDown className={cn("h-3 w-3 transition-transform", customOpen ? "" : "-rotate-90")} />
            </button>
            {customOpen && customPages.map((p: any) => (
              <NavItem key={p.pageSlug || p.page_slug}
                item={{ title: p.pageName || p.page_name, icon: FileText, href: `/custom/${p.pageSlug || p.page_slug}` }}
                isActive={location === `/custom/${p.pageSlug || p.page_slug}`}
                collapsed={false} />
            ))}
          </div>
        )}

        {/* Admin */}
        {isAdmin && (
          <div>
            {!isCollapsed && (
              <button
                onClick={() => setAdminOpen(p => !p)}
                className="flex w-full items-center justify-between px-3 py-1 mb-0.5
                           text-[10px] font-bold uppercase tracking-[0.1em]
                           text-black hover:text-black dark:text-slate-500 dark:hover:text-slate-300 transition-colors"
              >
                <span>Administration</span>
                <ChevronDown className={cn("h-3 w-3 transition-transform", adminOpen ? "" : "-rotate-90")} />
              </button>
            )}
            {(adminOpen || isCollapsed) && ADMIN_ITEMS.map(item => (
              <NavItem key={item.href} item={item} isActive={location === item.href} collapsed={isCollapsed} />
            ))}
          </div>
        )}

        {/* Help */}
        <div>
          {!isCollapsed && (
            <button
              onClick={() => setHelpOpen(p => !p)}
              className="flex w-full items-center justify-between px-3 py-1 mb-0.5
                         text-[10px] font-bold uppercase tracking-[0.1em]
                         text-black hover:text-black dark:text-slate-500 dark:hover:text-slate-300 transition-colors"
            >
              <span>Help & Support</span>
              <ChevronDown className={cn("h-3 w-3 transition-transform", helpOpen ? "" : "-rotate-90")} />
            </button>
          )}
          {(helpOpen || isCollapsed) && HELP_ITEMS.map(item => (
            <NavItem key={item.href} item={item} isActive={location === item.href} collapsed={isCollapsed} />
          ))}
        </div>
      </div>

      {/* User footer */}
      <div className={cn(
        "flex-shrink-0 border-t border-gray-200 dark:border-white/5 p-3",
        isCollapsed ? "flex justify-center" : "flex items-center gap-3"
      )}>
        <div className="flex-shrink-0 h-8 w-8 rounded-lg bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center">
          <User className="h-4 w-4 text-white" />
        </div>
        {!isCollapsed && (
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-black dark:text-slate-100 truncate">
              {user?.firstName || user?.username || "User"}
            </p>
            <p className="text-xs text-gray-600 dark:text-slate-400 truncate">
              {isAdmin ? "Administrator" : "Staff"}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default Sidebar;
export { Sidebar };

interface SidebarItemProps {
  item: { title: string; icon: any; href: string; badge: string | null };
  isActive: boolean;
  isCollapsed: boolean;
}
function SidebarItem({ item, isActive, isCollapsed }: SidebarItemProps) {
  return <NavItem item={item} isActive={isActive} collapsed={isCollapsed} />;
}