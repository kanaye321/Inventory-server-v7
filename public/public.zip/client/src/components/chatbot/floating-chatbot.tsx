import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MessageCircle, X, Send, Bot, User, Server, Shield, Monitor } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useLocation } from 'wouter';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

// Simple Markdown Formatter
const formatText = (text: string) => {
  return text.split('\n').map((line, i) => {
    // Handling bold markdown
    const parts = line.split(/(\*\*.*?\*\*)/g);
    return (
      <span key={i} className="block min-h-[0.5rem]">
        {parts.map((part, index) => {
          if (part.startsWith('**') && part.endsWith('**')) {
            return <strong key={index}>{part.slice(2, -2)}</strong>;
          }
          return <span key={index}>{part}</span>;
        })}
      </span>
    );
  });
};

export function FloatingChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [, setLocation] = useLocation();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: '👋 **Welcome to SRPH-MIS User Assistant!**\n\nI am now powered by a local, on-premise AI model to answer any questions you have about the system.\n\nHow can I help you today?',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleQuickAction = (route: string, label: string) => {
    setLocation(route);
    setIsOpen(false);
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    // Send last 6 messages (3 exchanges) — matches backend filter cap
    const history = messages
      .slice(-6)
      .filter(m => m.id !== '1')
      .map(m => ({ role: m.role, content: m.content }));

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: input, history })
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.reply || `Server error: ${response.status}`);
      }

      const data = await response.json();
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.reply || "No response received.",
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'assistant',
        content: '⚠️ **Communication Error**\n\nI could not reach the local AI engine. Please ensure Ollama is running and the backend is accessible.',
        timestamp: new Date()
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <>
      {!isOpen && (
        <Button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-20 right-6 h-16 w-16 rounded-full shadow-2xl z-50 bg-gradient-to-tr from-primary to-blue-500 hover:scale-105 transition-transform duration-200 border-2 border-white/20"
          size="icon"
        >
          <Bot className="h-8 w-8 text-white" />
        </Button>
      )}

      {isOpen && (
        <>
          {/* Full-screen backdrop blur for focus (optional, let's keep it subtle) */}
          <div className="fixed inset-0 bg-background/20 backdrop-blur-[2px] z-40 transition-opacity animate-in fade-in" onClick={() => setIsOpen(false)}></div>
          
          {/* The Floating Drawer Panel */}
          <div className="fixed top-4 bottom-4 right-4 w-[450px] max-w-[calc(100vw-2rem)] z-50 flex flex-col rounded-[2.5rem] bg-white/70 dark:bg-slate-900/80 backdrop-blur-3xl shadow-[0_0_60px_-15px_rgba(0,0,0,0.3)] ring-1 ring-black/5 dark:ring-white/10 overflow-hidden animate-in slide-in-from-right-8 duration-500 ease-out">
            
            {/* Elegant Header */}
            <div className="px-6 py-5 flex items-center justify-between border-b border-black/5 dark:border-white/5 bg-white/50 dark:bg-black/20 shrink-0">
              <div className="flex items-center gap-4">
                <div className="relative flex items-center justify-center h-12 w-12 rounded-full bg-gradient-to-tr from-indigo-500 to-blue-500 shadow-lg shadow-blue-500/30">
                  <Bot className="h-6 w-6 text-white" />
                  <div className="absolute -bottom-1 -right-1 h-3.5 w-3.5 rounded-full bg-green-500 border-2 border-white dark:border-slate-900"></div>
                </div>
                <div className="flex flex-col">
                  <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 tracking-tight">AI Assistant</h2>
                  <p className="text-sm font-medium text-blue-600 dark:text-blue-400">Powered by Ollama</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="h-10 w-10 flex items-center justify-center relative z-50 rounded-full bg-slate-100/50 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/20 text-slate-600 dark:text-slate-300 transition-all cursor-pointer"
                aria-label="Close Chatbot"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-hidden relative flex flex-col bg-slate-50/50 dark:bg-black/10">
              <ScrollArea className="flex-1 p-6 scroll-smooth" ref={scrollRef}>
                <div className="space-y-6 pb-6">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={cn(
                        'flex flex-col gap-1 w-full animate-in fade-in slide-in-from-bottom-3 duration-500',
                        message.role === 'user' ? 'items-end' : 'items-start'
                      )}
                    >
                      <div className="flex items-end gap-2 max-w-[85%]">
                        {message.role === 'assistant' && (
                          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-gradient-to-tr from-indigo-500 to-blue-500 flex items-center justify-center shadow-sm mb-1">
                            <Bot className="h-4 w-4 text-white" />
                          </div>
                        )}
                        <div
                          className={cn(
                            'px-5 py-4 text-[15px] leading-relaxed shadow-sm ring-1',
                            message.role === 'user'
                              ? 'bg-blue-600 text-white rounded-3xl rounded-br-sm ring-blue-700/50'
                              : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-3xl rounded-bl-sm ring-black/5 dark:ring-white/10 prose prose-sm dark:prose-invert max-w-none prose-p:leading-relaxed prose-pre:bg-slate-100 dark:prose-pre:bg-slate-900 prose-pre:border-none'
                          )}
                        >
                          {formatText(message.content)}
                        </div>
                      </div>
                      <span className="text-[11px] font-medium text-slate-400 dark:text-slate-500 px-10">
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  ))}
                  
                  {isTyping && (
                    <div className="flex flex-col gap-1 items-start w-full animate-in fade-in duration-300">
                      <div className="flex items-end gap-2 max-w-[85%]">
                        <div className="flex-shrink-0 h-8 w-8 rounded-full bg-gradient-to-tr from-indigo-500 to-blue-500 flex items-center justify-center shadow-sm mb-1">
                          <Bot className="h-4 w-4 text-white" />
                        </div>
                        <div className="bg-white dark:bg-slate-800 ring-1 ring-black/5 dark:ring-white/10 rounded-3xl rounded-bl-sm px-6 py-4 shadow-sm">
                          <div className="flex gap-1.5 items-center justify-center h-2">
                            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </div>

            {/* Input Area */}
            <div className="p-5 bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl border-t border-black/5 dark:border-white/5 shrink-0 relative">
              <div className="relative flex items-center bg-slate-100 dark:bg-slate-800/50 rounded-[2rem] ring-1 ring-black/5 dark:ring-white/10 focus-within:ring-blue-500/50 focus-within:bg-white dark:focus-within:bg-slate-800 transition-all p-1.5 shadow-inner">
                <div className="pl-4 pr-2 flex items-center justify-center text-slate-400">
                  <Bot className="h-5 w-5" />
                </div>
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  placeholder="Ask me anything about your data..."
                  autoComplete="off"
                  className="w-full border-0 bg-transparent focus-visible:ring-0 shadow-none text-[15px] px-2 py-3 placeholder:text-slate-400 dark:placeholder:text-slate-500"
                  disabled={isTyping}
                />
                <Button
                  onClick={handleSend}
                  size="icon"
                  className={cn(
                    "h-10 w-10 rounded-full transition-all shrink-0 ml-2",
                    !input.trim() || isTyping 
                      ? 'bg-slate-200 dark:bg-slate-700 text-slate-400 dark:text-slate-500 cursor-not-allowed' 
                      : 'bg-blue-600 hover:bg-blue-700 text-white shadow-md hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0'
                  )}
                  disabled={!input.trim() || isTyping}
                >
                  <Send className="h-4 w-4 ml-0.5" />
                </Button>
              </div>
              <div className="text-center mt-3">
                <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                  Secure On-Premise AI Connection
                </p>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
}
