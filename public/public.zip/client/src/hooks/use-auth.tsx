import React, {
  createContext, useContext, useState, useEffect,
  ReactNode, useCallback, useRef
} from 'react';
import { useQuery } from '@tanstack/react-query';
import { useToast } from './use-toast';
import { Clock, LogOut, ShieldCheck } from 'lucide-react';

/* ─────────────────────────────────────────────
   Types
───────────────────────────────────────────── */
interface User {
  id: string;
  username: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  department?: string;
  isAdmin?: boolean;
  roleId?: number | null;
  permissions?: {
    [key: string]: {
      view: boolean;
      edit: boolean;
      add: boolean;
      delete?: boolean;
    };
  };
}

interface AuthContextType {
  user: User | null;
  login: (user: User) => void;
  logout: () => void;
  loading: boolean;
}

/* ─────────────────────────────────────────────
   Context
───────────────────────────────────────────── */
const AuthContext = createContext<AuthContextType | undefined>(undefined);

/* ─────────────────────────────────────────────
   Constants
───────────────────────────────────────────── */
const WARNING_SECONDS = 60;       // Show warning 60 s before expiry
const ACTIVITY_DEBOUNCE_MS = 1000; // Only reset timer if 1 s has passed since last activity

/* ─────────────────────────────────────────────
   Helper: convert DB value to milliseconds
   DB stores the value the admin typed in the
   System Setup page (minutes). If a DB had the
   old default (1800 seconds), cap it sanely.
───────────────────────────────────────────── */
function toMs(rawMinutes: number): number {
  // Guard: if someone stored 0 or negative, fall back to 30 min
  const mins = rawMinutes > 0 ? rawMinutes : 30;
  // If the DB stored the old express-session default (1800 sec = 30 min),
  // treat values >= 480 as seconds (8 hours in minutes is unreasonably long)
  // and convert them to minutes. This is a one-time migration guard.
  const normalised = mins >= 480 ? Math.round(mins / 60) : mins;
  return normalised * 60 * 1000;
}

/* ─────────────────────────────────────────────
   Provider
───────────────────────────────────────────── */
export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();

  /* ── Fetch authenticated user ── */
  const { data: user, isLoading, error } = useQuery<User | null>({
    queryKey: ['/api/user'],
    queryFn: async () => {
      const res = await fetch('/api/user', {
        credentials: 'include',
        headers: { 'Cache-Control': 'no-cache', Pragma: 'no-cache' },
      });
      if (!res.ok) {
        if (res.status === 401) return null;
        throw new Error(`Failed to fetch user: ${res.status}`);
      }
      const data = await res.json();
      if (!data?.id || !data?.username) return null;
      return data;
    },
    retry: 2,
    retryDelay: (i) => Math.min(500 * 2 ** i, 2000),
    staleTime: 0,
    gcTime: 0,
  });

  /* ── Fetch session-timeout from settings ── */
  const { data: settingsData } = useQuery({
    queryKey: ['/api/settings'],
    queryFn: async () => {
      const res = await fetch('/api/settings', { credentials: 'include' });
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!user,
    staleTime: 5 * 60 * 1000,
    retry: 1,
  });

  /* ── Auth loading flag ── */
  const [authLoading, setAuthLoading] = useState(true);
  useEffect(() => {
    if (!isLoading) setAuthLoading(false);
  }, [isLoading, error]);

  /* ─────────────────────────────────────────
     Session-timeout state (all via refs so
     timers always read fresh values)
  ───────────────────────────────────────── */
  // Timeout value in milliseconds (default 30 min)
  const timeoutMsRef = useRef<number>(30 * 60 * 1000);
  const lastActivityRef = useRef<number>(Date.now());
  const mainTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const warnTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Warning dialog state
  const [showWarning, setShowWarning] = useState(false);
  const [countdown, setCountdown] = useState(WARNING_SECONDS);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Keep a stable ref to toast so timers never capture a stale closure
  const toastRef = useRef(toast);
  useEffect(() => { toastRef.current = toast; }, [toast]);

  /* ── Sync settings → timeoutMsRef ── */
  useEffect(() => {
    if (settingsData?.sessionTimeout) {
      timeoutMsRef.current = toMs(Number(settingsData.sessionTimeout));
      console.log('Session timeout set to', timeoutMsRef.current / 1000, 's');
    }
  }, [settingsData]);

  /* ── Clear all timers helper ── */
  const clearAllTimers = useCallback(() => {
    if (mainTimerRef.current) clearTimeout(mainTimerRef.current);
    if (warnTimerRef.current) clearTimeout(warnTimerRef.current);
    if (countdownRef.current) clearInterval(countdownRef.current);
    mainTimerRef.current = null;
    warnTimerRef.current = null;
    countdownRef.current = null;
  }, []);

  /* ── Auto-logout ── */
  const handleAutoLogout = useCallback(async () => {
    clearAllTimers();
    setShowWarning(false);

    try {
      await fetch('/api/logout', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: 'inactivity' }),
      });
    } catch {}

    localStorage.removeItem('user');

    toastRef.current({
      title: 'Session Expired',
      description: 'You were automatically logged out due to inactivity.',
      variant: 'destructive',
      duration: 5000,
    });

    setTimeout(() => { window.location.href = '/auth'; }, 1500);
  }, [clearAllTimers]);

  /* ── Start countdown in warning dialog ── */
  const startCountdown = useCallback(() => {
    setCountdown(WARNING_SECONDS);
    setShowWarning(true);

    if (countdownRef.current) clearInterval(countdownRef.current);
    countdownRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          if (countdownRef.current) clearInterval(countdownRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }, []);

  /* ── Schedule the warning + logout timers ── */
  const scheduleTimers = useCallback(() => {
    clearAllTimers();
    setShowWarning(false);

    const totalMs = timeoutMsRef.current;
    // Show warning 60 s before logout (min 10 s warning if timeout is very short)
    const warnDelayMs = Math.max(totalMs - WARNING_SECONDS * 1000, totalMs * 0.8);

    warnTimerRef.current = setTimeout(() => {
      startCountdown();
    }, warnDelayMs);

    mainTimerRef.current = setTimeout(() => {
      handleAutoLogout();
    }, totalMs);
  }, [clearAllTimers, startCountdown, handleAutoLogout]);

  /* ── "Stay Logged In" handler ── */
  const handleStayLoggedIn = useCallback(() => {
    if (countdownRef.current) clearInterval(countdownRef.current);
    setShowWarning(false);
    setCountdown(WARNING_SECONDS);
    lastActivityRef.current = Date.now();
    scheduleTimers();
  }, [scheduleTimers]);

  /* ── Activity listener ── */
  useEffect(() => {
    if (!user) {
      clearAllTimers();
      setShowWarning(false);
      return;
    }

    const handleActivity = () => {
      const now = Date.now();
      if (now - lastActivityRef.current < ACTIVITY_DEBOUNCE_MS) return;
      if (showWarning) return; // Don't reset if warning is showing
      lastActivityRef.current = now;
      scheduleTimers();
    };

    // Kick off the initial timer
    scheduleTimers();

    const events = ['mousedown', 'keydown', 'scroll', 'touchstart', 'click'];
    events.forEach((e) => window.addEventListener(e, handleActivity, { passive: true }));

    return () => {
      clearAllTimers();
      events.forEach((e) => window.removeEventListener(e, handleActivity));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]); // Only re-run when user changes — scheduleTimers uses refs

  /* ─────────────────────────────────────────
     Auth actions
  ───────────────────────────────────────── */
  const login = (userData: User) => {
    localStorage.setItem('user', JSON.stringify(userData));
    window.location.href = '/';
  };

  const logout = async () => {
    clearAllTimers();
    try {
      await fetch('/api/logout', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
      });
    } catch {}
    localStorage.removeItem('user');
    window.location.href = '/auth';
  };

  /* ─────────────────────────────────────────
     Render
  ───────────────────────────────────────── */
  return (
    <AuthContext.Provider value={{ user: user ?? null, login, logout, loading: authLoading }}>
      {children}

      {/* ── Session-expiry warning overlay ── */}
      {showWarning && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center">
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />

          {/* Card */}
          <div className="relative w-full max-w-sm mx-4 bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-amber-200 dark:border-amber-700/50 overflow-hidden">
            {/* Top accent bar */}
            <div className="h-1.5 w-full bg-gradient-to-r from-amber-400 to-orange-500" />

            <div className="p-6 space-y-4">
              {/* Header */}
              <div className="flex items-start gap-3">
                <div className="p-2.5 bg-amber-100 dark:bg-amber-900/30 rounded-xl shrink-0">
                  <Clock className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground text-base">Session Expiring</h3>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    You have been inactive. Your session will expire in:
                  </p>
                </div>
              </div>

              {/* Countdown */}
              <div className="text-center py-2">
                <span className="text-5xl font-bold tabular-nums text-amber-600 dark:text-amber-400">
                  {countdown}
                </span>
                <span className="text-lg text-muted-foreground ml-1">s</span>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
                <div
                  className="h-2 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 transition-[width] duration-1000 ease-linear"
                  style={{ width: `${(countdown / WARNING_SECONDS) * 100}%` }}
                />
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-1">
                <button
                  onClick={() => handleAutoLogout()}
                  className="flex-1 flex items-center justify-center gap-2 h-10 rounded-xl border border-border text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
                >
                  <LogOut className="h-4 w-4" />
                  Logout Now
                </button>
                <button
                  onClick={handleStayLoggedIn}
                  className="flex-1 flex items-center justify-center gap-2 h-10 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold shadow-lg shadow-emerald-500/25 transition-colors"
                >
                  <ShieldCheck className="h-4 w-4" />
                  Stay Logged In
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </AuthContext.Provider>
  );
}

/* ─────────────────────────────────────────────
   Hook
───────────────────────────────────────────── */
export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
}