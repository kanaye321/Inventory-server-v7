-- =============================================
-- Manual PostgreSQL Database Backup
-- =============================================
-- Created: 2026-04-17T04:24:33.972Z
-- Created By: admin
-- Database: srph_mis
-- =============================================


-- =============================================
-- Table: users
-- Total Records: 1
-- =============================================

TRUNCATE TABLE users CASCADE;

INSERT INTO users (id, username, password, first_name, last_name, email, department, is_admin, role_id, mfa_enabled, mfa_secret, force_password_change, permissions, created_at, updated_at, phone, location, bio, avatar) VALUES (1, 'admin', '7b10ce0fca3c77cd15011694de2924406335ad36fb821333b78cb9196383c966109ef837d5e1664dec30f941d11ea909f8d9bcab9ff3c0dce3d0def9e3d4db06.a845c630f9340f42a65bbdef4317e008', 'Admin', 'User', 'admin@srph.com', 'IT', TRUE, NULL, TRUE, 'EVFCUQD5GMXTY4REJMUDM6L2OQ3WE5KUKI2XW6ZBKIWG2YKBOYXA', FALSE, '{"admin":{"add":false,"edit":false,"view":false},"users":{"add":false,"edit":false,"view":false},"assets":{"add":false,"edit":false,"view":true},"reports":{"add":false,"edit":false,"view":true},"licenses":{"add":false,"edit":false,"view":true},"components":{"add":false,"edit":false,"view":true},"accessories":{"add":false,"edit":false,"view":true},"consumables":{"add":false,"edit":false,"view":true},"vmMonitoring":{"add":false,"edit":false,"view":true},"bitlockerKeys":{"add":false,"edit":false,"view":false},"networkDiscovery":{"add":false,"edit":false,"view":true}}', '2026-04-06 12:21:30.471099', '2026-04-06 12:21:30.471099', NULL, NULL, NULL, NULL); 

-- Completed users: 1 rows exported


-- =============================================
-- Table: assets
-- Total Records: 4
-- =============================================

TRUNCATE TABLE assets CASCADE;

INSERT INTO assets (id, asset_tag, name, description, category, status, condition, purchase_date, purchase_cost, location, serial_number, model, manufacturer, notes, knox_id, ip_address, mac_address, os_type, assigned_to, checkout_date, expected_checkin_date, finance_updated, department, created_at, updated_at, deployed_at) VALUES (10, 'test2', 'test2', '', 'Laptop', 'available', 'Good', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, FALSE, '', '2026-04-16 19:32:31.390011', '2026-04-16 19:32:31.390011', NULL); 
INSERT INTO assets (id, asset_tag, name, description, category, status, condition, purchase_date, purchase_cost, location, serial_number, model, manufacturer, notes, knox_id, ip_address, mac_address, os_type, assigned_to, checkout_date, expected_checkin_date, finance_updated, department, created_at, updated_at, deployed_at) VALUES (7, 'sdfsd', 'dfhdgh', '', 'Laptop', 'Deployed', 'Bad', '', '', '', '', '', '', '', 'bwakanangshets', '', '', '', NULL, NULL, NULL, FALSE, '', '2026-04-14 16:25:44.026167', '2026-04-14 16:25:44.026167', '2026-04-14T16:25:44.026Z'); 
INSERT INTO assets (id, asset_tag, name, description, category, status, condition, purchase_date, purchase_cost, location, serial_number, model, manufacturer, notes, knox_id, ip_address, mac_address, os_type, assigned_to, checkout_date, expected_checkin_date, finance_updated, department, created_at, updated_at, deployed_at) VALUES (8, 'test', 'test', '', 'Laptop', 'Deployed', 'Good', '', '', '', '', '', '', '', 'test1', '', '', '', 1, '2026-04-16', NULL, FALSE, '', '2026-04-16 19:02:44.995571', '2026-04-16 19:02:44.995571', '2026-04-16T19:02:44.995Z'); 
INSERT INTO assets (id, asset_tag, name, description, category, status, condition, purchase_date, purchase_cost, location, serial_number, model, manufacturer, notes, knox_id, ip_address, mac_address, os_type, assigned_to, checkout_date, expected_checkin_date, finance_updated, department, created_at, updated_at, deployed_at) VALUES (9, 'test1', 'test1', '', 'Laptop', 'Deployed', 'Good', '', '', '', '', '', '', '', 'test1', '', '', '', 1, '2026-04-16', NULL, FALSE, '', '2026-04-16 19:20:33.455745', '2026-04-16 19:20:33.455745', '2026-04-16T19:20:33.455Z'); 

-- Completed assets: 4 rows exported


-- =============================================
-- Table: activities
-- Total Records: 66
-- =============================================

TRUNCATE TABLE activities CASCADE;

INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (1, 'create', 'asset', 1, 1, '2026-04-14T07:43:20.485Z', 'Asset test (test) created', '2026-04-14 15:43:20.486723'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (2, 'checkout', 'asset', 1, 1, '2026-04-14T07:43:20.511Z', 'Asset automatically checked out to KnoxID: jimenez.n', '2026-04-14 15:43:20.512071'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (3, 'checkout', 'asset', 1, 1, '2026-04-14T07:43:20.512Z', 'Asset automatically checked out to KnoxID: jimenez.n', '2026-04-14 15:43:20.513132'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (4, 'update', 'asset', 1, 1, '2026-04-14T07:44:06.813Z', 'Asset test (test) updated', '2026-04-14 15:44:06.813843'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (5, 'delete', 'asset', 1, 1, '2026-04-14T08:01:49.700Z', 'Asset test (test) deleted', '2026-04-14 16:01:49.70247'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (6, 'create', 'asset', 2, 1, '2026-04-14T08:01:56.771Z', 'Asset test (test) created', '2026-04-14 16:01:56.773233'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (7, 'update', 'asset', 2, 1, '2026-04-14T08:02:07.284Z', 'Asset test (test) updated', '2026-04-14 16:02:07.285676'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (8, 'checkout', 'asset', 2, 1, '2026-04-14T08:02:07.291Z', 'Asset automatically checked out to KnoxID: jimenez.n', '2026-04-14 16:02:07.293066'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (9, 'checkout', 'asset', 2, 1, '2026-04-14T08:02:07.293Z', 'Asset automatically checked out to KnoxID: jimenez.n', '2026-04-14 16:02:07.294508'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (10, 'update', 'asset', 2, 1, '2026-04-14T08:02:24.161Z', 'Asset test (test) updated', '2026-04-14 16:02:24.162382'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (11, 'delete', 'asset', 2, 1, '2026-04-14T08:05:07.182Z', 'Asset test (test) deleted', '2026-04-14 16:05:07.183752'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (12, 'create', 'asset', 3, 1, '2026-04-14T08:05:19.921Z', 'Asset test (test1) created', '2026-04-14 16:05:19.92223'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (13, 'update', 'asset', 3, 1, '2026-04-14T08:05:30.131Z', 'Asset test (test1) updated', '2026-04-14 16:05:30.132333'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (14, 'checkout', 'asset', 3, 1, '2026-04-14T08:05:30.138Z', 'Asset automatically checked out to KnoxID: jimenez', '2026-04-14 16:05:30.139331'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (15, 'checkout', 'asset', 3, 1, '2026-04-14T08:05:30.139Z', 'Asset automatically checked out to KnoxID: jimenez', '2026-04-14 16:05:30.14049'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (16, 'update', 'asset', 3, 1, '2026-04-14T08:05:41.051Z', 'Asset test (test1) updated', '2026-04-14 16:05:41.05296'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (17, 'delete', 'asset', 3, 1, '2026-04-14T08:11:00.285Z', 'Asset test (test1) deleted', '2026-04-14 16:11:00.287314'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (18, 'create', 'asset', 4, 1, '2026-04-14T08:11:06.608Z', 'Asset test (test) created', '2026-04-14 16:11:06.609938'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (19, 'update', 'asset', 4, 1, '2026-04-14T08:11:22.719Z', 'Asset test (test) updated', '2026-04-14 16:11:22.720317'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (20, 'checkout', 'asset', 4, 1, '2026-04-14T08:11:22.728Z', 'Asset automatically checked out to KnoxID: kelkel', '2026-04-14 16:11:22.729274'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (21, 'checkout', 'asset', 4, 1, '2026-04-14T08:11:22.729Z', 'Asset automatically checked out to KnoxID: kelkel', '2026-04-14 16:11:22.730376'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (22, 'update', 'asset', 4, 1, '2026-04-14T08:11:30.578Z', 'Asset test (test) updated', '2026-04-14 16:11:30.57915'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (23, 'delete', 'asset', 4, 1, '2026-04-14T08:20:22.789Z', 'Asset test (test) deleted', '2026-04-14 16:20:22.789932'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (24, 'create', 'asset', 5, 1, '2026-04-14T08:20:28.719Z', 'Asset teste (testest) created', '2026-04-14 16:20:28.720223'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (25, 'update', 'asset', 5, 1, '2026-04-14T08:20:41.704Z', 'Asset teste (testest) updated', '2026-04-14 16:20:41.705164'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (26, 'checkout', 'asset', 5, 1, '2026-04-14T08:20:41.711Z', 'Asset automatically checked out to KnoxID: tetemoto', '2026-04-14 16:20:41.712426'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (27, 'checkout', 'asset', 5, 1, '2026-04-14T08:20:41.712Z', 'Asset automatically checked out to KnoxID: tetemoto', '2026-04-14 16:20:41.713457'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (28, 'checkin', 'asset', 5, 1, '2026-04-14T08:20:52.977Z', 'Asset teste (testest) checked in', '2026-04-14 16:20:52.978585'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (29, 'update', 'asset', 5, 1, '2026-04-14T08:20:52.991Z', 'Asset teste (testest) updated', '2026-04-14 16:20:52.992616'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (30, 'update', 'asset', 5, 1, '2026-04-14T08:21:10.637Z', 'Asset teste (testest) updated', '2026-04-14 16:21:10.638807'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (31, 'update', 'asset', 5, 1, '2026-04-14T08:21:23.357Z', 'Asset teste (testest) updated', '2026-04-14 16:21:23.357819'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (32, 'delete', 'asset', 5, 1, '2026-04-14T08:23:42.992Z', 'Asset teste (testest) deleted', '2026-04-14 16:23:42.993587'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (33, 'create', 'asset', 6, 1, '2026-04-14T08:23:54.832Z', 'Asset tete (tetet) created', '2026-04-14 16:23:54.833575'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (34, 'update', 'asset', 6, 1, '2026-04-14T08:24:07.419Z', 'Asset tete (tetet) updated', '2026-04-14 16:24:07.420727'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (35, 'checkin', 'asset', 6, NULL, '2026-04-14T08:24:24.235Z', 'Asset tete (tetet) checked in', '2026-04-14 16:24:24.236644'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (36, 'update', 'asset', 6, 1, '2026-04-14T08:24:24.255Z', 'Asset tete (tetet) updated', '2026-04-14 16:24:24.255921'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (37, 'update', 'asset', 6, 1, '2026-04-14T08:24:35.968Z', 'Asset tete (tetet) updated', '2026-04-14 16:24:35.969577'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (38, 'update', 'asset', 6, 1, '2026-04-14T08:25:07.618Z', 'Asset tete (tetet) updated', '2026-04-14 16:25:07.620413'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (39, 'update', 'asset', 6, 1, '2026-04-14T08:25:23.858Z', 'Asset tete (tetet) updated', '2026-04-14 16:25:23.859328'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (40, 'delete', 'asset', 6, 1, '2026-04-14T08:25:36.788Z', 'Asset tete (tetet) deleted', '2026-04-14 16:25:36.789345'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (41, 'create', 'asset', 7, 1, '2026-04-14T08:25:44.042Z', 'Asset dfhdgh (sdfsd) created', '2026-04-14 16:25:44.043786'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (42, 'update', 'asset', 7, 1, '2026-04-14T08:25:52.732Z', 'Asset dfhdgh (sdfsd) updated', '2026-04-14 16:25:52.73418'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (43, 'checkout', 'asset', 7, 1, '2026-04-14T08:25:52.741Z', 'Asset automatically checked out to KnoxID: gdfgdfgd', '2026-04-14 16:25:52.742141'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (44, 'checkout', 'asset', 7, 1, '2026-04-14T08:25:52.742Z', 'Asset automatically checked out to KnoxID: gdfgdfgd', '2026-04-14 16:25:52.743291'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (45, 'checkin', 'asset', 7, 1, '2026-04-14T08:26:03.705Z', 'Asset dfhdgh (sdfsd) checked in', '2026-04-14 16:26:03.706513'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (46, 'update', 'asset', 7, 1, '2026-04-14T08:26:03.717Z', 'Asset dfhdgh (sdfsd) updated', '2026-04-14 16:26:03.719078'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (47, 'update', 'asset', 7, 1, '2026-04-14T08:26:18.695Z', 'Asset dfhdgh (sdfsd) updated', '2026-04-14 16:26:18.697142'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (48, 'update', 'asset', 7, 1, '2026-04-14T08:26:28.584Z', 'Asset dfhdgh (sdfsd) updated', '2026-04-14 16:26:28.585659'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (49, 'update', 'asset', 7, 1, '2026-04-14T08:28:57.236Z', 'Asset dfhdgh (sdfsd) updated', '2026-04-14 16:28:57.237307'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (50, 'checkin', 'asset', 7, NULL, '2026-04-14T08:29:06.728Z', 'Asset dfhdgh (sdfsd) checked in', '2026-04-14 16:29:06.729336'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (51, 'update', 'asset', 7, 1, '2026-04-14T08:29:06.748Z', 'Asset dfhdgh (sdfsd) updated', '2026-04-14 16:29:06.749416'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (52, 'update', 'asset', 7, 1, '2026-04-14T08:29:21.586Z', 'Asset dfhdgh (sdfsd) updated', '2026-04-14 16:29:21.586992'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (53, 'checkin', 'asset', 7, NULL, '2026-04-14T08:37:40.388Z', 'Asset dfhdgh (sdfsd) checked in', '2026-04-14 16:37:40.38984'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (54, 'update', 'asset', 7, 1, '2026-04-14T08:37:40.414Z', 'Asset dfhdgh (sdfsd) updated', '2026-04-14 16:37:40.414851'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (55, 'update', 'asset', 7, 1, '2026-04-14T08:37:54.624Z', 'Asset dfhdgh (sdfsd) updated', '2026-04-14 16:37:54.625422'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (56, 'checkin', 'asset', 7, NULL, '2026-04-14T08:47:34.935Z', 'Asset dfhdgh (sdfsd) checked in', '2026-04-14 16:47:34.935939'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (57, 'update', 'asset', 7, 1, '2026-04-14T08:47:34.955Z', 'Asset dfhdgh (sdfsd) updated', '2026-04-14 16:47:34.956285'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (58, 'update', 'asset', 7, 1, '2026-04-14T08:47:43.582Z', 'Asset dfhdgh (sdfsd) updated', '2026-04-14 16:47:43.583715'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (59, 'update', 'asset', 7, 1, '2026-04-14T11:51:25.439Z', 'Asset dfhdgh (sdfsd) updated', '2026-04-14 19:51:25.442219'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (60, 'create', 'asset', 8, 1, '2026-04-16T11:02:45.006Z', 'Asset test (test) created', '2026-04-16 19:02:45.008027'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (61, 'checkout', 'asset', 8, 1, '2026-04-16T11:02:45.043Z', 'Asset automatically checked out to KnoxID: test1', '2026-04-16 19:02:45.044971'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (62, 'checkout', 'asset', 8, 1, '2026-04-16T11:02:45.045Z', 'Asset automatically checked out to KnoxID: test1', '2026-04-16 19:02:45.047112'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (63, 'create', 'asset', 9, 1, '2026-04-16T11:20:33.458Z', 'Asset test1 (test1) created', '2026-04-16 19:20:33.461194'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (64, 'checkout', 'asset', 9, 1, '2026-04-16T11:20:33.475Z', 'Asset automatically checked out to KnoxID: test1', '2026-04-16 19:20:33.478669'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (65, 'checkout', 'asset', 9, 1, '2026-04-16T11:20:33.477Z', 'Asset automatically checked out to KnoxID: test1', '2026-04-16 19:20:33.48086'); 
INSERT INTO activities (id, action, item_type, item_id, user_id, timestamp, notes, created_at) VALUES (66, 'create', 'asset', 10, 1, '2026-04-16T11:32:31.415Z', 'Asset test2 (test2) created', '2026-04-16 19:32:31.4163'); 

-- Completed activities: 66 rows exported


-- =============================================
-- Table: azure_inventory
-- Total Records: 2
-- =============================================

TRUNCATE TABLE azure_inventory CASCADE;

INSERT INTO azure_inventory (id, name, type, resource_group, location, subscriptions, status, remarks, created_at, updated_at) VALUES (1, 'example-vm', 'Virtual Machine', 'production-rg', 'East US', 'prod-subscription', 'active', 'Production server - Example: test@email.com, 10.0.0.1', '2026-04-14 06:02:06.751', '2026-04-14 06:02:06.751'); 
INSERT INTO azure_inventory (id, name, type, resource_group, location, subscriptions, status, remarks, created_at, updated_at) VALUES (2, 'example-storage', 'Storage Account', 'production-rg', 'West US', 'prod-subscription', 'active', 'Storage for backups: data.backup@company.com', '2026-04-14 06:02:06.762', '2026-04-14 06:02:06.762'); 

-- Completed azure_inventory: 2 rows exported


-- =============================================
-- Table: gcp_inventory
-- Total Records: 2
-- =============================================

TRUNCATE TABLE gcp_inventory CASCADE;

INSERT INTO gcp_inventory (id, name, resource_type, project_id, display_name, location, status, remarks, created_at, updated_at) VALUES (1, 'Example Production Instance', 'Compute Engine', 'my-project-123456', 'Example Production Instance', 'us-central1', 'active', 'Production server - Contact: admin@example.com, IP: 10.0.0.1', '2026-04-14 06:01:40.415', '2026-04-14 06:01:40.415'); 
INSERT INTO gcp_inventory (id, name, resource_type, project_id, display_name, location, status, remarks, created_at, updated_at) VALUES (2, 'Example Storage Bucket', 'Cloud Storage', 'my-project-123456', 'Example Storage Bucket', 'us-east1', 'active', 'Storage for backups: data.backup@company.com', '2026-04-14 06:01:40.442', '2026-04-14 06:01:40.442'); 

-- Completed gcp_inventory: 2 rows exported


-- =============================================
-- Table: aws_inventory
-- Total Records: 2
-- =============================================

TRUNCATE TABLE aws_inventory CASCADE;

INSERT INTO aws_inventory (id, identifier, service, type, region, account_name, account_id, status, remarks, created_at, updated_at) VALUES (1, 'i-1234567890abcdef0', 'EC2', 't3.medium', 'us-east-1', 'Production Account', '123456789012', 'active', 'Production web server - Contact: admin@example.com', '2026-04-14 06:01:58.217', '2026-04-14 06:01:58.217'); 
INSERT INTO aws_inventory (id, identifier, service, type, region, account_name, account_id, status, remarks, created_at, updated_at) VALUES (2, 'db-instance-1', 'RDS', 'db.t3.micro', 'us-west-2', 'Production Account', '123456789012', 'active', 'Database instance for application', '2026-04-14 06:01:58.229', '2026-04-14 06:01:58.229'); 

-- Completed aws_inventory: 2 rows exported


-- ERROR backing up table zabbix_subnets:
-- relation "zabbix_subnets" does not exist


-- =============================================
-- Table: aws_historical_data
-- Total Records: 2
-- =============================================

TRUNCATE TABLE aws_historical_data CASCADE;

INSERT INTO aws_historical_data (id, resource_id, identifier, service, type, region, account_name, account_id, status, remarks, change_type, month_year, created_at) VALUES (1, '1', 'i-1234567890abcdef0', 'EC2', 't3.medium', 'us-east-1', 'Production Account', '123456789012', 'active', 'Production web server - Contact: admin@example.com', 'imported', '2026-04', '2026-04-14 06:01:58.224'); 
INSERT INTO aws_historical_data (id, resource_id, identifier, service, type, region, account_name, account_id, status, remarks, change_type, month_year, created_at) VALUES (2, '2', 'db-instance-1', 'RDS', 'db.t3.micro', 'us-west-2', 'Production Account', '123456789012', 'active', 'Database instance for application', 'imported', '2026-04', '2026-04-14 06:01:58.232'); 

-- Completed aws_historical_data: 2 rows exported


-- =============================================
-- Table: azure_historical_data
-- Total Records: 2
-- =============================================

TRUNCATE TABLE azure_historical_data CASCADE;

INSERT INTO azure_historical_data (id, resource_id, name, type, resource_group, location, subscriptions, status, remarks, change_type, month_year, created_at) VALUES (1, '1', 'example-vm', 'Virtual Machine', 'production-rg', 'East US', 'prod-subscription', 'active', 'Production server - Example: test@email.com, 10.0.0.1', 'imported', '2026-04', '2026-04-14 06:02:06.757'); 
INSERT INTO azure_historical_data (id, resource_id, name, type, resource_group, location, subscriptions, status, remarks, change_type, month_year, created_at) VALUES (2, '2', 'example-storage', 'Storage Account', 'production-rg', 'West US', 'prod-subscription', 'active', 'Storage for backups: data.backup@company.com', 'imported', '2026-04', '2026-04-14 06:02:06.764'); 

-- Completed azure_historical_data: 2 rows exported


-- =============================================
-- Table: gcp_historical_data
-- Total Records: 2
-- =============================================

TRUNCATE TABLE gcp_historical_data CASCADE;

INSERT INTO gcp_historical_data (id, resource_id, name, resource_type, project_id, display_name, location, status, remarks, change_type, month_year, created_at) VALUES (1, '1', 'Example Production Instance', 'Compute Engine', 'my-project-123456', 'Example Production Instance', 'us-central1', 'active', 'Production server - Contact: admin@example.com, IP: 10.0.0.1', 'imported', '2026-04', '2026-04-14 06:01:40.433'); 
INSERT INTO gcp_historical_data (id, resource_id, name, resource_type, project_id, display_name, location, status, remarks, change_type, month_year, created_at) VALUES (2, '2', 'Example Storage Bucket', 'Cloud Storage', 'my-project-123456', 'Example Storage Bucket', 'us-east1', 'active', 'Storage for backups: data.backup@company.com', 'imported', '2026-04', '2026-04-14 06:01:40.444'); 

-- Completed gcp_historical_data: 2 rows exported


-- =============================================
-- Backup Summary
-- =============================================
-- Total Tables Backed Up: 9/29
-- Total Records: 83
-- Backup Completed: 2026-04-17T04:24:34.226Z
-- =============================================
