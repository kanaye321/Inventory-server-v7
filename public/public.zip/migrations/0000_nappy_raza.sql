CREATE TABLE "accessories" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"category" text NOT NULL,
	"status" text NOT NULL,
	"quantity" integer DEFAULT 1 NOT NULL,
	"description" text,
	"location" text,
	"serial_number" text,
	"model" text,
	"manufacturer" text,
	"purchase_date" text,
	"purchase_cost" text,
	"assigned_to" integer,
	"knox_id" text,
	"date_released" text,
	"date_returned" text,
	"released_by" text,
	"returned_to" text,
	"notes" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "activities" (
	"id" serial PRIMARY KEY NOT NULL,
	"action" text NOT NULL,
	"item_type" text NOT NULL,
	"item_id" integer NOT NULL,
	"user_id" integer,
	"timestamp" text NOT NULL,
	"notes" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "approval_monitoring" (
	"id" serial PRIMARY KEY NOT NULL,
	"type" text,
	"platform" text,
	"pic" text,
	"ip_address" text,
	"hostname_accounts" text,
	"identifier_serial_number" text,
	"approval_number" text,
	"start_date" text,
	"end_date" text,
	"status" text,
	"remarks" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "assets" (
	"id" serial PRIMARY KEY NOT NULL,
	"asset_tag" text NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"category" text NOT NULL,
	"status" text NOT NULL,
	"condition" text DEFAULT 'Good' NOT NULL,
	"purchase_date" text,
	"purchase_cost" text,
	"location" text,
	"serial_number" text,
	"model" text,
	"manufacturer" text,
	"notes" text,
	"knox_id" text,
	"ip_address" text,
	"mac_address" text,
	"os_type" text,
	"assigned_to" integer,
	"checkout_date" text,
	"expected_checkin_date" text,
	"finance_updated" boolean DEFAULT false,
	"department" text,
	"deployed_at" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "assets_asset_tag_unique" UNIQUE("asset_tag")
);
--> statement-breakpoint
CREATE TABLE "aws_historical_data" (
	"id" serial PRIMARY KEY NOT NULL,
	"resource_id" text,
	"identifier" text NOT NULL,
	"service" text NOT NULL,
	"type" text NOT NULL,
	"region" text NOT NULL,
	"account_name" text NOT NULL,
	"account_id" text NOT NULL,
	"status" text NOT NULL,
	"remarks" text,
	"change_type" text NOT NULL,
	"month_year" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "aws_inventory" (
	"id" serial PRIMARY KEY NOT NULL,
	"identifier" text NOT NULL,
	"service" text NOT NULL,
	"type" text NOT NULL,
	"region" text NOT NULL,
	"account_name" text NOT NULL,
	"account_id" text NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"remarks" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "azure_historical_data" (
	"id" serial PRIMARY KEY NOT NULL,
	"resource_id" text,
	"name" text NOT NULL,
	"type" text NOT NULL,
	"resource_group" text NOT NULL,
	"location" text NOT NULL,
	"subscriptions" text NOT NULL,
	"status" text NOT NULL,
	"remarks" text,
	"change_type" text NOT NULL,
	"month_year" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "azure_inventory" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"type" text NOT NULL,
	"resource_group" text NOT NULL,
	"location" text NOT NULL,
	"subscriptions" text,
	"status" text DEFAULT 'active' NOT NULL,
	"remarks" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bitlocker_keys" (
	"id" serial PRIMARY KEY NOT NULL,
	"serial_number" text NOT NULL,
	"identifier" text NOT NULL,
	"recovery_key" text NOT NULL,
	"notes" text,
	"date_added" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "blocked_ips" (
	"id" serial PRIMARY KEY NOT NULL,
	"ip" text NOT NULL,
	"reason" text NOT NULL,
	"blocked_by" text DEFAULT 'auto' NOT NULL,
	"unblocked" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"expires_at" timestamp,
	CONSTRAINT "blocked_ips_ip_unique" UNIQUE("ip")
);
--> statement-breakpoint
CREATE TABLE "components" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"type" text NOT NULL,
	"category" text NOT NULL,
	"quantity" integer DEFAULT 0 NOT NULL,
	"status" text DEFAULT 'available',
	"description" text,
	"location" text,
	"serial_number" text,
	"model" text,
	"manufacturer" text,
	"purchase_date" text,
	"purchase_cost" text,
	"warranty_expiry" text,
	"assigned_to" text,
	"date_released" text,
	"date_returned" text,
	"released_by" text,
	"returned_to" text,
	"specifications" text,
	"notes" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "consumable_assignments" (
	"id" serial PRIMARY KEY NOT NULL,
	"consumable_id" integer NOT NULL,
	"assigned_to" text NOT NULL,
	"serial_number" text,
	"knox_id" text,
	"quantity" integer DEFAULT 1 NOT NULL,
	"assigned_date" text NOT NULL,
	"returned_date" text,
	"status" text DEFAULT 'assigned' NOT NULL,
	"notes" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "consumables" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"category" text NOT NULL,
	"quantity" integer DEFAULT 1 NOT NULL,
	"status" text DEFAULT 'available' NOT NULL,
	"location" text,
	"model_number" text,
	"manufacturer" text,
	"purchase_date" text,
	"purchase_cost" text,
	"notes" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "custom_pages" (
	"id" serial PRIMARY KEY NOT NULL,
	"page_name" text NOT NULL,
	"page_slug" text NOT NULL,
	"table_name" text NOT NULL,
	"description" text,
	"icon" text DEFAULT 'FileText',
	"is_active" boolean DEFAULT true,
	"columns" json NOT NULL,
	"filters" json DEFAULT '[]'::json,
	"sort_config" json DEFAULT '{"field":"id","direction":"asc"}'::json,
	"pagination_config" json DEFAULT '{"pageSize":10,"enabled":true}'::json,
	"import_export_enabled" boolean DEFAULT true,
	"created_by" integer,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "custom_pages_page_name_unique" UNIQUE("page_name"),
	CONSTRAINT "custom_pages_page_slug_unique" UNIQUE("page_slug"),
	CONSTRAINT "custom_pages_table_name_unique" UNIQUE("table_name")
);
--> statement-breakpoint
CREATE TABLE "discovered_hosts" (
	"id" serial PRIMARY KEY NOT NULL,
	"hostname" text,
	"ip_address" text NOT NULL,
	"mac_address" text,
	"status" text DEFAULT 'new' NOT NULL,
	"last_seen" timestamp DEFAULT now(),
	"source" text DEFAULT 'zabbix' NOT NULL,
	"system_info" json DEFAULT '{}'::json,
	"hardware_details" json DEFAULT '{}'::json,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "gcp_historical_data" (
	"id" serial PRIMARY KEY NOT NULL,
	"resource_id" text,
	"name" text NOT NULL,
	"resource_type" text NOT NULL,
	"project_id" text NOT NULL,
	"display_name" text NOT NULL,
	"location" text NOT NULL,
	"status" text NOT NULL,
	"remarks" text,
	"change_type" text NOT NULL,
	"month_year" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "gcp_inventory" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"resource_type" text NOT NULL,
	"project_id" text NOT NULL,
	"display_name" text NOT NULL,
	"location" text NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"remarks" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "iam_account_approval_history" (
	"id" serial PRIMARY KEY NOT NULL,
	"iam_account_id" integer NOT NULL,
	"approval_number" text NOT NULL,
	"duration" text,
	"action" text NOT NULL,
	"acted_by" text NOT NULL,
	"acted_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "iam_accounts" (
	"id" serial PRIMARY KEY NOT NULL,
	"requestor" text NOT NULL,
	"knox_id" text NOT NULL,
	"name" text,
	"user_knox_id" text,
	"permission" text NOT NULL,
	"duration_start_date" text,
	"duration_end_date" text,
	"cloud_platform" text NOT NULL,
	"project_accounts" text,
	"approval_id" text,
	"remarks" text,
	"status" text DEFAULT 'active' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "it_equipment" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"category" text NOT NULL,
	"total_quantity" integer,
	"assigned_quantity" integer DEFAULT 0,
	"model" text,
	"location" text,
	"date_acquired" text,
	"knox_id" text,
	"serial_number" text,
	"date_release" text,
	"remarks" text,
	"status" text DEFAULT 'available',
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "it_equipment_assignments" (
	"id" serial PRIMARY KEY NOT NULL,
	"equipment_id" integer NOT NULL,
	"assigned_to" text NOT NULL,
	"knox_id" text,
	"serial_number" text,
	"quantity" integer DEFAULT 1 NOT NULL,
	"assigned_date" text NOT NULL,
	"returned_date" text,
	"status" text DEFAULT 'assigned' NOT NULL,
	"notes" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "license_assignments" (
	"id" serial PRIMARY KEY NOT NULL,
	"license_id" integer NOT NULL,
	"assigned_to" text NOT NULL,
	"notes" text,
	"assigned_date" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "licenses" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"key" text NOT NULL,
	"seats" text,
	"assigned_seats" integer DEFAULT 0,
	"company" text,
	"manufacturer" text,
	"purchase_date" text,
	"expiration_date" text,
	"purchase_cost" text,
	"status" text NOT NULL,
	"notes" text,
	"assigned_to" integer,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "monitor_inventory" (
	"id" serial PRIMARY KEY NOT NULL,
	"seat_number" text DEFAULT null,
	"knox_id" text DEFAULT null,
	"asset_number" text DEFAULT null,
	"serial_number" text DEFAULT null,
	"model" text DEFAULT null,
	"remarks" text DEFAULT null,
	"department" text DEFAULT null,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "monitoring_alert_rules" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"datasource" text NOT NULL,
	"query" text NOT NULL,
	"condition" text NOT NULL,
	"threshold" real NOT NULL,
	"evaluation_interval" integer DEFAULT 60,
	"for_duration" integer DEFAULT 300,
	"severity" text DEFAULT 'medium',
	"enabled" boolean DEFAULT true,
	"notification_channels" text,
	"annotations" text,
	"labels" text,
	"state" text DEFAULT 'normal',
	"last_evaluation" text,
	"error" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "monitoring_alerts" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"datasource" text NOT NULL,
	"query" text NOT NULL,
	"condition" text NOT NULL,
	"threshold" real NOT NULL,
	"evaluation_interval" integer DEFAULT 60,
	"for_duration" integer DEFAULT 300,
	"severity" text DEFAULT 'medium',
	"enabled" boolean DEFAULT true,
	"notification_channels" text,
	"annotations" text,
	"labels" text,
	"state" text DEFAULT 'normal',
	"last_evaluation" text,
	"error" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "monitoring_dashboards" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"is_public" boolean DEFAULT false,
	"refresh_interval" integer DEFAULT 30,
	"tags" text,
	"user_id" integer,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "monitoring_datasources" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"type" text NOT NULL,
	"url" text NOT NULL,
	"access" text DEFAULT 'proxy',
	"basic_auth" boolean DEFAULT false,
	"basic_auth_user" text,
	"basic_auth_password" text,
	"database" text,
	"json_data" text,
	"secure_json_fields" text,
	"is_default" boolean DEFAULT false,
	"status" text DEFAULT 'pending',
	"last_check" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "monitoring_notifications" (
	"id" serial PRIMARY KEY NOT NULL,
	"alert_id" integer NOT NULL,
	"type" text NOT NULL,
	"recipient" text NOT NULL,
	"message" text NOT NULL,
	"status" text DEFAULT 'pending',
	"sent_at" text,
	"error" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "monitoring_panels" (
	"id" serial PRIMARY KEY NOT NULL,
	"dashboard_id" integer NOT NULL,
	"title" text NOT NULL,
	"type" text NOT NULL,
	"datasource" text NOT NULL,
	"query" text NOT NULL,
	"refresh_interval" integer DEFAULT 30,
	"width" integer DEFAULT 6,
	"height" integer DEFAULT 300,
	"x_pos" integer DEFAULT 0,
	"y_pos" integer DEFAULT 0,
	"thresholds" text,
	"unit" text,
	"decimals" integer DEFAULT 2,
	"show_legend" boolean DEFAULT true,
	"color_scheme" text DEFAULT 'default',
	"config" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notifications" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer,
	"title" text NOT NULL,
	"message" text NOT NULL,
	"type" text,
	"read" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "security_events" (
	"id" serial PRIMARY KEY NOT NULL,
	"ip" text NOT NULL,
	"method" text NOT NULL,
	"path" text NOT NULL,
	"threat_type" text NOT NULL,
	"severity" text NOT NULL,
	"blocked" boolean DEFAULT true NOT NULL,
	"user_agent" text,
	"details" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"site_name" text,
	"site_url" text,
	"theme" text DEFAULT 'light',
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "storage_media_inventory" (
	"id" serial PRIMARY KEY NOT NULL,
	"media_type" text NOT NULL,
	"serial_number" text NOT NULL,
	"capacity" text,
	"status" text DEFAULT 'available' NOT NULL,
	"location" text,
	"remarks" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "storage_media_inventory_serial_number_unique" UNIQUE("serial_number")
);
--> statement-breakpoint
CREATE TABLE "system_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"site_name" text DEFAULT 'SRPH-MIS' NOT NULL,
	"site_url" text DEFAULT '' NOT NULL,
	"default_language" text DEFAULT 'en' NOT NULL,
	"default_timezone" text DEFAULT 'UTC' NOT NULL,
	"allow_public_registration" boolean DEFAULT false,
	"company_name" text DEFAULT 'SRPH' NOT NULL,
	"company_address" text DEFAULT '',
	"company_phone" text DEFAULT '',
	"company_email" text DEFAULT '',
	"company_logo" text DEFAULT '',
	"mail_driver" text DEFAULT '',
	"mail_host" text DEFAULT '',
	"mail_port" text DEFAULT '',
	"mail_username" text DEFAULT '',
	"mail_password" text DEFAULT '',
	"mail_from_address" text DEFAULT '',
	"mail_from_name" text DEFAULT '',
	"iam_expiration_email_subject" text DEFAULT '',
	"iam_expiration_email_body" text DEFAULT '',
	"asset_tag_prefix" text DEFAULT 'SRPH',
	"asset_tag_zeros" integer DEFAULT 5,
	"asset_auto_increment" boolean DEFAULT true,
	"asset_checkout_policy" text DEFAULT '',
	"asset_checkout_duration" integer DEFAULT 30,
	"enable_login_attempts" boolean DEFAULT true,
	"max_login_attempts" integer DEFAULT 5,
	"lockout_duration" integer DEFAULT 30,
	"password_min_length" integer DEFAULT 8,
	"require_special_char" boolean DEFAULT true,
	"require_uppercase" boolean DEFAULT true,
	"require_number" boolean DEFAULT true,
	"password_expiry_days" integer DEFAULT 90,
	"enable_admin_notifications" boolean DEFAULT true,
	"enable_user_notifications" boolean DEFAULT true,
	"notify_on_checkout" boolean DEFAULT true,
	"notify_on_checkin" boolean DEFAULT true,
	"notify_on_overdue" boolean DEFAULT true,
	"notify_on_iam_expiration" boolean DEFAULT true,
	"notify_on_vm_expiration" boolean DEFAULT true,
	"notify_on_it_equipment_changes" boolean DEFAULT true,
	"notify_on_user_changes" boolean DEFAULT true,
	"notify_on_vm_inventory_changes" boolean DEFAULT true,
	"notify_on_iam_account_changes" boolean DEFAULT true,
	"notify_on_gcp_changes" boolean DEFAULT true,
	"notify_on_azure_changes" boolean DEFAULT true,
	"notify_on_approval_expiration" boolean DEFAULT true,
	"session_timeout" integer DEFAULT 1800,
	"automatic_backups" boolean DEFAULT false,
	"backup_frequency" text DEFAULT 'daily',
	"backup_time" text DEFAULT '03:00',
	"backup_retention" integer DEFAULT 30,
	"maintenance_mode" boolean DEFAULT false,
	"updated_at" timestamp DEFAULT now(),
	"auto_backup_enabled" boolean DEFAULT false,
	"auto_optimize_enabled" boolean DEFAULT false,
	"optimize_time" text DEFAULT '04:00',
	"backup_retention_days" integer DEFAULT 30,
	"email_notifications" boolean DEFAULT true,
	"auto_backup" boolean DEFAULT false,
	"auto_optimize" boolean DEFAULT false,
	"retention_days" integer DEFAULT 30,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"username" text NOT NULL,
	"password" text NOT NULL,
	"first_name" text,
	"last_name" text,
	"email" text,
	"phone" text,
	"location" text,
	"bio" text,
	"avatar" text,
	"department" text,
	"is_admin" boolean DEFAULT false,
	"role_id" integer,
	"mfa_enabled" boolean DEFAULT false,
	"mfa_secret" text,
	"force_password_change" boolean DEFAULT false,
	"permissions" json DEFAULT '{"assets":{"view":true,"edit":false,"add":false},"components":{"view":true,"edit":false,"add":false},"accessories":{"view":true,"edit":false,"add":false},"consumables":{"view":true,"edit":false,"add":false},"licenses":{"view":true,"edit":false,"add":false},"users":{"view":false,"edit":false,"add":false},"reports":{"view":true,"edit":false,"add":false},"vmMonitoring":{"view":true,"edit":false,"add":false},"networkDiscovery":{"view":true,"edit":false,"add":false},"bitlockerKeys":{"view":false,"edit":false,"add":false},"admin":{"view":false,"edit":false,"add":false}}'::json,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "users_username_unique" UNIQUE("username")
);
--> statement-breakpoint
CREATE TABLE "vm_approval_history" (
	"id" serial PRIMARY KEY NOT NULL,
	"vm_id" integer NOT NULL,
	"old_approval_number" text,
	"new_approval_number" text,
	"changed_by" integer,
	"changed_at" timestamp DEFAULT now() NOT NULL,
	"reason" text,
	"notes" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "vm_inventory" (
	"id" serial PRIMARY KEY NOT NULL,
	"vm_id" text,
	"vm_name" text NOT NULL,
	"vm_status" text DEFAULT 'Active' NOT NULL,
	"vm_ip" text,
	"vm_os" text,
	"cpu_count" integer DEFAULT 0,
	"memory_gb" integer DEFAULT 0,
	"disk_capacity_gb" integer DEFAULT 0,
	"requestor" text,
	"knox_id" text,
	"department" text,
	"start_date" text,
	"end_date" text,
	"jira_number" text,
	"approval_number" text,
	"remarks" text,
	"internet_access" boolean DEFAULT false,
	"vm_os_version" text,
	"hypervisor" text,
	"host_name" text,
	"host_model" text,
	"host_ip" text,
	"host_os" text,
	"rack" text,
	"deployed_by" text,
	"user" text,
	"jira_ticket" text,
	"date_deleted" text,
	"guest_os" text,
	"power_state" text,
	"memory_mb" integer,
	"disk_gb" integer,
	"ip_address" text,
	"mac_address" text,
	"vmware_tools" text,
	"cluster" text,
	"datastore" text,
	"status" text DEFAULT 'available',
	"assigned_to" integer,
	"location" text,
	"serial_number" text,
	"model" text,
	"manufacturer" text,
	"purchase_date" text,
	"purchase_cost" text,
	"created_date" text,
	"last_modified" text,
	"notes" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "vm_monitoring" (
	"id" serial PRIMARY KEY NOT NULL,
	"vm_id" integer NOT NULL,
	"zabbix_id" text,
	"status" text,
	"uptime" integer,
	"last_checked" timestamp,
	"monitoring_enabled" boolean DEFAULT true,
	"alerts_enabled" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "vms" (
	"id" serial PRIMARY KEY NOT NULL,
	"vm_name" text NOT NULL,
	"host_name" text NOT NULL,
	"guest_os" text NOT NULL,
	"power_state" text DEFAULT 'stopped' NOT NULL,
	"cpu_count" integer DEFAULT 1,
	"memory_mb" integer DEFAULT 1024,
	"disk_gb" integer DEFAULT 20,
	"ip_address" text,
	"mac_address" text,
	"vmware_tools" text,
	"cluster" text,
	"host_model" text,
	"datastore" text,
	"status" text DEFAULT 'available' NOT NULL,
	"assigned_to" integer,
	"location" text,
	"serial_number" text,
	"model" text,
	"manufacturer" text,
	"purchase_date" text,
	"purchase_cost" text,
	"department" text,
	"description" text,
	"created_date" text DEFAULT '2026-04-17T06:45:03.895Z',
	"last_modified" text DEFAULT '2026-04-17T06:45:03.896Z',
	"notes" text
);
--> statement-breakpoint
CREATE TABLE "zabbix_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"server_url" text DEFAULT '' NOT NULL,
	"username" text DEFAULT '' NOT NULL,
	"password" text DEFAULT '' NOT NULL,
	"api_token" text DEFAULT '',
	"last_sync" timestamp,
	"sync_interval" integer DEFAULT 30,
	"enabled" boolean DEFAULT false,
	"updated_at" timestamp DEFAULT now(),
	"zabbix_url" text,
	"zabbix_api_token" text,
	"refresh_interval" integer DEFAULT 30,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "zabbix_subnets" (
	"id" serial PRIMARY KEY NOT NULL,
	"cidr_range" text NOT NULL,
	"description" text,
	"enabled" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "accessories" ADD CONSTRAINT "accessories_assigned_to_users_id_fk" FOREIGN KEY ("assigned_to") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "activities" ADD CONSTRAINT "activities_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "assets" ADD CONSTRAINT "assets_assigned_to_users_id_fk" FOREIGN KEY ("assigned_to") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "consumable_assignments" ADD CONSTRAINT "consumable_assignments_consumable_id_consumables_id_fk" FOREIGN KEY ("consumable_id") REFERENCES "public"."consumables"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "iam_account_approval_history" ADD CONSTRAINT "iam_account_approval_history_iam_account_id_iam_accounts_id_fk" FOREIGN KEY ("iam_account_id") REFERENCES "public"."iam_accounts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "it_equipment_assignments" ADD CONSTRAINT "it_equipment_assignments_equipment_id_it_equipment_id_fk" FOREIGN KEY ("equipment_id") REFERENCES "public"."it_equipment"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "license_assignments" ADD CONSTRAINT "license_assignments_license_id_licenses_id_fk" FOREIGN KEY ("license_id") REFERENCES "public"."licenses"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "licenses" ADD CONSTRAINT "licenses_assigned_to_users_id_fk" FOREIGN KEY ("assigned_to") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "monitoring_dashboards" ADD CONSTRAINT "monitoring_dashboards_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "monitoring_panels" ADD CONSTRAINT "monitoring_panels_dashboard_id_monitoring_dashboards_id_fk" FOREIGN KEY ("dashboard_id") REFERENCES "public"."monitoring_dashboards"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "vm_approval_history" ADD CONSTRAINT "vm_approval_history_vm_id_vm_inventory_id_fk" FOREIGN KEY ("vm_id") REFERENCES "public"."vm_inventory"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "vm_approval_history" ADD CONSTRAINT "vm_approval_history_changed_by_users_id_fk" FOREIGN KEY ("changed_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "vm_inventory" ADD CONSTRAINT "vm_inventory_assigned_to_users_id_fk" FOREIGN KEY ("assigned_to") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "vms" ADD CONSTRAINT "vms_assigned_to_users_id_fk" FOREIGN KEY ("assigned_to") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;