-- Migration: add deployed_at column to assets table
-- This records the exact timestamp when an asset's status first became "Deployed".
-- Back-fill existing Deployed assets with their updatedAt value as the best available approximation.

ALTER TABLE assets ADD COLUMN IF NOT EXISTS deployed_at TEXT;

-- Back-fill: existing Deployed assets get their updated_at as best approximation
UPDATE assets
SET deployed_at = TO_CHAR(updated_at, 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')
WHERE status = 'Deployed' AND deployed_at IS NULL;
