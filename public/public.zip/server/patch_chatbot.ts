import fs from "fs";
import path from "path";

const ROUTES_FILE = path.join(process.cwd(), "server", "routes.ts");

let content = fs.readFileSync(ROUTES_FILE, "utf8");

// Find the exact start and end markers
const START_MARKER = `  // ─── Chatbot API (Local Ollama) ───────────────────────────────────────────────`;
const END_MARKER = `\r\n  return server;\r\n}\r\n`;

const startIdx = content.indexOf(START_MARKER);
const endIdx = content.lastIndexOf(END_MARKER);

if (startIdx === -1) {
  console.error("❌ Could not find chat route start marker");
  process.exit(1);
}
if (endIdx === -1) {
  console.error("❌ Could not find route end marker");
  process.exit(1);
}

console.log(`✅ Found chat route at index ${startIdx}, ends at ${endIdx}`);

const newChatRoute = `  // ─── Chatbot API (Local Ollama) ───────────────────────────────────────────────
  // Uses SQL-first approach: runs real Postgres queries, passes pre-computed facts to LLM.
  // The LLM only phrases the answer — it NEVER counts or filters data (prevents hallucination).
  app.post("/api/chat", requireAuth, async (req: Request, res: Response) => {
    try {
      const { message, history } = req.body;
      if (!message?.trim()) return res.status(400).json({ reply: "Please enter a message." });

      const { CHATBOT_SYSTEM_KNOWLEDGE } = await import("./chatbot-knowledge");
      const msgLower = message.toLowerCase();
      const now = new Date().toLocaleString();

      // ── Intent classification ──────────────────────────────────────────────
      const isGuide     = /\\b(how to|how do|how can|steps|guide|setup|configure|install|fix|troubleshoot|explain|what is|what are|help me)\\b/.test(msgLower);
      const isInventory = !isGuide && /\\b(list|show|how many|count|total|give me|find|search|which|who has|assigned|status of|ip of|details of|asset|device|server|vm|virtual machine|monitor|license|user|department|inventory|equipment|it equipment|accessory|accessories|component|consumable|iam|bitlocker|cloud|azure|gcp|aws|deployed|available|active|expired)\\b/.test(msgLower);

      // ── System prompt ──────────────────────────────────────────────────────
      let systemPrompt = \`You are the SRPH-MIS AI Assistant for the IT system.
Today is \${now}.
STRICT RULES:
1. ONLY use the data in the INVENTORY FACTS block below to answer questions.
2. If the answer is not in INVENTORY FACTS, reply EXACTLY: "I do not have enough information in my database to answer that."
3. NEVER invent, guess, or generate any names, numbers, or data not explicitly present in the facts.
4. When answering count/total questions, use ONLY the exact numbers from the facts - do not recalculate.
5. Be concise and direct.\`;

      // ── SQL-First inventory resolution ────────────────────────────────────
      if (isInventory) {
        console.log("[CHATBOT] Intent: INVENTORY — running SQL queries against PostgreSQL (DATABASE_URL from .env)...");

        const facts: string[] = [];
        const wantsOverview = /\\b(overview|all|summary|everything|inventory|total|how many|count)\\b/.test(msgLower);
        const wantsList     = /\\b(list|show|give me|find|details|which|who)\\b/.test(msgLower);
        const wantsDeployed = /\\bdeployed\\b/.test(msgLower);
        const wantsAvailable = /\\bavailable\\b/.test(msgLower);
        const wantsExpired  = /\\bexpired\\b/.test(msgLower);
        const wantsActive   = /\\bactive\\b/.test(msgLower);

        try {
          // ── ASSETS ──
          if (/\\b(asset|laptop|desktop|computer|device|pc|workstation)\\b/.test(msgLower) || wantsOverview) {
            const counts = (await db.execute<{status: string; count: string}>(
              sql\`SELECT status, COUNT(*)::int AS count FROM assets GROUP BY status ORDER BY count DESC\`
            )).rows as {status: string; count: string}[];

            if (counts.length > 0) {
              const total = counts.reduce((s, r) => s + Number(r.count), 0);
              facts.push(\`ASSETS — Total: \${total}\`);
              counts.forEach(r => facts.push(\`  • \${r.status}: \${r.count}\`));
            } else {
              facts.push("ASSETS — No records found.");
            }

            if (wantsList) {
              const filterStatus = wantsDeployed ? 'Deployed' : wantsAvailable ? 'available' : null;
              const listq = filterStatus
                ? sql\`SELECT asset_tag,name,status,category,assigned_to FROM assets WHERE status=\${filterStatus} ORDER BY name LIMIT 50\`
                : sql\`SELECT asset_tag,name,status,category,assigned_to FROM assets ORDER BY name LIMIT 50\`;
              const rows = (await db.execute<{asset_tag:string;name:string;status:string;category:string;assigned_to:string}>(listq)).rows as {asset_tag:string;name:string;status:string;category:string;assigned_to:string}[];
              if (rows.length > 0) {
                facts.push(\`\nASSET LIST\${filterStatus ? " ["+filterStatus+"]" : ""}:\`);
                rows.forEach(r => facts.push(\`  [\${r.asset_tag}] \${r.name} | \${r.status} | \${r.category} | Assigned: \${r.assigned_to || "Unassigned"}\`));
              }
            }
          }

          // ── USERS ──
          if (/\\b(user|staff|employee|personnel|who|department)\\b/.test(msgLower) || wantsOverview) {
            const cnt = (await db.execute<{count:string}>(sql\`SELECT COUNT(*)::int AS count FROM users\`)).rows as {count:string}[];
            facts.push(\`\nUSERS — Total: \${cnt[0]?.count ?? 0}\`);
            if (wantsList) {
              const rows = (await db.execute<{username:string;email:string;role:string;department:string}>(
                sql\`SELECT username,email,role,department FROM users ORDER BY username LIMIT 30\`
              )).rows as {username:string;email:string;role:string;department:string}[];
              rows.forEach(r => facts.push(\`  \${r.username} | \${r.email} | \${r.role} | Dept: \${r.department||"N/A"}\`));
            }
          }

          // ── VIRTUAL MACHINES ──
          if (/\\b(vm|virtual machine|server|node)\\b/.test(msgLower) || wantsOverview) {
            const counts = (await db.execute<{vm_status:string;count:string}>(
              sql\`SELECT vm_status, COUNT(*)::int AS count FROM vm_inventory GROUP BY vm_status ORDER BY count DESC\`
            )).rows as {vm_status:string;count:string}[];
            if (counts.length > 0) {
              const total = counts.reduce((s, r) => s + Number(r.count), 0);
              facts.push(\`\nVIRTUAL MACHINES — Total: \${total}\`);
              counts.forEach(r => facts.push(\`  • \${r.vm_status}: \${r.count}\`));
            } else {
              facts.push("\nVIRTUAL MACHINES — No records found.");
            }
            if (wantsList) {
              const rows = (await db.execute<{vm_name:string;vm_status:string;ip_address:string;department:string}>(
                sql\`SELECT vm_name,vm_status,ip_address,department FROM vm_inventory ORDER BY vm_name LIMIT 30\`
              )).rows as {vm_name:string;vm_status:string;ip_address:string;department:string}[];
              rows.forEach(r => facts.push(\`  \${r.vm_name} | \${r.vm_status} | IP:\${r.ip_address||"N/A"} | \${r.department||"N/A"}\`));
            }
          }

          // ── IT EQUIPMENT ──
          if (/\\b(it equipment|equipment|switch|router|access point)\\b/.test(msgLower) || wantsOverview) {
            const counts = (await db.execute<{status:string;count:string}>(
              sql\`SELECT status, COUNT(*)::int AS count FROM it_equipment GROUP BY status ORDER BY count DESC\`
            )).rows as {status:string;count:string}[];
            if (counts.length > 0) {
              const total = counts.reduce((s, r) => s + Number(r.count), 0);
              facts.push(\`\nIT EQUIPMENT — Total: \${total}\`);
              counts.forEach(r => facts.push(\`  • \${r.status}: \${r.count}\`));
            } else {
              facts.push("\nIT EQUIPMENT — No records found.");
            }
            if (wantsList) {
              const rows = (await db.execute<{name:string;category:string;status:string;location:string}>(
                sql\`SELECT name,category,status,location FROM it_equipment ORDER BY name LIMIT 30\`
              )).rows as {name:string;category:string;status:string;location:string}[];
              rows.forEach(r => facts.push(\`  \${r.name} | \${r.category} | \${r.status} | \${r.location||"N/A"}\`));
            }
          }

          // ── MONITORS ──
          if (/\\b(monitor|screen|display)\\b/.test(msgLower) || wantsOverview) {
            const cnt = (await db.execute<{count:string}>(sql\`SELECT COUNT(*)::int AS count FROM monitor_inventory\`)).rows as {count:string}[];
            facts.push(\`\nMONITORS — Total: \${cnt[0]?.count ?? 0}\`);
          }

          // ── LICENSES ──
          if (/\\b(license|software|key|seat)\\b/.test(msgLower) || wantsOverview) {
            const counts = (await db.execute<{status:string;count:string}>(
              sql\`SELECT status, COUNT(*)::int AS count FROM licenses GROUP BY status ORDER BY count DESC\`
            )).rows as {status:string;count:string}[];
            if (counts.length > 0) {
              const total = counts.reduce((s, r) => s + Number(r.count), 0);
              facts.push(\`\nLICENSES — Total: \${total}\`);
              counts.forEach(r => facts.push(\`  • \${r.status}: \${r.count}\`));
            } else {
              facts.push("\nLICENSES — No records found.");
            }
          }

          // ── ACCESSORIES ──
          if (/\\b(accessor|keyboard|mouse|headset|peripheral|dock)\\b/.test(msgLower) || wantsOverview) {
            const counts = (await db.execute<{status:string;count:string}>(
              sql\`SELECT status, COUNT(*)::int AS count FROM accessories GROUP BY status ORDER BY count DESC\`
            )).rows as {status:string;count:string}[];
            if (counts.length > 0) {
              const total = counts.reduce((s, r) => s + Number(r.count), 0);
              facts.push(\`\nACCESSORIES — Total: \${total}\`);
              counts.forEach(r => facts.push(\`  • \${r.status}: \${r.count}\`));
            } else {
              facts.push("\nACCESSORIES — No records found.");
            }
          }

          // ── COMPONENTS ──
          if (/\\b(component|ram|cpu|hard drive|ssd|gpu|memory|processor|disk)\\b/.test(msgLower) || wantsOverview) {
            const cnt = (await db.execute<{count:string}>(sql\`SELECT COUNT(*)::int AS count FROM components\`)).rows as {count:string}[];
            facts.push(\`\nCOMPONENTS — Total: \${cnt[0]?.count ?? 0}\`);
          }

          // ── CONSUMABLES ──
          if (/\\b(consumable|toner|paper|battery|ink|supply)\\b/.test(msgLower) || wantsOverview) {
            const cnt = (await db.execute<{count:string}>(sql\`SELECT COUNT(*)::int AS count FROM consumables\`)).rows as {count:string}[];
            facts.push(\`\nCONSUMABLES — Total: \${cnt[0]?.count ?? 0}\`);
          }

          // ── IAM ACCOUNTS ──
          if (/\\b(iam|iam account|cloud account|access account)\\b/.test(msgLower) || wantsOverview) {
            const counts = (await db.execute<{status:string;count:string}>(
              sql\`SELECT status, COUNT(*)::int AS count FROM iam_accounts GROUP BY status ORDER BY count DESC\`
            )).rows as {status:string;count:string}[];
            if (counts.length > 0) {
              const total = counts.reduce((s, r) => s + Number(r.count), 0);
              facts.push(\`\nIAM ACCOUNTS — Total: \${total}\`);
              counts.forEach(r => facts.push(\`  • \${r.status}: \${r.count}\`));
            } else {
              facts.push("\nIAM ACCOUNTS — No records found.");
            }
          }

          // ── BITLOCKER ──
          if (/\\b(bitlocker|recovery key|encryption key)\\b/.test(msgLower)) {
            const cnt = (await db.execute<{count:string}>(sql\`SELECT COUNT(*)::int AS count FROM bitlocker_keys\`)).rows as {count:string}[];
            facts.push(\`\nBITLOCKER KEYS — Total: \${cnt[0]?.count ?? 0}\`);
          }

        } catch (dbErr: any) {
          console.error("[CHATBOT] SQL query error:", dbErr.message);
          facts.push("DATABASE ERROR: Could not query data. Check DATABASE_URL in .env file.");
        }

        systemPrompt += facts.length > 0
          ? \`\n\n--- INVENTORY FACTS (live SQL from PostgreSQL using DATABASE_URL in .env) ---\n\${facts.join("\n")}\n--- END INVENTORY FACTS ---\`
          : \`\n\nINVENTORY FACTS: No data found for this query.\`;

      } else if (isGuide) {
        console.log("[CHATBOT] Intent: GUIDE — injecting system manual...");
        systemPrompt += \`\n\n--- SRPH-MIS SYSTEM MANUAL ---\n\${CHATBOT_SYSTEM_KNOWLEDGE}\n--- END OF MANUAL ---\`;
      } else {
        console.log("[CHATBOT] Intent: GENERAL — answering directly.");
      }

      // ── Limit history to last 6 messages ──────────────────────────────────
      const recentHistory = (history || []).filter((m: any) => m.role && m.content).slice(-6);

      // ── Call Ollama ───────────────────────────────────────────────────────
      const OLLAMA_TIMEOUT_MS = 120_000;
      const ollamaResponse = await fetch("http://127.0.0.1:11434/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: AbortSignal.timeout(OLLAMA_TIMEOUT_MS),
        body: JSON.stringify({
          model: "llama3",
          messages: [
            { role: "system", content: systemPrompt },
            ...recentHistory,
            { role: "user", content: message }
          ],
          stream: false,
          options: {
            temperature: 0.1,   // Near-zero: LLM phrases the answer, never invents data
            num_predict: 512,
            num_ctx: 4096,
            top_k: 10,
            top_p: 0.5,
            repeat_penalty: 1.2
          }
        })
      });

      if (!ollamaResponse.ok) throw new Error(\`Ollama API error: \${ollamaResponse.statusText}\`);

      const data = await ollamaResponse.json();
      res.json({ reply: data.message?.content || "No response received." });

    } catch (err: any) {
      const isTimeout = err?.name === "TimeoutError" || err?.name === "AbortError";
      console.error(\`[CHATBOT] \${isTimeout ? "Timeout" : "Error"} calling Ollama:\`, err.message);
      res.status(503).json({
        reply: isTimeout
          ? "The AI is taking too long to respond. It may still be loading the model. Please try again."
          : "Cannot reach the local AI engine. Please ensure Ollama is running and llama3 is loaded."
      });
    }
  });

`;

// Replace from START_MARKER to just before `  return server;\n}`
const before = content.slice(0, startIdx);
const after = content.slice(endIdx);

const patched = before + newChatRoute + after;

fs.writeFileSync(ROUTES_FILE, patched, "utf8");
console.log("✅ Chatbot route successfully patched with SQL-first implementation!");
console.log(`   File size: ${(patched.length / 1024).toFixed(1)} KB`);
