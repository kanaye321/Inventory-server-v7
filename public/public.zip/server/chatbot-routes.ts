import type { Express, Request, Response } from "express";
import { sql } from "drizzle-orm";
import { db } from "./db";

// ─────────────────────────────────────────────────────────────────────────────
// TIMEOUT CONSTANTS
// Ollama is NEVER called for inventory/data questions.
// It is only called for guide/how-to questions with a hard 20s cap.
// ─────────────────────────────────────────────────────────────────────────────
const OLLAMA_TIMEOUT_MS = 20_000;

// ─────────────────────────────────────────────────────────────────────────────
// NLP HELPERS — extract structured intent from natural language
// ─────────────────────────────────────────────────────────────────────────────

/** Extract all knox_id patterns (e.g. j.flora, m.santos) from the message */
function extractKnoxIds(msg: string): string[] {
  const matches = msg.match(/\b([a-z]+\.[a-z]+)\b/gi) || [];
  return [...new Set(matches.map(m => m.toLowerCase()))];
}

/** Map keyword → exact DB category value */
function extractCategory(msg: string): string | null {
  const map: [RegExp, string][] = [
    [/\blaptop(s)?\b/i,      'Laptop'],
    [/\bdesktop(s)?\b/i,     'Desktop'],
    [/\bmobile(s)?\b/i,      'Mobile'],
    [/\bphone(s)?\b/i,       'Mobile'],
    [/\bmonitor(s)?\b/i,     'Monitor'],
    [/\btablet(s)?\b/i,      'Tablet'],
    [/\baccessor(y|ies)\b/i, 'Accessory'],
    [/\blicense(s)?\b/i,     'License'],
  ];
  for (const [re, cat] of map) {
    if (re.test(msg)) return cat;
  }
  return null;
}

/** Map keyword → exact DB status value */
function extractAssetStatus(msg: string): string | null {
  if (/\bdeployed\b/i.test(msg))  return 'Deployed';
  if (/\bavailable\b/i.test(msg)) return 'available';
  if (/\bpending\b/i.test(msg))   return 'pending';
  if (/\bon.hand\b/i.test(msg))   return 'On-Hand';
  if (/\breserved\b/i.test(msg))  return 'Reserved';
  return null;
}

/** True if the message is counting, false if listing */
function isCountQuestion(msg: string): boolean {
  return /\b(how many|count|total|number of)\b/i.test(msg);
}

/** True if asking "who has the most / ranking" */
function isRankingQuestion(msg: string): boolean {
  return /\b(who has (the )?most|ranking|rank|top user|most asset)\b/i.test(msg);
}

// ─────────────────────────────────────────────────────────────────────────────
// SQL SAFETY — sanitize before execution
// ─────────────────────────────────────────────────────────────────────────────
function sanitizeSQL(raw: string): string | null {
  const codeBlockMatch = raw.match(/```(?:sql)?\s*([\s\S]+?)```/i);
  let extracted = codeBlockMatch ? codeBlockMatch[1].trim() : raw.trim();

  const selectMatch = extracted.match(/(SELECT[\s\S]+?)(?:;|$)/i);
  if (!selectMatch) return null;

  let query = selectMatch[1].trim();
  const dangerous = /\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|TRUNCATE|GRANT|REVOKE|EXEC|EXECUTE|COPY|DO)\b/i;
  if (dangerous.test(query)) return null;

  if (!/\bLIMIT\b/i.test(query)) query += ' LIMIT 50';
  return query + ';';
}

// ─────────────────────────────────────────────────────────────────────────────
// DB QUERY RUNNER
// ─────────────────────────────────────────────────────────────────────────────
async function runQuery(rawSQL: string): Promise<{ rows: any[]; error?: string }> {
  if (!db) return { rows: [], error: "Database not connected" };

  const cleanSQL = sanitizeSQL(rawSQL);
  if (!cleanSQL) return { rows: [], error: "Could not extract a safe SELECT query." };

  console.log("[CHATBOT] SQL:", cleanSQL);
  try {
    const result = await db.execute(sql.raw(cleanSQL));
    return { rows: result.rows || [] };
  } catch (err: any) {
    console.error("[CHATBOT] SQL error:", err.message);
    return { rows: [], error: err.message };
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// RESPONSE FORMATTER — pure TypeScript, no Ollama
// ─────────────────────────────────────────────────────────────────────────────
function formatRows(rows: any[], question: string): string {
  if (rows.length === 0) return "No results found for your query.";

  const keys = Object.keys(rows[0]);

  // Single scalar (COUNT)
  if (rows.length === 1 && keys.length === 1) {
    const val = rows[0][keys[0]];
    return `The answer is **${val}**.`;
  }

  // GROUP BY result (2 columns, one is count)
  if (keys.includes('count') && keys.length === 2) {
    const groupKey = keys.find(k => k !== 'count') || keys[0];
    const total = rows.reduce((s: number, r: any) => s + (Number(r.count) || 0), 0);
    const lines = rows.map((r: any, i: number) =>
      `${i + 1}. **${r[groupKey] ?? 'N/A'}** — ${r.count} item${r.count !== 1 ? 's' : ''}`
    );
    return `**Results** (${rows.length} group${rows.length !== 1 ? 's' : ''}, **${total}** total):\n\n${lines.join('\n')}`;
  }

  // Asset list
  if (keys.includes('asset_tag')) {
    const lines = rows.slice(0, 30).map((r: any) => {
      const tag    = r.asset_tag ? `**${r.asset_tag}**` : '';
      const name   = r.name      ? ` — ${r.name}` : '';
      const cat    = r.category  ? ` | ${r.category}` : '';
      const status = r.status    ? ` | *${r.status}*` : '';
      const knox   = r.knox_id   ? ` | 👤 ${r.knox_id}` : '';
      const loc    = r.location  ? ` | 📍 ${r.location}` : '';
      return `• ${tag}${name}${cat}${status}${knox}${loc}`;
    });
    const footer = rows.length > 30 ? `\n\n*(Showing 30 of ${rows.length})*` : '';
    return `**${rows.length}** asset${rows.length !== 1 ? 's' : ''} found:\n\n${lines.join('\n')}${footer}`;
  }

  // VM list
  if (keys.includes('vm_name')) {
    const lines = rows.slice(0, 30).map((r: any) =>
      `• **${r.vm_name}** | *${r.vm_status ?? ''}* | 🌐 ${r.vm_ip ?? 'N/A'} | ${r.department ?? ''}`
    );
    return `**${rows.length}** VM${rows.length !== 1 ? 's' : ''} found:\n\n${lines.join('\n')}` +
           (rows.length > 30 ? `\n\n*(Showing 30 of ${rows.length})*` : '');
  }

  // Generic markdown table
  const header  = `| ${keys.join(' | ')} |`;
  const divider = `| ${keys.map(() => '---').join(' | ')} |`;
  const rowLines = rows.slice(0, 25).map((r: any) =>
    `| ${keys.map(k => {
      const v = r[k];
      if (v === null || v === undefined) return 'N/A';
      if (typeof v === 'boolean') return v ? '✅' : '❌';
      return String(v).slice(0, 60);
    }).join(' | ')} |`
  );
  return `**${rows.length}** result${rows.length !== 1 ? 's' : ''}:\n\n${[header, divider, ...rowLines].join('\n')}` +
         (rows.length > 25 ? `\n\n*(Showing 25 of ${rows.length})*` : '');
}

// ─────────────────────────────────────────────────────────────────────────────
// CORE QUERY ENGINE — handles inventory questions with ZERO Ollama calls
// Uses NLP extraction + SQL templates to cover 95%+ of questions.
// ─────────────────────────────────────────────────────────────────────────────
async function handleInventoryQuestion(message: string): Promise<string | null> {
  if (!db) return "Database is not connected.";

  const m       = message.toLowerCase().trim();
  const knoxIds = extractKnoxIds(m);
  const cat     = extractCategory(m);
  const status  = extractAssetStatus(m);
  const isCount = isCountQuestion(m);
  const isRank  = isRankingQuestion(m);

  // Helper to build ILIKE conditions
  const knoxWhere = (alias = '') => {
    const col = alias ? `${alias}.knox_id` : 'knox_id';
    if (knoxIds.length === 0) return '';
    if (knoxIds.length === 1) return `${col} ILIKE '%${knoxIds[0]}%'`;
    return '(' + knoxIds.map(k => `${col} ILIKE '%${k}%'`).join(' OR ') + ')';
  };
  const catWhere   = cat    ? `category ILIKE '%${cat}%'`    : '';
  const statWhere  = status ? `status ILIKE '%${status}%'`   : '';

  const conditions = (...parts: string[]) =>
    parts.filter(Boolean).join(' AND ');

  // ── RANKING: "who has the most assets / laptops" ──────────────────────────
  if (isRank) {
    const where = conditions(catWhere, statWhere,
      `knox_id IS NOT NULL AND knox_id <> ''`);
    const q = `SELECT knox_id, COUNT(*)::int AS count FROM assets
               WHERE ${where || "knox_id IS NOT NULL AND knox_id <> ''"}
               GROUP BY knox_id ORDER BY count DESC LIMIT 20;`;
    const { rows, error } = await runQuery(q);
    if (error) return `Query error: ${error}`;
    return formatRows(rows, message);
  }

  // ── USER-SPECIFIC: question mentions at least one knox_id ─────────────────
  if (knoxIds.length > 0) {
    const userWhere = knoxWhere();
    const where = conditions(userWhere, catWhere, statWhere);

    if (isCount) {
      if (knoxIds.length > 1) {
        // "how many assets do j.flora and m.santos have" → GROUP BY
        const q = `SELECT knox_id, COUNT(*)::int AS count FROM assets
                   WHERE ${where} GROUP BY knox_id ORDER BY count DESC;`;
        const { rows, error } = await runQuery(q);
        if (error) return `Query error: ${error}`;
        return formatRows(rows, message);
      } else {
        // "how many laptops deployed to j.flora"
        const q = `SELECT COUNT(*)::int AS count FROM assets WHERE ${where};`;
        const { rows, error } = await runQuery(q);
        if (error) return `Query error: ${error}`;
        const count = rows[0]?.count ?? 0;
        const user  = knoxIds[0];
        const catLabel   = cat    ? cat.toLowerCase() + (count !== 1 ? 's' : '') : `asset${count !== 1 ? 's' : ''}`;
        const statLabel  = status ? ` ${status.toLowerCase()}` : '';
        return `**${user}** has **${count}**${statLabel} ${catLabel}.`;
      }
    }

    // LIST: "show assets for j.flora", "list j.flora's laptops"
    const q = `SELECT asset_tag, name, category, status, knox_id, location, department
               FROM assets WHERE ${where}
               ORDER BY asset_tag LIMIT 50;`;
    const { rows, error } = await runQuery(q);
    if (error) return `Query error: ${error}`;
    return formatRows(rows, message);
  }

  // ── GLOBAL COUNT / LIST (no specific user) ────────────────────────────────

  // "how many total assets"
  if (isCount && !cat && /\basset(s)?\b/i.test(m)) {
    const { rows } = await runQuery(`SELECT COUNT(*)::int AS count FROM assets;`);
    const count = rows[0]?.count ?? 0;
    const byStatus = await runQuery(
      `SELECT status, COUNT(*)::int AS count FROM assets GROUP BY status ORDER BY count DESC;`
    );
    const lines = byStatus.rows.map((r: any) => `  - ${r.status}: **${r.count}**`).join('\n');
    return `There are **${count}** total assets in the system.\n\n**By Status:**\n${lines}`;
  }

  // "how many laptops / desktops / etc"
  if (isCount && cat) {
    const where = conditions(catWhere, statWhere);
    const { rows } = await runQuery(
      `SELECT COUNT(*)::int AS count FROM assets WHERE ${where};`
    );
    const count = rows[0]?.count ?? 0;
    const byStatus = await runQuery(
      `SELECT status, COUNT(*)::int AS count FROM assets WHERE ${catWhere}
       GROUP BY status ORDER BY count DESC;`
    );
    const lines = byStatus.rows.map((r: any) => `  - ${r.status}: **${r.count}**`).join('\n');
    const statLabel = status ? ` ${status.toLowerCase()}` : '';
    return `There are **${count}**${statLabel} **${cat.toLowerCase()}s** in the system.\n\n**By Status:**\n${lines}`;
  }

  // "list all deployed assets", "show available laptops"
  if ((isCount || /\b(list|show|give|find|display)\b/i.test(m)) && (cat || status)) {
    const where = conditions(catWhere, statWhere);
    const q = `SELECT asset_tag, name, category, status, knox_id, location
               FROM assets ${where ? `WHERE ${where}` : ''}
               ORDER BY asset_tag LIMIT 50;`;
    const { rows, error } = await runQuery(q);
    if (error) return `Query error: ${error}`;
    return formatRows(rows, message);
  }

  // "how many users"
  if (isCount && /\buser(s)?\b/i.test(m)) {
    const { rows } = await runQuery(`SELECT COUNT(*)::int AS count FROM users;`);
    return `There are **${rows[0]?.count ?? 0}** users registered in the system.`;
  }

  // "how many VMs"
  if (isCount && /\b(vm|virtual machine)s?\b/i.test(m)) {
    const { rows } = await runQuery(`SELECT COUNT(*)::int AS count FROM vm_inventory;`);
    const count = rows[0]?.count ?? 0;
    const byStatus = await runQuery(
      `SELECT vm_status, COUNT(*)::int AS count FROM vm_inventory GROUP BY vm_status ORDER BY count DESC;`
    );
    const lines = byStatus.rows.map((r: any) => `  - ${r.vm_status}: **${r.count}**`).join('\n');
    return `There are **${count}** virtual machines.\n\n**By Status:**\n${lines}`;
  }

  // "how many licenses"
  if (isCount && /\blicense(s)?\b/i.test(m)) {
    const { rows } = await runQuery(`SELECT COUNT(*)::int AS count FROM licenses;`);
    const count = rows[0]?.count ?? 0;
    const byStatus = await runQuery(
      `SELECT status, COUNT(*)::int AS count FROM licenses GROUP BY status ORDER BY count DESC;`
    );
    const lines = byStatus.rows.map((r: any) => `  - ${r.status}: **${r.count}**`).join('\n');
    return `There are **${count}** licenses.\n\n**By Status:**\n${lines}`;
  }

  // "how many IAM accounts"
  if (isCount && /\biam\b/i.test(m)) {
    const { rows } = await runQuery(`SELECT COUNT(*)::int AS count FROM iam_accounts;`);
    const count = rows[0]?.count ?? 0;
    const byStatus = await runQuery(
      `SELECT status, COUNT(*)::int AS count FROM iam_accounts GROUP BY status ORDER BY count DESC;`
    );
    const lines = byStatus.rows.map((r: any) => `  - ${r.status}: **${r.count}**`).join('\n');
    return `There are **${count}** IAM accounts.\n\n**By Status:**\n${lines}`;
  }

  // "how many (cloud: azure/gcp/aws)"
  if (isCount && /\bazure\b/i.test(m)) {
    const { rows } = await runQuery(`SELECT COUNT(*)::int AS count FROM azure_inventory;`);
    return `There are **${rows[0]?.count ?? 0}** Azure resources.`;
  }
  if (isCount && /\bgcp\b/i.test(m)) {
    const { rows } = await runQuery(`SELECT COUNT(*)::int AS count FROM gcp_inventory;`);
    return `There are **${rows[0]?.count ?? 0}** GCP resources.`;
  }
  if (isCount && /\baws\b/i.test(m)) {
    const { rows } = await runQuery(`SELECT COUNT(*)::int AS count FROM aws_inventory;`);
    return `There are **${rows[0]?.count ?? 0}** AWS resources.`;
  }

  // "list VMs", "show active VMs", "overdue VMs"
  if (/\b(vm|virtual machine)s?\b/i.test(m) && /\b(list|show|active|overdue|decommissioned)\b/i.test(m)) {
    let vmWhere = '';
    if (/\bactive\b/i.test(m))          vmWhere = `WHERE vm_status ILIKE '%active%'`;
    else if (/\boverdue\b/i.test(m))    vmWhere = `WHERE vm_status ILIKE '%overdue%'`;
    else if (/\bdecommissioned\b/i.test(m)) vmWhere = `WHERE vm_status ILIKE '%decommissioned%'`;
    const { rows, error } = await runQuery(
      `SELECT vm_name, vm_status, vm_ip, department, knox_id FROM vm_inventory ${vmWhere} ORDER BY vm_name LIMIT 50;`
    );
    if (error) return `Query error: ${error}`;
    return formatRows(rows, message);
  }

  // "list expired licenses"
  if (/\blicense(s)?\b/i.test(m) && /\b(list|show|expired|active|unused)\b/i.test(m)) {
    let licWhere = '';
    if (/\bexpired\b/i.test(m)) licWhere = `WHERE status ILIKE '%expired%'`;
    else if (/\bactive\b/i.test(m)) licWhere = `WHERE status ILIKE '%active%'`;
    else if (/\bunused\b/i.test(m)) licWhere = `WHERE status ILIKE '%unused%'`;
    const { rows, error } = await runQuery(
      `SELECT name, status, company, expiration_date, seats FROM licenses ${licWhere} ORDER BY name LIMIT 50;`
    );
    if (error) return `Query error: ${error}`;
    return formatRows(rows, message);
  }

  // "asset count per department"
  if (/\bdepartment\b/i.test(m) && isCount) {
    const { rows, error } = await runQuery(
      `SELECT department, COUNT(*)::int AS count FROM assets WHERE department IS NOT NULL GROUP BY department ORDER BY count DESC;`
    );
    if (error) return `Query error: ${error}`;
    return formatRows(rows, message);
  }

  // "bad condition" / "defective"
  if (/\b(bad condition|defective|bad)\b/i.test(m)) {
    const { rows, error } = await runQuery(
      `SELECT asset_tag, name, category, status, condition, knox_id FROM assets WHERE condition ILIKE '%bad%' ORDER BY asset_tag LIMIT 50;`
    );
    if (error) return `Query error: ${error}`;
    return formatRows(rows, message);
  }

  // No pattern matched — return null to fall through to Ollama
  return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// OLLAMA CALL — only for guide/how-to/general questions
// Has a hard 20s timeout. If Ollama is slow or down, returns a static message.
// ─────────────────────────────────────────────────────────────────────────────
async function askOllama(systemPrompt: string, userMessage: string, history: any[]): Promise<string> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), OLLAMA_TIMEOUT_MS);

  try {
    const recentHistory = (history || []).filter((m: any) => m.role && m.content).slice(-4);
    const response = await fetch("http://127.0.0.1:11434/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({
        model: "llama3",
        messages: [
          { role: "system", content: systemPrompt },
          ...recentHistory,
          { role: "user", content: userMessage }
        ],
        stream: false,
        options: { temperature: 0.7, num_predict: 512 }
      })
    });
    if (!response.ok) throw new Error(`Ollama HTTP ${response.status}`);
    const data = await response.json();
    return data.message?.content || "I couldn't generate a response.";
  } catch (err: any) {
    if (err.name === 'AbortError' || controller.signal.aborted) {
      return "The AI assistant is taking too long. Please try again or ask a simpler question.";
    }
    console.error("[CHATBOT] Ollama error:", err.message);
    return "The AI assistant is currently unavailable. Please try again later.";
  } finally {
    clearTimeout(timer);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// ROUTE REGISTRATION
// ─────────────────────────────────────────────────────────────────────────────
export function registerChatbotRoutes(app: Express, requireAuth: any) {

  app.post("/api/chat", requireAuth, async (req: Request, res: Response) => {
    // Hard socket timeout — server ALWAYS responds within 25s
    res.setTimeout(25_000, () => {
      if (!res.headersSent) {
        res.status(504).json({
          reply: "The request took too long. Please try again."
        });
      }
    });

    try {
      const { message, history } = req.body;
      if (!message?.trim()) {
        return res.status(400).json({ reply: "Please enter a message." });
      }

      console.log(`[CHATBOT] Q: "${message}"`);

      const m = message.toLowerCase();

      // ── PATH 1: Inventory / Data question ──────────────────────────────────
      // Handled entirely with direct PostgreSQL — NO Ollama call.
      const isDataQ = /\b(how many|count|total|list|show|find|search|give me|who has|assigned|deployed|status|asset|laptop|desktop|mobile|tablet|monitor|vm|virtual machine|license|iam|accessory|accessories|component|consumable|bitlocker|azure|gcp|aws|user|department|equipment|inventory|overdue|defective|bad condition|available|active|expired|inactive|decommissioned|ranking)\b/i.test(m);

      if (isDataQ) {
        console.log("[CHATBOT] PATH: Inventory (direct SQL, no Ollama)");
        try {
          const answer = await handleInventoryQuestion(message);
          if (answer !== null) {
            return res.json({ reply: answer });
          }
          // handleInventoryQuestion returned null → no pattern matched
          // Fall through to Ollama for unusual data questions
          console.log("[CHATBOT] No pattern matched — falling to Ollama");
        } catch (err: any) {
          console.error("[CHATBOT] Inventory handler error:", err.message);
          return res.json({ reply: `Query error: ${err.message}` });
        }
      }

      // ── PATH 2: Guide / How-to / General (Ollama with 20s hard limit) ──────
      console.log("[CHATBOT] PATH: Guide/General (Ollama)");

      let systemPrompt = `You are the SRPH-MIS AI Assistant for an IT inventory management system.
Today is ${new Date().toLocaleString()}.
Be helpful, accurate, and concise. If you don't know something, say so.`;

      const isGuide = /\b(how to|how do|how can|steps|guide|setup|configure|install|fix|troubleshoot|explain|what is|what are|help me)\b/i.test(m);
      if (isGuide) {
        try {
          const { CHATBOT_SYSTEM_KNOWLEDGE } = await import("./chatbot-knowledge");
          systemPrompt += `\n\n--- SRPH-MIS SYSTEM MANUAL ---\n${CHATBOT_SYSTEM_KNOWLEDGE}\n--- END OF MANUAL ---`;
          console.log("[CHATBOT] Loaded knowledge base");
        } catch {
          console.warn("[CHATBOT] Could not load knowledge base");
        }
      }

      const reply = await askOllama(systemPrompt, message, history);
      return res.json({ reply });

    } catch (err: any) {
      console.error("[CHATBOT] Unhandled error:", err.message);
      if (!res.headersSent) {
        return res.status(500).json({ reply: `Server error: ${err.message}` });
      }
    }
  });
}