import { db } from "./db.js";
import { sql } from "drizzle-orm";

async function run() {
  try {
    console.log("Patching database...");
    
    // Drop old table to avoid drizzle interactive prompt
    await db.execute(sql`DROP TABLE IF EXISTS "jira_settings" CASCADE;`);
    
    // Add the specific column that caused the crash in case push still fails
    await db.execute(sql`ALTER TABLE "system_settings" ADD COLUMN IF NOT EXISTS "notify_on_approval_expiration" boolean DEFAULT true;`);
    
    console.log("Successfully patched database.");
    process.exit(0);
  } catch (e) {
    console.error("Error patching database:", e);
    process.exit(1);
  }
}

run();
