Add-Type -AssemblyName System.IO.Compression.FileSystem

$zipPath = "C:\Users\samsung\.ollama\models.zip"
$destRoot = "C:\Users\samsung\.ollama"

Write-Host "Opening models.zip (4.2GB)..."
$zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)

foreach ($entry in $zip.Entries) {
    $name = $entry.FullName
    # Skip directory entries
    if ($name.EndsWith('/') -or $name.EndsWith('\')) { continue }
    
    $destPath = Join-Path $destRoot $name
    $destDir  = Split-Path $destPath -Parent

    if (-not (Test-Path $destDir)) {
        New-Item -ItemType Directory -Path $destDir -Force | Out-Null
    }

    if (Test-Path $destPath) {
        Write-Host "  SKIP (exists): $name"
    } else {
        Write-Host "  Extracting:    $name ..."
        [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $destPath)
        Write-Host "  Done:          $name"
    }
}

$zip.Dispose()
Write-Host ""
Write-Host "Extraction complete! Verifying..."

# Verify the manifest exists
$manifest = "C:\Users\samsung\.ollama\models\manifests\registry.ollama.ai\library\llama3\latest"
if (Test-Path $manifest) {
    Write-Host "SUCCESS: llama3 manifest found at $manifest"
} else {
    Write-Host "WARNING: Manifest not found. Check the zip contents."
}
