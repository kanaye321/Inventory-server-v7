/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║              SECURITY MIDDLEWARE — DEFENCE IN DEPTH             ║
 * ║  Layers:                                                         ║
 * ║   1. Security HTTP headers                                      ║
 * ║   2. Blocked-IP enforcement                                     ║
 * ║   3. Request-size guard (10 MB hard cap)                        ║
 * ║   4. Suspicious user-agent detection                            ║
 * ║   5. SQL injection pattern detection & blocking                 ║
 * ║   6. XSS / script-injection sanitization                        ║
 * ║   7. URL parameter sanitization                                 ║
 * ║   8. Auth-endpoint rate limiting                                ║
 * ║   9. Persistent security event logging (dashboard)              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

import type { Request, Response, NextFunction } from "express";
import { db } from "../db";
import * as schema from "../../shared/schema";
import { eq, and } from "drizzle-orm";

// ─── 1. SQL injection patterns ────────────────────────────────────────────────
// IMPORTANT: Do NOT use the `g` (global) flag here.
// RegExp.prototype.test() with a global flag is stateful — it advances
// lastIndex on each call, causing non-deterministic behaviour and potential
// server freezes on large payloads. Use non-global regexes only.
const SQL_INJECTION_PATTERNS: RegExp[] = [
  /(\b)(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE|UNION|TRUNCATE|REPLACE)\b/i,
  /--[ \t]|--$/m,              // SQL line comments (-- followed by space/tab or end-of-line)
                               // NOTE: CSS custom properties (--var-name) are excluded
  /\/\*[\s\S]*?\*\//,          // SQL block comments: /* ... */
  /(;)\s*(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|TRUNCATE)/i,
  /\b(OR|AND)\s+['"]?\d+['"]?\s*=\s*['"]?\d+['"]?/i,  // OR 1=1 / AND 1=1
  /'(\s*)(OR|AND)(\s*)'/i,     // ' OR ' / ' AND '
  /xp_cmdshell/i,
  /information_schema/i,
  /sys\.sysobjects/i,
  /CAST\s*\(/i,
  /CONVERT\s*\(/i,
  /CHAR\s*\(\d+\)/i,
  /WAITFOR\s+DELAY/i,
  /BENCHMARK\s*\(/i,
  /SLEEP\s*\(/i,
  /[\0\x08\x1a]/,              // null byte, BS, SUB — genuine control chars
                               // \x09(tab) \x0d(CR) \x0a(LF) intentionally excluded
];

// ─── 2. XSS / script-injection patterns ───────────────────────────────────────
const XSS_PATTERNS: RegExp[] = [
  /<script[\s\S]*?>[\s\S]*?<\/script>/i,
  /<iframe[\s\S]*?>[\s\S]*?<\/iframe>/i,
  /javascript\s*:/i,
  /vbscript\s*:/i,
  /on\w+\s*=\s*["'][^"']*["']/i,
  /<img[^>]+src\s*=\s*["']?\s*javascript:/i,
  /&#x?[0-9a-fA-F]+;/,
  /expression\s*\(/i,
  /eval\s*\(/i,
  /document\s*\.\s*cookie/i,
  /document\s*\.\s*write/i,
  /window\s*\.\s*location/i,
];

// ─── 3. Suspicious user-agent fragments ───────────────────────────────────────
const SUSPICIOUS_AGENTS: RegExp[] = [
  /sqlmap/i,
  /nikto/i,
  /nessus/i,
  /nmap/i,
  /masscan/i,
  /zgrab/i,
  /python-requests\/[0-9]/i,
  /go-http-client\/[0-9]/i,
  /curl\/[0-9]/i,     // commonly used in automated scans; legitimate curl blocked here for API
  /dirbuster/i,
  /acunetix/i,
  /burpsuite/i,
  /w3af/i,
  /havij/i,
];

// ─── Auto-block config ────────────────────────────────────────────────────────
const AUTO_BLOCK_THRESHOLD = 10;   // threats before auto-block
const THREAT_WINDOW_MS = 10 * 60 * 1000;  // 10-minute sliding window

// ─── In-memory state ──────────────────────────────────────────────────────────
/** Fast lookup set of currently-blocked IPs (loaded from DB at startup) */
const blockedIpCache = new Set<string>();

/** Per-IP threat counter used for auto-blocking */
interface ThreatEntry { count: number; windowStart: number }
const threatCounter = new Map<string, ThreatEntry>();

// Prune threat counter every 15 minutes
setInterval(() => {
  const cutoff = Date.now() - THREAT_WINDOW_MS;
  for (const [ip, entry] of threatCounter.entries()) {
    if (entry.windowStart < cutoff) threatCounter.delete(ip);
  }
}, 15 * 60 * 1000);

// ─── Cache management (called by routes.ts) ───────────────────────────────────
/** Load active blocked IPs from DB into memory. Call once at server start. */
export async function initBlockedIpCache(): Promise<void> {
  try {
    const rows = await db
      .select()
      .from(schema.blockedIps)
      .where(eq(schema.blockedIps.unblocked, false));
    blockedIpCache.clear();
    for (const row of rows) {
      if (!row.expiresAt || row.expiresAt > new Date()) {
        blockedIpCache.add(row.ip);
      }
    }
    console.log(`[SECURITY] Loaded ${blockedIpCache.size} blocked IPs into cache.`);
  } catch (err: any) {
    if (err.code === '42P01' || err.message?.includes('relation "blocked_ips" does not exist')) {
      console.log("[SECURITY] Blocked IP table not yet initialized. Skipping cache load.");
    } else {
      console.error("[SECURITY] Failed to load blocked IP cache:", err.message);
    }
  }
}

/** Add an IP to the in-memory cache (called after DB insert). */
export function addToBlockedIpCache(ip: string): void {
  blockedIpCache.add(ip);
}

/** Remove an IP from the in-memory cache (called after DB unblock). */
export function removeFromBlockedIpCache(ip: string): void {
  blockedIpCache.delete(ip);
}

// ─── Event logging ────────────────────────────────────────────────────────────
/** Fire-and-forget: persists a security event to the DB. */
function logSecurityEvent(
  req: Request,
  threatType: string,
  severity: "low" | "medium" | "high" | "critical",
  details: string,
): void {
  const ip = (req.ip ?? req.socket?.remoteAddress ?? "unknown").replace(/^::ffff:/, "");
  setImmediate(async () => {
    try {
      await db.insert(schema.securityEvents).values({
        ip,
        method: req.method,
        path: req.path,
        threatType,
        severity,
        blocked: true,
        userAgent: req.headers["user-agent"]?.slice(0, 500) ?? null,
        details: details.slice(0, 1000),
      });
    } catch {/* DB unavailable — ignore, never block the response pipeline */}
  });

  // Auto-block after threshold
  const now = Date.now();
  const entry = threatCounter.get(ip);
  if (!entry || now - entry.windowStart > THREAT_WINDOW_MS) {
    threatCounter.set(ip, { count: 1, windowStart: now });
  } else {
    entry.count++;
    if (entry.count >= AUTO_BLOCK_THRESHOLD && !blockedIpCache.has(ip)) {
      blockedIpCache.add(ip);
      setImmediate(async () => {
        try {
          await db.insert(schema.blockedIps).values({
            ip,
            reason: `Auto-blocked: ${entry.count} threats in 10 minutes (last: ${threatType})`,
            blockedBy: "auto",
            unblocked: false,
          }).onConflictDoNothing();
          console.warn(`[SECURITY] Auto-blocked IP ${ip} after ${entry.count} threats.`);
        } catch {/* ignore */}
      });
    }
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function containsSQLInjection(value: string): boolean {
  return SQL_INJECTION_PATTERNS.some((p) => { p.lastIndex = 0; return p.test(value); });
}

function containsXSS(value: string): boolean {
  return XSS_PATTERNS.some((p) => { p.lastIndex = 0; return p.test(value); });
}

// HTML entity escape function
// Note: Forward slash (/) is NOT encoded to preserve date formats (MM/DD/YYYY)
// Forward slash encoding is not required for XSS prevention in HTML content
const HTML_ENTITIES: Record<string, string> = {
  '&': '\u0026amp;',
  '<': '\u0026lt;',
  '>': '\u0026gt;',
  '"': '\u0026quot;',
  "'": '\u0026#x27;',
};

function escapeHtml(str: string): string {
  return str.replace(/[&<>"']/g, (char) => HTML_ENTITIES[char] || char);
}

function stripDangerousChars(str: string): string {
  // eslint-disable-next-line no-control-regex
  return str.replace(/[\0\x08\x1a]/g, "");
}

function sanitizeObject(obj: unknown, allowedHtml = false): unknown {
  if (obj === null || obj === undefined) return obj;
  if (typeof obj === "string") {
    let s = stripDangerousChars(obj);
    if (!allowedHtml) s = escapeHtml(s);
    return s;
  }
  if (Array.isArray(obj)) return obj.map((v) => sanitizeObject(v, allowedHtml));
  if (typeof obj === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj as Record<string, unknown>)) {
      const safeKey = k.replace(/[^a-zA-Z0-9_\-\.]/g, "");
      if (safeKey) out[safeKey] = sanitizeObject(v, allowedHtml);
    }
    return out;
  }
  return obj;
}

function checkForInjection(obj: unknown, path = ""): string | null {
  if (typeof obj === "string") {
    if (containsSQLInjection(obj)) return `SQL injection pattern in ${path || "input"}`;
    if (containsXSS(obj))         return `XSS pattern in ${path || "input"}`;
    return null;
  }
  if (Array.isArray(obj)) {
    for (let i = 0; i < obj.length; i++) {
      const err = checkForInjection(obj[i], `${path}[${i}]`);
      if (err) return err;
    }
    return null;
  }
  if (obj !== null && typeof obj === "object") {
    for (const [k, v] of Object.entries(obj as Record<string, unknown>)) {
      const err = checkForInjection(v, path ? `${path}.${k}` : k);
      if (err) return err;
    }
    return null;
  }
  return null;
}

// ─── Rate limiter ─────────────────────────────────────────────────────────────
interface RateLimitEntry { count: number; windowStart: number }
const rateLimitMap = new Map<string, RateLimitEntry>();

function rateLimiter(maxRequests: number, windowMs: number) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const ip = (req.ip ?? req.socket.remoteAddress ?? "unknown").replace(/^::ffff:/, "");
    const now = Date.now();
    const entry = rateLimitMap.get(ip);

    if (!entry || now - entry.windowStart > windowMs) {
      rateLimitMap.set(ip, { count: 1, windowStart: now });
      return next();
    }
    entry.count++;
    if (entry.count > maxRequests) {
      logSecurityEvent(req, "rate_limit", "medium",
        `Exceeded ${maxRequests} requests in ${windowMs / 1000}s`);
      res.status(429).json({
        error: "Too many requests",
        message: `Rate limit exceeded. Maximum ${maxRequests} requests per ${windowMs / 1000}s.`,
        retryAfter: Math.ceil((entry.windowStart + windowMs - now) / 1000),
      });
      return;
    }
    next();
  };
}

setInterval(() => {
  const cutoff = Date.now() - 15 * 60 * 1000;
  for (const [key, entry] of rateLimitMap.entries()) {
    if (entry.windowStart < cutoff) rateLimitMap.delete(key);
  }
}, 5 * 60 * 1000);

// ═══════════════════════════════════════════════════════════════════════════════
// ─── Exported middleware ───────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * checkBlockedIp
 * Layer 2: Rejects requests from IPs in the blocked-IP cache immediately.
 */
export function checkBlockedIp(req: Request, res: Response, next: NextFunction): void {
  const ip = (req.ip ?? req.socket?.remoteAddress ?? "").replace(/^::ffff:/, "");
  if (ip && blockedIpCache.has(ip)) {
    // Still log the attempt so it shows in the dashboard
    logSecurityEvent(req, "blocked_ip", "critical", `Request from blocked IP ${ip}`);
    res.status(403).json({ error: "Forbidden", message: "Access denied." });
    return;
  }
  next();
}

/**
 * requestSizeGuard
 * Layer 3: Rejects requests whose Content-Length header exceeds 10 MB.
 * This prevents memory exhaustion from enormous payloads.
 */
export function requestSizeGuard(req: Request, res: Response, next: NextFunction): void {
  const MAX_BYTES = 10 * 1024 * 1024; // 10 MB
  const contentLength = parseInt(req.headers["content-length"] ?? "0", 10);
  if (contentLength > MAX_BYTES) {
    logSecurityEvent(req, "oversized_request", "high",
      `Content-Length ${contentLength} exceeds limit ${MAX_BYTES}`);
    res.status(413).json({
      error: "Payload Too Large",
      message: "Request body exceeds the 10 MB limit.",
    });
    return;
  }
  next();
}

/**
 * suspiciousAgentGuard
 * Layer 4: Blocks well-known vulnerability scanners and automated attack tools
 * by matching the User-Agent header against a known-bad list.
 */
export function suspiciousAgentGuard(req: Request, res: Response, next: NextFunction): void {
  const ua = req.headers["user-agent"] ?? "";
  if (SUSPICIOUS_AGENTS.some((p) => p.test(ua))) {
    logSecurityEvent(req, "suspicious_agent", "high",
      `Suspicious User-Agent: ${ua.slice(0, 200)}`);
    res.status(403).json({ error: "Forbidden", message: "Access denied." });
    return;
  }
  next();
}

/**
 * sqlInjectionProtection
 * Layer 5+6: Checks req.body, req.query, req.params for injection patterns.
 * HTML-rich routes (email templates, settings) are exempt from scanning but
 * still have dangerous control characters stripped.
 */
export function sqlInjectionProtection(req: Request, res: Response, next: NextFunction): void {
  const htmlAllowedPaths = [
    "/api/page-builder",
    "/api/email",
    "/api/custom-pages",
    "/api/settings",
    "/api/send-modification-notification",
    "/api/email-bulk-sender",
    "/api/chat",   // Chatbot messages are natural language sent to Ollama — never used in SQL queries
  ];
  const isHtmlAllowed = htmlAllowedPaths.some((p) => req.path.startsWith(p));

  if (req.body && typeof req.body === "object") {
    if (!isHtmlAllowed) {
      const err = checkForInjection(req.body);
      if (err) {
        console.warn(`[SECURITY] Blocked ${req.path}: ${err} — IP: ${req.ip}`);
        logSecurityEvent(req,
          err.startsWith("SQL") ? "sql_injection" : "xss",
          "high", err);
        res.status(400).json({ error: "Invalid input", message: "Request contains potentially malicious content." });
        return;
      }
    }
    req.body = sanitizeObject(req.body, isHtmlAllowed);
  }

  if (req.query) {
    const err = checkForInjection(req.query, "query");
    if (err) {
      console.warn(`[SECURITY] Blocked query on ${req.path}: ${err} — IP: ${req.ip}`);
      logSecurityEvent(req,
        err.startsWith("SQL") ? "sql_injection" : "xss",
        "high", err);
      res.status(400).json({ error: "Invalid input", message: "Query parameters contain potentially malicious content." });
      return;
    }
    req.query = sanitizeObject(req.query) as typeof req.query;
  }

  if (req.params) {
    const err = checkForInjection(req.params, "params");
    if (err) {
      console.warn(`[SECURITY] Blocked params on ${req.path}: ${err} — IP: ${req.ip}`);
      logSecurityEvent(req,
        err.startsWith("SQL") ? "sql_injection" : "xss",
        "high", err);
      res.status(400).json({ error: "Invalid input", message: "URL parameters contain potentially malicious content." });
      return;
    }
  }

  next();
}

/**
 * securityHeaders
 * Sets protective HTTP response headers on every response.
 */
export function securityHeaders(req: Request, res: Response, next: NextFunction): void {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("X-XSS-Protection", "1; mode=block");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader(
    "Content-Security-Policy",
    [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data: blob:",
      "connect-src 'self' ws: wss:",
      "frame-ancestors 'none'",
    ].join("; ")
  );
  if (req.path.startsWith("/api/")) {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
  }
  next();
}

/** authRateLimiter — max 10 login attempts per 15 minutes per IP */
export const authRateLimiter = rateLimiter(10, 15 * 60 * 1000);

/** apiRateLimiter — max 300 requests per minute per IP */
export const apiRateLimiter = rateLimiter(300, 60 * 1000);

/** validateId — ensures :id param is a valid positive integer */
export function validateId(req: Request, res: Response, next: NextFunction): void {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    res.status(400).json({ error: "Invalid ID", message: "ID must be a positive integer." });
    return;
  }
  next();
}

/** sanitizeBody — standalone sanitiser for individual routes */
export function sanitizeBody(req: Request, _res: Response, next: NextFunction): void {
  if (req.body) req.body = sanitizeObject(req.body);
  next();
}

export { sanitizeObject, checkForInjection };